"""Strict parser for the native @-self notification text (WeChat 4.2.0.53 only).

Provenance
----------
Bridge 11 (ABI 2) copies the raw native push/notification string from the
inbound message object (+0x40 on 4.2.0.53, evidence in
.analysis/wechat-42053/sender-name-probe/) into ``WcaEvent.notification_text``
and ``Event.notification_text``. WeChat composes that string for an @-self group
message as ``<rendered sender name>在群聊中@了你``: the sender's group card
(群昵称) when one is set, otherwise the sender's WeChat name. The parser reports
that rendered name verbatim (after whitespace trim); it never reads account
caches, contacts, remarks or private profiles, so a private remark can never
become a display name.

Eligibility and limits
----------------------
``parse_sender_display_name`` is intentionally narrow:

- it accepts only the exact template above as a full match; empty strings,
  other templates and template mismatches return ``None``;
- the caller must already have established that the observation is a group
  message whose native ``atuserlist`` contains the bound account; the event
  mapping layer enforces that before calling;
- the name is whitespace-trimmed, must be non-empty, free of C0/DEL control
  characters and at most ``MAX_DISPLAY_NAME`` characters; a longer candidate is
  treated as a template mismatch rather than exposed as a name.

This value is inbound/display provenance only. It is not a verified identity
and it must never be used as a native outbound @ label: a clickable native @
requires the receiver's actual display name, and this field describes the
*sender*, not the target.

4.2.0.52 is explicitly unsupported. Its native profile carries no notification
offset, the bridge never reads +0x40 there, and both event fields stay ``None``.
"""
import re

MAX_DISPLAY_NAME=128
_AT_SELF=re.compile(r'^(?P<name>[^\x00-\x1f\x7f]+?)在群聊中@了你$')


def parse_sender_display_name(text: str | None) -> str | None:
    """Return the rendered sender name of an @-self group notification, or None.

    ``text`` is the raw ``Event.notification_text`` value. The caller is
    responsible for the @-self group context; this function only validates the
    native template and bounds the extracted name.
    """
    if not isinstance(text,str) or not text:
        return None
    match=_AT_SELF.fullmatch(text)
    if match is None:
        return None
    name=match.group('name').strip()
    if not name or len(name)>MAX_DISPLAY_NAME:
        return None
    return name
