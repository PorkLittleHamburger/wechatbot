from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping,Generic,TypeVar
import time

from .errors import ErrorCode
from .media import MediaHandle


def freeze(value):
    if isinstance(value, Mapping):
        return MappingProxyType({str(k): freeze(v) for k, v in value.items()})
    if isinstance(value, (list, tuple)):
        return tuple(freeze(v) for v in value)
    return value


class CapabilityState(str, Enum):
    SUPPORTED = "supported"
    NOT_ADAPTED = "not_adapted"
    NOT_VERIFIED = "not_verified"
    UNAVAILABLE = "unavailable"


@dataclass(frozen=True)
class Capability:
    name: str
    state: CapabilityState
    reason: str
    scenarios: tuple[str, ...] = ()


@dataclass(frozen=True)
class BuildInfo:
    version: str
    architecture: str
    size: int
    sha256: str
    timestamp: int
    image_size: int
    path: Path
    recognized: bool


@dataclass(frozen=True)
class Account:
    wxid: str
    wechat_name: str | None = None


@dataclass(frozen=True)
class DiscoveryResult:
    pid: int
    process_created: int
    build: BuildInfo | None
    account: Account | None
    error: ErrorCode | None
    detail: str
    bridge_supported: bool = False


class SendState(str, Enum):
    ACCEPTED = "accepted"
    COMPLETED = "completed"
    FAILED = "failed"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class OperationResult:
    operation_id: str
    state: SendState
    error: ErrorCode | None = None
    native_message_id: str | None = None
    accepted_parts: int = 0
    detail: str = ""
    native_error: int | None = None


@dataclass(frozen=True)
class SendResult(OperationResult):
    pass


@dataclass(frozen=True)
class Event:
    """Immutable inbound observation snapshot.

    Schema 2 adds two optional, inbound-only fields for WeChat 4.2.0.53:

    - ``notification_text``: the native push/notification string copied from the
      message object by bridge 11. It is ``None`` when the observation carries
      none, and always ``None`` on 4.2.0.52 (explicitly unadapted: no offset is
      assumed or read). Raw display-oriented data, not a verified identity.
    - ``sender_display_name``: strict parse of an @-self group notification
      (rendered group-card name, falling back to the WeChat name as WeChat
      displayed it). ``None`` for anything that is not a self-mention or does
      not match the notification template. Never a private remark and never a
      native outbound @ label; see ``_notification.py`` for provenance.
    """
    event_id: str
    account_id: str
    session_id: str
    sequence: int
    kind: str
    chat_id: str | None = None
    sender_id: str | None = None
    native_message_id: str | None = None
    native_timestamp: float | None = None
    content_type: str | None = None
    text: str | None = None
    mentions: tuple[str, ...] = ()
    reference: Mapping[str, Any] | None = None
    content: Mapping[str, Any] = field(default_factory=dict)
    schema_version: int = 2
    observed_at: float = field(default_factory=time.time)
    media: MediaHandle | None = None
    bridge_sequence: int | None = None
    notification_text: str | None = None
    sender_display_name: str | None = None

    def __post_init__(self):
        object.__setattr__(self, 'mentions', tuple(self.mentions))
        object.__setattr__(self, 'reference', freeze(self.reference))
        object.__setattr__(self, 'content', freeze(self.content))


@dataclass(frozen=True)
class SessionStatus:
    state: str
    account_id: str | None
    pid: int
    pending_operations: int
    last_error: ErrorCode | None = None


@dataclass(frozen=True)
class GroupInfo:
    wxid: str
    name: str | None = None


@dataclass(frozen=True)
class GroupMember:
    wxid: str
    group_nickname: str | None = None
    wechat_name: str | None = None
    remark: str | None = None
    role: str | None = None


@dataclass(frozen=True)
class ContactInfo:
    wxid: str
    wechat_name: str | None = None
    remark: str | None = None
    relationship: str | None = None


DirectoryRow=TypeVar('DirectoryRow',GroupInfo,GroupMember,ContactInfo)


@dataclass(frozen=True)
class DirectorySnapshot(Generic[DirectoryRow]):
    records: tuple[DirectoryRow, ...]
    source: str = 'wechat_cache'
    complete: bool = False
