"""Bounded stable cache reader; no native calls and no network synchronization.

Container algorithms adapted from helper group_members.py/contacts.py. Every
supported build carries its own class vtables and provider addresses; the
container/field offsets are shared only where the target build's constructors
and live cache objects independently prove them. A registered build without
that evidence is rejected with NOT_ADAPTED instead of being reinterpreted with
another build's constants.

Evidence for 4.2.0.53 (class constructors + live read-only cache objects) is in
.analysis/wechat-42053/mention-cache-adapt.md; 4.2.0.52 keeps the constants that
dev14/dev15 verified in place.
"""
import re
import struct

from ._identity import SHA_42052,SHA_42053,profile_for as identity_profile,read_identity
from .errors import ErrorCode,fail
from .models import DirectorySnapshot,GroupInfo,GroupMember,ContactInfo

# Layout shared by the supported builds. 4.2.0.53 evidence: CacheCenter ctor
# 0xe9bd90 (provider vtable at object +0), context getter 0x355690 (lazy
# shared_ptr at context +0x460), ChatroomCache ctor 0xe9fe90 (LRU at +0x38),
# ContactCache ctor 0xedd100 (map at +0xc8), generated protobuf initializers
# 0xef8721/0xef8757 (member element/table vtables).
CONTEXT_CACHE_GETTER_SLOT=0x38
CONTEXT_PROVIDER_OFFSET=0x460
PROVIDER_REGISTRY_OFFSET=0x90
CHATROOM_LRU_OFFSET=0x38
CACHE_NODE_KEY_OFFSET=0x10
CACHE_NODE_OBJECT_OFFSET=0x30
ROOM_RECORD_ID_OFFSET=0x8
ROOM_MEMBER_CONTAINER_OFFSET=0x60
ROOM_MEMBER_INDEX_OFFSET=0xD0
ROOM_MEMBER_INDEX_COUNT_OFFSET=0x10
CONTACT_MAP_OFFSET=0xC8
CONTACT_NAME_OFFSET=0xD8
CONTACT_REMARK_OFFSET=0x78
# 0x355690 is a lazy getter: when context+0x460 is empty it calls its factory
# (0x355790) and then hands back the shared_ptr. The byte sequence below is the
# exact guard at getter+0x1c for both supported builds; a build where this does
# not match must not be interpreted with these offsets.
CACHE_GETTER_BYTES=bytes.fromhex('48 83 b9 60 04 00 00 00')

CACHE_PROFILES={
    SHA_42052: dict(sha256=SHA_42052,provider_getter=0x355690,provider_vtable=0x9225548,
                    chatroom_vtable=0x92257D8,contact_vtable=0x922BBD8,
                    member_data_vtable=0x922D358,member_vtable=0x922D2C8),
    SHA_42053: dict(sha256=SHA_42053,provider_getter=0x355690,provider_vtable=0x92215B8,
                    chatroom_vtable=0x9221848,contact_vtable=0x9227C58,
                    member_data_vtable=0x92293D8,member_vtable=0x9229348),
}
DEFAULT_CACHE_PROFILE=CACHE_PROFILES[SHA_42052]


def cache_profile_for(sha256: str | None):
    """Return the verified directory-cache profile for an exact build fingerprint."""
    profile=CACHE_PROFILES.get(sha256)
    if profile is None:
        fail(ErrorCode.NOT_ADAPTED,'Directory cache layout is not adapted for this build')
    return profile


class StableReader:
    def __init__(self,read):
        self._read=read;self.observed={};self.total=0
    def read(self,address,size):
        if not 0x10000<=address<0x800000000000 or not 0<size<=1048576 or address+size>=0x800000000000:
            fail(ErrorCode.LAYOUT_NOT_READY,'Cache pointer/budget not ready',retryable=True)
        value=self._read(address,size)
        if len(value)!=size:
            fail(ErrorCode.LAYOUT_NOT_READY,'Cache read incomplete',retryable=True)
        key=(address,size)
        if key in self.observed and self.observed[key]!=value:
            fail(ErrorCode.LAYOUT_NOT_READY,'Cache changed while reading',retryable=True)
        if key not in self.observed:
            self.total+=size
            if self.total>16*1024*1024:
                fail(ErrorCode.LAYOUT_NOT_READY,'Cache exceeds snapshot budget')
        self.observed[key]=value
        return value
    def ptr(self,address):return struct.unpack('<Q',self.read(address,8))[0]
    def string(self,address,limit=256):
        header=self.read(address,32);length,capacity=struct.unpack_from('<QQ',header,16)
        if length>limit or capacity<length or not (capacity==15 or 16<=capacity<=1048576):
            fail(ErrorCode.LAYOUT_MISMATCH,'Cache string layout mismatch')
        if not length:return ''
        data=self.read(address if capacity==15 else struct.unpack_from('<Q',header)[0],length)
        try:value=data.decode('utf-8')
        except UnicodeError:fail(ErrorCode.LAYOUT_MISMATCH,'Cache string encoding mismatch')
        if any(ord(c)<32 or ord(c)==127 for c in value):
            fail(ErrorCode.LAYOUT_MISMATCH,'Cache string contains invalid control bytes')
        return value
    def verify(self):
        for (address,size),value in reversed(tuple(self.observed.items())):
            if self._read(address,size)!=value:
                fail(ErrorCode.LAYOUT_NOT_READY,'Cache changed during final verification',retryable=True)


def cache_object(reader,base,account,profile,role,key=None):
    if read_identity(reader.read,base,profile['sha256']).wxid!=account:
        fail(ErrorCode.ACCOUNT_CHANGED,'Cache belongs to a different account')
    identity=identity_profile(profile['sha256'])
    context=reader.ptr(reader.ptr(base+identity['app_global'])+0x68)
    getter=profile['provider_getter']
    if (reader.ptr(reader.ptr(context)+CONTEXT_CACHE_GETTER_SLOT)!=base+getter or
            reader.read(base+getter+28,8)!=CACHE_GETTER_BYTES):
        fail(ErrorCode.LAYOUT_MISMATCH,'Cache provider getter mismatch')
    provider=reader.ptr(context+CONTEXT_PROVIDER_OFFSET)
    if reader.ptr(provider)!=base+profile['provider_vtable']:
        fail(ErrorCode.LAYOUT_NOT_READY,'Cache provider is not initialized',retryable=True)
    head,count=struct.unpack('<QQ',reader.read(provider+PROVIDER_REGISTRY_OFFSET,16))
    if not 1<=count<=512:fail(ErrorCode.LAYOUT_NOT_READY,'Cache registry count invalid')
    current=reader.ptr(head);seen=set();matches=[]
    for _ in range(count):
        if current==head or current in seen:fail(ErrorCode.LAYOUT_NOT_READY,'Cache registry changed')
        seen.add(current);obj=reader.ptr(current+CACHE_NODE_OBJECT_OFFSET)
        if obj and reader.ptr(obj)==base+profile[role]:
            if key is not None and reader.string(current+CACHE_NODE_KEY_OFFSET,64)!=key:fail(ErrorCode.LAYOUT_MISMATCH,'Cache key mismatch')
            matches.append(obj)
        current=reader.ptr(current)
    if current!=head or len(matches)!=1:fail(ErrorCode.LAYOUT_NOT_READY,'No unique requested cache')
    return matches[0]


def room_records(read,base,account,profile=None):
    profile=profile or DEFAULT_CACHE_PROFILE
    reader=StableReader(read)
    cache=cache_object(reader,base,account,profile,'chatroom_vtable','ChatroomCache')
    head,count=struct.unpack('<QQ',reader.read(cache+CHATROOM_LRU_OFFSET,16))
    if count>10000:fail(ErrorCode.LAYOUT_NOT_READY,'Room cache exceeds budget')
    current=reader.ptr(head);seen=set();records={}
    for _ in range(count):
        if current==head or current in seen:fail(ErrorCode.LAYOUT_NOT_READY,'Room list changed')
        seen.add(current);next_node,previous=struct.unpack('<QQ',reader.read(current,16))
        if reader.ptr(previous)!=current or reader.ptr(next_node+8)!=current:fail(ErrorCode.LAYOUT_NOT_READY,'Room links changed')
        room=reader.string(current+CACHE_NODE_KEY_OFFSET,127);record=reader.ptr(current+CACHE_NODE_OBJECT_OFFSET)
        if (not re.fullmatch(r'[a-zA-Z0-9_.-]+@chatroom',room) or
                reader.string(record+ROOM_RECORD_ID_OFFSET,127)!=room or room in records):
            fail(ErrorCode.LAYOUT_MISMATCH,'Room record identity mismatch')
        records[room]=record;current=next_node
    if current!=head:fail(ErrorCode.LAYOUT_NOT_READY,'Room count changed')
    return reader,records


def contacts(read,base,account,profile=None):
    profile=profile or DEFAULT_CACHE_PROFILE
    reader=StableReader(read)
    cache=cache_object(reader,base,account,profile,'contact_vtable')
    layout=reader.read(cache+CONTACT_MAP_OFFSET,0x40)
    head,count,buckets,end,capacity,mask,bucket_count=struct.unpack_from('<7Q',layout,8)
    if count>10000 or not 1<=mask<=65535 or (mask+1)&mask or bucket_count!=mask+1 or end-buckets!=bucket_count*16 or capacity<end:
        fail(ErrorCode.LAYOUT_NOT_READY,'Contact cache container is not ready')
    current=reader.ptr(head);seen=set();result=[]
    for _ in range(count):
        if current==head or current in seen:fail(ErrorCode.LAYOUT_NOT_READY,'Contact links changed')
        seen.add(current);following,previous=struct.unpack('<QQ',reader.read(current,16))
        if reader.ptr(previous)!=current or reader.ptr(following+8)!=current:fail(ErrorCode.LAYOUT_NOT_READY,'Contact links changed')
        wxid=reader.string(current+CACHE_NODE_KEY_OFFSET,127);record=reader.ptr(current+CACHE_NODE_OBJECT_OFFSET)
        if not re.fullmatch(r'[a-zA-Z0-9_.@-]{1,127}',wxid) or reader.string(record+ROOM_RECORD_ID_OFFSET,127)!=wxid:
            fail(ErrorCode.LAYOUT_MISMATCH,'Contact identity mismatch')
        result.append(ContactInfo(wxid,reader.string(record+CONTACT_NAME_OFFSET,256) or None,
                                  reader.string(record+CONTACT_REMARK_OFFSET,1024) or None))
        current=following
    if current!=head:fail(ErrorCode.LAYOUT_NOT_READY,'Contact count changed')
    if len({c.wxid for c in result})!=len(result):fail(ErrorCode.LAYOUT_MISMATCH,'Duplicate contact IDs')
    reader.verify()
    return DirectorySnapshot(tuple(sorted(result,key=lambda row:row.wxid)))


def groups(read,base,account,profile=None):
    profile=profile or DEFAULT_CACHE_PROFILE
    reader,records=room_records(read,base,account,profile);reader.verify()
    return DirectorySnapshot(tuple(GroupInfo(room) for room in sorted(records)))


def members(read,base,account,room,profile=None):
    profile=profile or DEFAULT_CACHE_PROFILE
    reader,records=room_records(read,base,account,profile)
    if room not in records:fail(ErrorCode.LAYOUT_NOT_READY,'Room is not loaded in the cache',retryable=True)
    record=records[room]
    table,array,count,allocated,capacity=struct.unpack_from('<QQiii',reader.read(record+ROOM_MEMBER_CONTAINER_OFFSET,32))
    if table!=base+profile['member_data_vtable'] or not 1<=count<=allocated<=capacity<=2000:
        fail(ErrorCode.LAYOUT_NOT_READY,'Member list is not stable',retryable=True)
    if struct.unpack_from('<Q',reader.read(record+ROOM_MEMBER_INDEX_OFFSET,0x38),ROOM_MEMBER_INDEX_COUNT_OFFSET)[0]!=count:
        fail(ErrorCode.LAYOUT_NOT_READY,'Member index is rebuilding',retryable=True)
    pointers=struct.unpack('<'+'Q'*count,reader.read(array,count*8));result=[];seen=set()
    if len(set(pointers))!=count:fail(ErrorCode.LAYOUT_MISMATCH,'Duplicate member pointers')
    for pointer in pointers:
        table,identity,name=struct.unpack('<QQQ',reader.read(pointer,24))
        if table!=base+profile['member_vtable']:fail(ErrorCode.LAYOUT_MISMATCH,'Member protobuf table mismatch')
        wxid=reader.string(identity,127)
        if not re.fullmatch(r'[a-zA-Z0-9_.@-]{1,127}',wxid) or wxid.endswith('@chatroom') or wxid in seen:fail(ErrorCode.LAYOUT_MISMATCH,'Member identity mismatch')
        seen.add(wxid)
        # member+0x18 is the inviter field in 4.2.0.53 (a third string added
        # after the 4.2.0.52 identity/name pair); it is never read as the
        # member's own name or identity.
        nickname=reader.string(name,256) if name else None
        result.append(GroupMember(wxid,nickname or None))
    if account not in seen:fail(ErrorCode.LAYOUT_NOT_READY,'Own membership is missing',retryable=True)
    reader.verify()
    return DirectorySnapshot(tuple(sorted(result,key=lambda row:row.wxid)))


def inspect_cache(pid,account,room=None,*,directory=False):
    from .discovery import inspect_process
    from ._win32 import Reader,modules
    result=inspect_process(pid)
    if result.error:fail(result.error,result.detail)
    # Cache container addresses/vtables are independently mapped per build;
    # only builds with that evidence have a profile. Never reinterpret a newer
    # build with an older build's cache layout.
    if result.build is None:
        fail(ErrorCode.NOT_ADAPTED,'Directory cache layout is not adapted for this build')
    profile=cache_profile_for(result.build.sha256)
    if account is not None and result.account.wxid!=account:fail(ErrorCode.ACCOUNT_CHANGED,'Selected account changed')
    with Reader(pid) as process:
        if process.created()!=result.process_created:fail(ErrorCode.PROCESS_EXITED,'Process identity changed')
        core=modules(pid)['weixin.dll']
        if directory:
            snapshot=contacts(process.read,core[0],result.account.wxid,profile)
        else:
            snapshot=(groups(process.read,core[0],result.account.wxid,profile) if room is None
                      else members(process.read,core[0],result.account.wxid,room,profile))
            from dataclasses import replace
            from .errors import FrameworkError
            try:
                names={r.wxid:r for r in contacts(process.read,core[0],result.account.wxid,profile).records}
            except FrameworkError:
                names={}
            snapshot=replace(snapshot,records=tuple((replace(row,name=names[row.wxid].wechat_name) if isinstance(row,GroupInfo)
                else replace(row,wechat_name=names[row.wxid].wechat_name,remark=names[row.wxid].remark))
                if row.wxid in names else row for row in snapshot.records))
        if (modules(pid).get('weixin.dll')!=core or
                read_identity(process.read,core[0],result.build.sha256)!=result.account):
            fail(ErrorCode.ACCOUNT_CHANGED,'Cache account/module changed')
        return snapshot
