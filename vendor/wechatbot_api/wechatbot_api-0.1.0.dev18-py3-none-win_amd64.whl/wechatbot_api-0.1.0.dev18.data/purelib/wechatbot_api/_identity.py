"""Build-specific read-only layout; derived from helper with new structural evidence.

The identity chain is: application global -> app object (vtable) -> account
context (shared_ptr at app+0x68) -> context vtable slot +0x18 (identity getter)
-> String at context+0x48. Every address below is an RVA in the exact target
build; a build without a verified profile is rejected instead of reusing another
build's layout. Evidence for 4.2.0.53 is in .analysis/wechat-42053/readapt.md.
"""
import re
import struct
from collections.abc import Callable

from .errors import ErrorCode, FrameworkError, fail
from .models import Account

SHA_42052 = 'd733489eea0b62af77e1aa61ba645cd941583d2a64fb2d7572da818d285f8d84'
SHA_42053 = 'ac6b174d98ee1b69e95c99a7a39c3197c8c167b7c6d32f5b72c7a7659c104825'
DEFAULT_PROFILE = SHA_42052
IDENTITY_GETTER = 0x358810
IDENTITY_GETTER_BYTES = b'\x48\x8d\x41\x48\xc3'
PROFILES = {
    SHA_42052: dict(app_global=0xBB6F788, app_table=0x901F0E8, context_table=0x90D0CC8,
                    app_getter=0x20920, identity_getter=IDENTITY_GETTER),
    SHA_42053: dict(app_global=0xBB6B788, app_table=0x901B0E8, context_table=0x90CCCB8,
                    app_getter=0x20920, identity_getter=IDENTITY_GETTER),
}
# Backward-compatible aliases for the default (4.2.0.52) profile.
APP_GLOBAL = PROFILES[DEFAULT_PROFILE]['app_global']
APP_TABLE = PROFILES[DEFAULT_PROFILE]['app_table']
CONTEXT_TABLE = PROFILES[DEFAULT_PROFILE]['context_table']
APP_GETTER = PROFILES[DEFAULT_PROFILE]['app_getter']


def profile_for(sha256: str | None):
    """Return the verified read-only profile for an exact build fingerprint."""
    profile = PROFILES.get(sha256) if sha256 else PROFILES[DEFAULT_PROFILE]
    if profile is None:
        fail(ErrorCode.UNSUPPORTED_BUILD, 'No read-only identity profile for this build')
    return profile


def read_identity(read_memory: Callable[[int, int], bytes], base: int,
                  sha256: str | None = None) -> Account:
    profile = profile_for(sha256)
    app_global, app_table = profile['app_global'], profile['app_table']
    context_table = profile['context_table']
    app_getter, identity_getter = profile['app_getter'], profile['identity_getter']
    observed = {}

    def read(address, size):
        if not 0x10000 <= address < 0x800000000000 or address + size >= 0x800000000000:
            fail(ErrorCode.LAYOUT_NOT_READY, 'Identity pointer is not ready', retryable=True)
        data = read_memory(address, size)
        if len(data) != size:
            fail(ErrorCode.LAYOUT_NOT_READY, 'Short identity read', retryable=True)
        key = (address, size)
        if key in observed and observed[key] != data:
            fail(ErrorCode.LAYOUT_NOT_READY, 'Identity changed during read', retryable=True)
        observed[key] = data
        return data

    def ptr(address):
        return struct.unpack('<Q', read(address, 8))[0]

    app = ptr(base + app_global)
    if not app:
        fail(ErrorCode.LAYOUT_NOT_READY, 'Application object is not initialized', retryable=True)
    if ptr(app) != base + app_table or ptr(base + app_table + 0x60) != base + app_getter:
        fail(ErrorCode.LAYOUT_MISMATCH, 'Application object/vtable mismatch')
    context = ptr(app + 0x68)
    if not context:
        fail(ErrorCode.LAYOUT_NOT_READY, 'Account context is not initialized', retryable=True)
    if ptr(context) != base + context_table or ptr(base + context_table + 0x18) != base + identity_getter:
        fail(ErrorCode.LAYOUT_MISMATCH, 'Identity context/vtable mismatch')
    if read(base + identity_getter, 5) != IDENTITY_GETTER_BYTES:
        fail(ErrorCode.LAYOUT_MISMATCH, 'Identity getter instruction mismatch')

    def string(address, limit, encoding):
        header = read(address, 32)
        length, capacity = struct.unpack_from('<QQ', header, 16)
        if length > limit or capacity < length or not (capacity == 15 or 16 <= capacity <= 1048576):
            fail(ErrorCode.LAYOUT_MISMATCH, 'Invalid identity string layout')
        if length == 0:
            return ''
        buffer = address if capacity == 15 else struct.unpack_from('<Q', header)[0]
        try:
            return read(buffer, length).decode(encoding)
        except UnicodeError:
            fail(ErrorCode.LAYOUT_MISMATCH, 'Invalid identity string encoding')

    wxid = string(context + 0x48, 127, 'ascii')
    if not wxid:
        fail(ErrorCode.NOT_LOGGED_IN, 'Identity has no logged-in account', retryable=True)
    if not re.fullmatch(r'[a-zA-Z0-9_.-]{1,127}', wxid) or wxid in ('filehelper', 'fmessage') or wxid.startswith('gh_'):
        fail(ErrorCode.LAYOUT_MISMATCH, 'Identity is not a personal account')
    # The new build's display-name field has not been proven; never reuse +0x88.
    for (address, size), data in reversed(tuple(observed.items())):
        if read_memory(address, size) != data:
            fail(ErrorCode.LAYOUT_NOT_READY, 'Identity changed during verification', retryable=True)
    return Account(wxid)
