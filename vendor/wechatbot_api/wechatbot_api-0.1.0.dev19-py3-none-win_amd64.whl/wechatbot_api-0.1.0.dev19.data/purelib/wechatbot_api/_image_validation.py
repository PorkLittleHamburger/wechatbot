"""Verify image structure and decode bounded pixels before declaring ready."""
import os
import warnings
import struct,zlib
from .errors import ErrorCode,fail
from ._media_diagnostics import MediaCopyError
from ._rich.images import MAX_IMAGE_BYTES

MAX_PIXELS=32_000_000
MAX_FRAME_PIXELS=64_000_000
MAX_FRAMES=256
SUPPORTED_FORMATS=('PNG','JPEG','GIF','WEBP')
# Private key used only between validate_image() and _copy_result(); it is popped
# before the ready media_metadata snapshot is published.
CONTAINER_TRAILING_KEY='_container_trailing'


def validate_image(path):
    """Return decoded metadata or raise a stage-tagged MediaCopyError.

    Strictness is unchanged for format/pixel/frame budgets, PNG chunk bounds and
    CRCs, and JPEG end-marker presence. A complete container followed by
    trailing bytes is accepted by the container verifiers; the caller reports
    that fact in the successful detail and keeps the byte-identical copy.
    """
    try:
        from PIL import Image,ImageFile,__version__ as pillow_version
    except ImportError:
        fail(ErrorCode.DEPENDENCY_MISSING,'Strict media decoding requires the pinned Pillow runtime dependency')
    if ImageFile.LOAD_TRUNCATED_IMAGES:
        raise MediaCopyError('truncated_global',pillow=pillow_version)
    try:
        return _decode(path,Image,pillow_version)
    except MediaCopyError as error:
        error.fields.setdefault('pillow',pillow_version)
        raise
    except Exception as error:
        # Codec syntax errors, decompression limits and truncated streams share
        # this bounded failure path; only the exception class name is exposed.
        raise MediaCopyError('decode_failed',pillow=pillow_version,decoder=type(error).__name__) from None


def _annotate(error,base):
    for key,value in base.items():error.fields.setdefault(key,value)


def _decode(path,Image,pillow_version):
    trailing=0
    with warnings.catch_warnings():
        warnings.simplefilter('error',Image.DecompressionBombWarning)
        with Image.open(path) as image:
            width,height=image.size;format=image.format
            base={'format':format,'width':width,'height':height,'pillow':pillow_version}
            if format not in SUPPORTED_FORMATS or width<1 or height<1:
                raise MediaCopyError('decode_format',**base)
            pixels=width*height
            if pixels>MAX_PIXELS:
                raise MediaCopyError('decode_pixels',**base,pixels=pixels)
            if format=='PNG':
                try:trailing=_verify_png(path)
                except MediaCopyError as error:_annotate(error,base);raise
            elif format=='JPEG':
                try:trailing=_verify_jpeg(path)
                except MediaCopyError as error:_annotate(error,base);raise
            try:
                image.verify()
            except Exception as error:
                raise MediaCopyError('decode_failed',**base,decoder=type(error).__name__) from None
        # verify() checks structure/CRC but does not decode pixel data. Reopen
        # and force every accepted frame through its decoder as a second gate.
        count=0;decoded_pixels=0
        with Image.open(path) as image:
            while True:
                try:image.seek(count)
                except EOFError:break
                w,h=image.size;decoded_pixels+=w*h;count+=1
                if count>MAX_FRAMES or decoded_pixels>MAX_FRAME_PIXELS or w*h>MAX_PIXELS:
                    raise MediaCopyError('decode_frames',format=format,width=width,height=height,
                        frames=count,pixels=decoded_pixels,pillow=pillow_version)
                try:image.load()
                except Exception as error:
                    raise MediaCopyError('decode_failed',format=format,width=width,height=height,
                        frames=count,pillow=pillow_version,decoder=type(error).__name__) from None
    if count<1:
        raise MediaCopyError('decode_failed',format=format,width=width,height=height,
            frames=0,pillow=pillow_version,decoder='NoFrames')
    metadata={'format':format,'width':width,'height':height,'frames':count}
    if trailing:metadata[CONTAINER_TRAILING_KEY]=trailing
    return metadata


def _verify_png(path):
    # Pillow can decode pixels despite a truncated IEND checksum. Require the
    # complete bounded container as well, including every chunk CRC and a
    # present IEND. Bytes after a valid IEND are tolerated: the container is
    # complete, and a polyglot tail would still have to pass every chunk CRC.
    with open(path,'rb') as stream:
        if stream.read(8)!=b'\x89PNG\r\n\x1a\n':raise MediaCopyError('png_signature')
        total=8;count=0;seen_data=False
        while True:
            position=stream.tell();raw=stream.read(8)
            if not raw:raise MediaCopyError('png_iend_missing',offset=position)
            if len(raw)!=8:raise MediaCopyError('png_chunk_header',offset=position)
            length,kind=struct.unpack('>I4s',raw);total+=length+12;count+=1
            if total>MAX_IMAGE_BYTES or count>100000 or (count==1 and (kind!=b'IHDR' or length!=13)):
                raise MediaCopyError('png_structure',offset=position)
            crc=zlib.crc32(kind);remaining=length
            while remaining:
                block=stream.read(min(remaining,1024*1024))
                if not block:raise MediaCopyError('png_chunk_bounds',offset=stream.tell())
                crc=zlib.crc32(block,crc);remaining-=len(block)
            position=stream.tell();stored=stream.read(4)
            if len(stored)!=4 or struct.unpack('>I',stored)[0]!=(crc&0xffffffff):
                raise MediaCopyError('png_crc',offset=position)
            seen_data|=kind==b'IDAT'
            if kind==b'IEND':
                if length or not seen_data:raise MediaCopyError('png_structure',offset=position)
                return max(0,os.fstat(stream.fileno()).st_size-total)


def _verify_jpeg(path):
    # The old check only looked at the last two bytes, which rejects a complete
    # JPEG followed by trailing bytes and cannot distinguish that from a
    # truncated stream. Walk the marker structure instead: require a real EOI at
    # a segment boundary; bytes after it are tolerated.
    payload=path.read_bytes();size=len(payload)
    if not payload.startswith(b'\xff\xd8'):raise MediaCopyError('jpeg_eoi_missing',offset=0)
    position=2
    while True:
        if position+1>=size:raise MediaCopyError('jpeg_eoi_missing',offset=position)
        if payload[position]!=0xff:raise MediaCopyError('jpeg_eoi_missing',offset=position)
        while position+1<size and payload[position+1]==0xff:position+=1
        if position+1>=size:raise MediaCopyError('jpeg_eoi_missing',offset=position)
        marker=payload[position+1]
        if marker==0xd9:return size-(position+2)
        if marker in (0x01,0xd8) or 0xd0<=marker<=0xd7:
            position+=2;continue
        if position+4>size:raise MediaCopyError('jpeg_eoi_missing',offset=position)
        length=int.from_bytes(payload[position+2:position+4],'big')
        if length<2 or position+2+length>size:
            raise MediaCopyError('jpeg_eoi_missing',offset=position)
        position+=2+length
        if marker==0xda:
            # Entropy-coded scan: a marker is 0xFF followed by a non-zero,
            # non-RST byte; 0x00 is byte stuffing and D0-D7 are restart markers.
            while True:
                found=payload.find(b'\xff',position)
                if found<0 or found+1>=size:
                    raise MediaCopyError('jpeg_eoi_missing',offset=position)
                following=payload[found+1]
                if following==0x00 or 0xd0<=following<=0xd7:
                    position=found+2;continue
                if following==0xff:
                    position=found+1;continue
                position=found;break
