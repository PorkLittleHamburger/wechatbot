"""Sanitized, bounded diagnostics for native media copy/validation failures.

A copy/validation failure still maps to ``NATIVE_FAILURE``; this module only
enriches the public informational text (``OperationResult.detail`` and the
correlated ``media_update`` reason) with a stable stage token and a bounded,
allow-listed set of counters. It is the difference between "something in the
copy path failed" and a diagnosable stage without capturing image bytes again.

Security rules enforced here:

- Every field is rendered from an allow-list; unknown keys are dropped, so a
  future caller cannot leak a credential/URL/path through this channel.
- ``header`` is at most the first 16 bytes rendered as lowercase hex.
- No filekey/aeskey/CDN URL/XML/notification text/account/group/path is ever
  accepted. Enumerations are fixed tokens; integers are range checked.
- The final string is single line and bounded to ``DETAIL_LIMIT`` characters.

Stage tokens are part of the SDK's documented diagnostics vocabulary; see
``docs/IMAGE_RECEIVE_DIAGNOSTICS.md``.
"""
from __future__ import annotations

import re

DETAIL_PREFIX = 'SDK media copy or validation failed'
DETAIL_LIMIT = 512

_HEIF_BRANDS = frozenset(
    (b'heic', b'heix', b'hevc', b'hevx', b'heim', b'heis', b'mif1', b'mif2',
     b'msf1', b'avif', b'avis'))
_QUALITIES = frozenset(('original', 'standard', 'thumbnail', 'unknown'))
_REFS = frozenset(('cdnbigimgurl', 'cdnmidimgurl', 'filekey', 'cdnthumburl', 'unknown'))
_KEY_SOURCES = frozenset(('aeskey', 'cdnthumbaeskey', 'unknown'))
_FAMILIES = frozenset(
    ('png', 'jpeg', 'gif', 'webp', 'bmp', 'tiff', 'heif-avif', 'isobmff', 'jxl', 'unknown'))
_STAGE = re.compile(r'[a-z][a-z0-9_]{0,63}\Z')
_FORMAT = re.compile(r'[A-Za-z0-9_.+-]{1,24}\Z')
_DECODER = re.compile(r'[A-Za-z_][A-Za-z0-9_.]{0,31}\Z')
_PILLOW = re.compile(r'[A-Za-z0-9.+_-]{1,24}\Z')
_HEX = re.compile(r'[0-9a-f]{0,32}\Z')

_INT_KEYS = frozenset((
    'bytes', 'maximum', 'offset', 'width', 'height', 'pixels', 'frames',
    'image_type', 'encryver', 'declared_width', 'declared_height',
    'declared_size', 'native_state', 'native_error'))
_BOOL_KEYS = frozenset(('size_match', 'md5_present', 'md5_match', 'truncated_global'))
_ENUM_KEYS = {
    'quality': _QUALITIES,
    'ref': _REFS,
    'key_source': _KEY_SOURCES,
    'family': _FAMILIES,
}
_PATTERN_KEYS = {
    'stage': _STAGE,
    'format': _FORMAT,
    'decoder': _DECODER,
    'pillow': _PILLOW,
    'header': _HEX,
}
_ALLOWED = frozenset(('stage',)) | _INT_KEYS | _BOOL_KEYS | frozenset(_ENUM_KEYS) | frozenset(_PATTERN_KEYS)
_ORDER = (
    'stage', 'bytes', 'maximum', 'offset', 'header', 'family', 'format', 'width',
    'height', 'pixels', 'frames', 'quality', 'image_type', 'ref', 'key_source',
    'encryver', 'declared_width', 'declared_height', 'declared_size', 'size_match',
    'md5_present', 'md5_match', 'truncated_global', 'pillow', 'decoder',
    'native_state', 'native_error')


class MediaCopyError(ValueError):
    """Private stage-tagged copy/validation failure.

    Callers attach bounded public values only. ``describe_copy_failure`` drops
    anything outside its allow-list before the text becomes public.
    """

    def __init__(self, stage, **fields):
        self.stage = stage
        self.fields = fields
        super().__init__(stage)


def header_family(header):
    """Classify the first bytes of a download without trusting an extension."""
    if header.startswith(b'\x89PNG\r\n\x1a\n'):
        return 'png'
    if header.startswith(b'\xff\xd8\xff'):
        return 'jpeg'
    if header.startswith((b'GIF87a', b'GIF89a')):
        return 'gif'
    if len(header) >= 12 and header.startswith(b'RIFF') and header[8:12] == b'WEBP':
        return 'webp'
    if header.startswith(b'BM'):
        return 'bmp'
    if header.startswith((b'II*\x00', b'MM\x00*')):
        return 'tiff'
    if len(header) >= 12 and header[4:8] == b'ftyp':
        return 'heif-avif' if header[8:12] in _HEIF_BRANDS else 'isobmff'
    if header.startswith(b'\xff\x0a'):
        return 'jxl'
    return 'unknown'


def describe_copy_failure(record, *, stage, fields=None, native_state, native_error):
    """Build the bounded public detail/reason for a failed SDK media copy.

    ``record`` is the private media reference; only allow-listed selection
    provenance keys are read from it. ``fields`` is the exception's sanitized
    field dict (byte count, header signature, validation metadata, ...).
    """
    values = {'stage': _stage(stage)}
    for key, value in (fields or {}).items():
        if key in _ALLOWED:
            values.setdefault(key, value)
    for key in ('quality', 'image_type', 'ref', 'key_source', 'encryver',
                'declared_width', 'declared_height'):
        value = record.get(key)
        if value is not None:
            values.setdefault(key, value)
    if 'ref' in record:
        # Image-only environment facts that decide whether strict validation is
        # usable at all; they never identify the message, account or file.
        try:
            from PIL import ImageFile, __version__ as pillow_version
        except ImportError:
            pass
        else:
            values.setdefault('truncated_global', bool(ImageFile.LOAD_TRUNCATED_IMAGES))
            values.setdefault('pillow', pillow_version)
    values['native_state'] = native_state
    values['native_error'] = native_error
    pairs = []
    for key in _ORDER:
        if key not in values:
            continue
        rendered = _render(key, values[key])
        if rendered is not None:
            pairs.append(f'{key}={rendered}')
    text = f'{DETAIL_PREFIX} (' + ' '.join(pairs) + ')'
    if len(text) > DETAIL_LIMIT:
        while pairs and len(f'{DETAIL_PREFIX} (' + ' '.join(pairs) + ' ...)') > DETAIL_LIMIT:
            pairs.pop()
        text = f'{DETAIL_PREFIX} (' + ' '.join(pairs) + ' ...)'
    return text


def _stage(value):
    return value if isinstance(value, str) and _STAGE.fullmatch(value) else 'copy_failed'


def _render(key, value):
    if key in _PATTERN_KEYS:
        return value if isinstance(value, str) and _PATTERN_KEYS[key].fullmatch(value) else None
    if key in _ENUM_KEYS:
        return value if isinstance(value, str) and value in _ENUM_KEYS[key] else None
    if key in _BOOL_KEYS:
        return 'true' if value is True else 'false' if value is False else None
    # bool is an int subclass: require the exact int type so a stray flag cannot
    # be rendered as an unbounded number.
    if type(value) is not int or not 0 <= value <= (1 << 63) - 1:
        return None
    return str(value)
