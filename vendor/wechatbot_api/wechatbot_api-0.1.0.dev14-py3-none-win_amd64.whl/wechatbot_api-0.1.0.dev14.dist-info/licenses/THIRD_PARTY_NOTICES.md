# 第三方来源与归属

原生调度器、共享所有权、小字符串与完成 ABI 实现，以及稳定的只读身份校验，改编自
Prometheus-first/helper：

- 来源：https://github.com/Prometheus-first/helper
- 考察基线：`70110581865f441e11b875e5383279bb7242c8fa`
- 许可证：helper Noncommercial License 1.0，原文完整保留在 LICENSE 中（法律文本不翻译）。
- 原始文件：native/selftest_bridge.cpp、native/text_bridge.cpp、
  wxbot_framework/account.py 与 wxbot_framework/native_profiles.py。

本地改动：独立的有类型包与公开 ABI；以内存中的操作结果替代携带聊天内容的报告文件；
针对 4.2.0.52 的独立分析；只读诊断；专用 owner 线程；事件订阅；以及显式的
“不支持/未验证”能力状态。本发行版并非与 helper API 兼容的分发版；不包含上游插件、
WebUI、客户端 DLL、数据库或凭据。MinHook 1.3.4 源码保留在
native/vendor/minhook-1.3.4，含其 LICENSE.txt 与 AUTHORS.txt；接收 Hook 与实验性
@ Hook 使用它。Bot vendor 的媒体路径/ACL/守护改进中，除下文列出的以外仍属待移植工作。

Bot vendor 的 files.py、local_paths.py、snapshot_access.py 以 _files.py、_local_paths.py、
_snapshot_access.py 私有保留。改动为内部导入与扩展的 UTF-16 长路径 ABI 上限。原始
源文件 SHA-256 分别为：
330133f717c670bde246c9b4c1485bae3bfba58b02a35564241de23acfd3d393、
bffb44c2cd613fed93bed9a225710de457c7c2ac5004b9ed29677bc9ad966e69、
98f914b73d344ca774e14ddca8b03836097a262639e36b614db3a78818bd8b18。
私有快照保留同用户读/遍历 ACL 修复、扩展本地路径、稳定文件复制校验与清理边界。
原生图片暂存/Qt ABI 参考 helper native/image_send.h；4.2.0.52 的地址均独立定位。

Bot vendor 的 voices.py 以 _voices.py 私有保留（源文件 SHA-256
80a7bbfca2d222d514d4feb7cf68caf7bf9ca5b6f2acc8dfc2a6c5bf70b379c3），改动为内部导入、
UTF-16 长路径与有类型的“缺少编码器”错误。保留其 WAV 末帧填充、标准/Tencent SILK
归一化与包边界处理。可选依赖 silk-python 0.2.9 作为独立依赖安装，不 vendored；
API/许可证来源：https://pypi.org/project/silk-python/ 。原生语音工厂/借用字符串/
选项所有权参考 helper voice_send.h，当前构建地址独立定位并做内容复制校验。

Bot vendor 的 videos.py 以 _videos.py 私有保留，仅改动内部导入；源文件 SHA-256
1cfd628ea240a81299100972b04749a0a8de8fb94beb3503a63f6296732e47cc。
它解析有界 MP4 box 与时长，不依赖外部探测程序。原生视频使用在 4.2.0.52 中独立确认的
当前工厂/类型/时长/标志路径；不使用旧构建的视频地址兜底。

私有 `_rich` 解析器保留 Bot 的有界引用/递归转发改动；源哈希和提取细节见
docs/rich-provenance.json。图片元数据模块只包含元数据解析，不含图片存储/下载器。

Bot 只读参考按其真实 vendor 源记录固定，而不当作未改动的上游 checkout。不修改 Bot
源码，运行时也不依赖 Bot。第三方 Python 构建/分析/测试依赖保留各自许可证；它们不是
运行时包依赖。

Pillow 13.0.0 是单独安装的固定运行时依赖，不 vendored；它在 ready 事件交付前校验并
完整解码收到的图片。其 HPND 许可与第三方编解码声明随其 wheel 提供；项目源码：
https://github.com/python-pillow/Pillow 。原生图片下载请求/Shared 所有权与自有任务
CDN 参数修复参考 helper 的图片下载路径；所有启用的 4.2.0.52 地址与布局均沿着当前
二进制独立确认，不启用旧偏移兜底。已有一次私聊 PNG 字节精确的实机验收；其他场景仍
待验证。

Bot 的 file_metadata.py 元数据解析（FileStore 之前）以私有形式保留在 _rich 下，
MAX_FILE_BYTES 导入重定向到本框架模块。完整原始源文件 SHA-256：
c42054c046a230eecc856aa4dba36f24317a1a5684a6cdfc0f40eff4f9f61eb2。
不复制 Bot 现有 FileStore/下载器。原生 type-5 请求语义在 4.2.0.52 中独立核对；
图片 CDN 修复刻意不适用于独立的框架文件任务前缀。

Bot voice_receiver.py 中纯解析函数 parse_voice_xml/_voice_data 校验逻辑保留在
_voice_validation.py，内部账号/SILK 解析导入有改动；不复制接收器/存储/线程实现。
原始源文件 SHA-256：
009f314e38fbe28e6b452beb07baa2226102c589dca924d1abfa0f04dd3614de。
当前 4.2.0.52 的 AddMsg 缓冲区偏移在 a8a210 区间独立确认；不使用旧 helper 版本门禁
作为证据。完整 WAV 解码使用单独安装的固定 silk-python 包，而非私有编解码器。

Bot 的 video_metadata.py 以私有形式保留在 _rich 下，无功能改动；源文件 SHA-256
dc76fcd75a6f0d4b9fa358452b5f628744057a31f7691e6b1f165c0b6724dd36。
视频 CDN type-4 语义保留自 helper 的显式视频接口；当前 .52 的任务/参数地址独立核对。
PyAV 18.1.0 是单独安装的可选依赖（BSD-3-Clause，含其捆绑的 FFmpeg 声明），不 vendored；
该固定版本支持本框架 Python 3.11 最低版本；源码/发行元数据：
https://pypi.org/project/av/18.1.0/ 。解复用器外部引用控制参考
https://ffmpeg.org/ffmpeg-formats.html 。

Dev10 的富解析器改动保留原始来源证据，同时把公开的非文本引用 XML 替换为结构化快照，
显式表示缺失的身份/正文，区分非转发容器 app 类型，并把嵌套图片元数据绑定到 SDK 私有
选择器。缺失的嵌套内容携带 availability/reason，而不是编造用户文本。不包含任何 Bot
运行时/缓存或协议组件。

Dev11 保留上述来源归属，并用框架拥有的清理注册表包装出站文件/语音生成器；生成器失败
不能丢弃外层目录。失败的发布者清理保留订阅者租约。系统入口解析现在校验完整 owner
模块路径与两个进程中匹配的 x64 PE 身份。保守的可执行返回栈扫描属于新的框架代码，
用独立 DLL 宿主验证，而不是复用旧微信偏移。

Dev14 的离线 guard 夹具（`WCA_GUARD_TEST`）与守护进程属于本框架新代码；测试夹具不
包含微信路径、地址或消息调用，不进入 wheel，生产 DLL 不包含其测试导出。目标构建、
DLL/ABI/SDK/产物哈希与提交的配套关系记录在 docs/ARTIFACTS.json。
