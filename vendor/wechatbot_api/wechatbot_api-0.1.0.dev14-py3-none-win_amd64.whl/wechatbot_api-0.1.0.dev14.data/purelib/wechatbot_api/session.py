from __future__ import annotations

import asyncio
import concurrent.futures as cf
import threading
import logging
import time
from collections.abc import Callable
from dataclasses import replace
from pathlib import Path
from uuid import uuid4
from typing import cast

from .discovery import discover, inspect_process
from .errors import ErrorCode, FrameworkError, fail
from .events import Subscription
from .models import Capability, CapabilityState, DiscoveryResult,DirectorySnapshot,GroupInfo,GroupMember,ContactInfo, Event, OperationResult,SendResult, SendState, SessionStatus

CORE_CAPABILITIES=('text.send','text.receive','group.mention','image.send','image.receive',
    'file.send','file.receive','voice.send','voice.receive','video.send','video.receive',
    'contacts.read','group.members.read','reference.receive','forwarded.receive')


class Client:
    def __init__(self, *, data_root: str | Path | None=None,operation_history: int=1024,max_pending_operations: int=64):
        if type(operation_history) is not int or operation_history<1 or type(max_pending_operations) is not int or max_pending_operations<1:
            raise ValueError('operation_history and max_pending_operations must be positive integers')
        self.data_root=Path(data_root) if data_root else Path.home()/'.wechatbot-api'
        self.operation_history=operation_history;self.max_pending_operations=max_pending_operations

    def discover(self) -> tuple[DiscoveryResult,...]:
        return discover()

    def session(self, *, pid: int, account_id: str | None=None) -> Session:
        return Session(pid=pid,account_id=account_id,data_root=self.data_root,operation_history=self.operation_history,max_pending_operations=self.max_pending_operations)

    def groups(self, *, pid: int, account_id: str | None=None) -> DirectorySnapshot[GroupInfo]:
        from ._cache import inspect_cache
        return inspect_cache(pid,account_id)

    def group_members(self,room: str, *, pid: int, account_id: str | None=None) -> DirectorySnapshot[GroupMember]:
        from ._cache import inspect_cache
        return inspect_cache(pid,account_id,room)

    def contacts(self, *, pid: int, account_id: str | None=None) -> DirectorySnapshot[ContactInfo]:
        from ._cache import inspect_cache
        return inspect_cache(pid,account_id,directory=True)

    def contact(self,wxid: str, *, pid: int, account_id: str | None=None) -> ContactInfo:
        row=next((r for r in self.contacts(pid=pid,account_id=account_id).records if r.wxid==wxid),None)
        if row is None:
            fail(ErrorCode.LAYOUT_NOT_READY,'Contact is not loaded in the cache',retryable=True)
        return row


class Session:
    def __init__(self, *, pid: int, account_id: str | None=None, data_root: Path,operation_history: int=1024,max_pending_operations: int=64):
        if type(pid) is not int or pid<=0:
            raise ValueError('pid must be a positive integer')
        self.pid=pid;self.account_id=account_id;self.data_root=Path(data_root)
        if type(operation_history) is not int or operation_history<1 or type(max_pending_operations) is not int or max_pending_operations<1:
            raise ValueError('operation limits must be positive integers')
        self._history_limit=operation_history;self._pending_limit=max_pending_operations
        self.session_id=uuid4().hex
        self._lock=threading.RLock();self._state='created';self._error=None
        self._worker=cf.ThreadPoolExecutor(max_workers=1,thread_name_prefix='wechatbot-native')
        self._backend=None;self._target=None;self._operations={};self._subscriptions=[]
        self._operation_overrides={}
        self._closing=None
        self._poll_stop=threading.Event();self._poller=None
        self._event_sequence=0
        self._connect_cleanup_thread=None

    def connect(self, *, timeout: float=30, allow_unverified: bool=False, receive: bool=False) -> Session:
        with self._lock:
            if self._state!='created':
                fail(ErrorCode.SESSION_BUSY,'Session is already connecting, connected or closed')
            self._state='connecting'
            future=self._worker.submit(self._connect,allow_unverified,receive)
        try:
            future.result(timeout)
        except cf.TimeoutError:
            # Initialization retains its owner; close is queued behind it.
            try:
                self.close(timeout=0)
            except FrameworkError:
                pass
            self._start_connect_cleanup()
            fail(ErrorCode.RESULT_UNKNOWN,'Connection is still completing',retryable=False)
        except Exception as error:
            self._invalidate(error.code if isinstance(error,FrameworkError) else ErrorCode.NATIVE_FAILURE)
            self._start_connect_cleanup()
            raise
        return self

    def _start_connect_cleanup(self):
        with self._lock:
            if self._connect_cleanup_thread is not None:return
            def finish():
                logged=False
                while True:
                    try:self.close(timeout=None);return
                    except Exception:
                        if not logged:
                            logging.getLogger(__name__).warning('Failed initialization cleanup remains owned; payload omitted')
                            logged=True
                        time.sleep(0.5)
            self._connect_cleanup_thread=threading.Thread(target=finish,name='wechatbot-init-cleanup',daemon=True)
            self._connect_cleanup_thread.start()

    def _connect(self,allow_unverified=False,receive=False):
        from ._native import NativeBackend
        result=inspect_process(self.pid)
        if result.error:
            fail(result.error,result.detail)
        if self.account_id is not None and result.account.wxid!=self.account_id:
            fail(ErrorCode.ACCOUNT_CHANGED,'Selected process belongs to a different account')
        self.account_id=result.account.wxid;self._target=result
        backend=NativeBackend(result,self.data_root,allow_unverified=allow_unverified,receive=receive,session_id=self.session_id,history_limit=self._history_limit)
        self._backend=backend
        backend.connect(self._emit)
        with self._lock:
            if self._state=='connecting':
                self._state='connected'
                if receive:
                    self._poller=threading.Thread(target=self._poll_events,name='wechatbot-poll-scheduler',daemon=True)
                    self._poller.start()

    def _poll_events(self):
        while not self._poll_stop.wait(0.05):
            with self._lock:
                if self._state!='connected':
                    return
                future=self._worker.submit(self._poll_native)
            try:
                future.result()
            except FrameworkError as error:
                self._invalidate(error.code)
                return
            except Exception:
                self._invalidate(ErrorCode.NATIVE_FAILURE)
                return

    def _poll_native(self):
        try:return self._backend.poll()
        except Exception as error:
            self._invalidate(error.code if isinstance(error,FrameworkError) else ErrorCode.NATIVE_FAILURE)
            raise

    def _refresh_native(self,operation_id):
        try:result=self._backend.refresh_operation(operation_id)
        except FrameworkError as error:
            if error.code in (ErrorCode.ACCOUNT_CHANGED,ErrorCode.PROCESS_EXITED,ErrorCode.NOT_LOGGED_IN,ErrorCode.UNSUPPORTED_BUILD):
                self._invalidate(error.code)
            raise
        if result.error in (ErrorCode.ACCOUNT_CHANGED,ErrorCode.PROCESS_EXITED,ErrorCode.NOT_LOGGED_IN,ErrorCode.UNSUPPORTED_BUILD):
            self._invalidate(result.error)
        return result

    def _emit(self,event: Event):
        with self._lock:
            if self._state not in ('connecting','connected') and not (self._state=='closing' and event.kind in ('media_update','diagnostic')):
                self._release_publisher(event.media)
                return False
            self._event_sequence+=1
            event=replace(event,sequence=self._event_sequence)
            subscriptions=tuple(self._subscriptions)
        delivered=False
        try:
            for subscription in subscriptions:
                delivered=subscription._offer(event) or delivered
        finally:
            self._release_publisher(event.media)
        return delivered

    def _release_publisher(self,handle):
        if handle is None:return
        try:handle.release()
        except (OSError,ValueError,FrameworkError):
            # The publisher remains the owner when the final unlink fails.
            # Cleanup must not replace the already determined operation result.
            self._backend._incoming._remember_cleanup(handle.path.parent,handle.path,handle)

    def subscribe(self,callback: Callable[[Event],None] | None=None, *, capacity: int=1024) -> Subscription:
        with self._lock:
            if self._state in ('closing','closed'):
                fail(ErrorCode.SESSION_CLOSED,'Session is closing or closed')
            subscription=Subscription(callback,capacity=capacity)
            self._subscriptions.append(subscription)
            return subscription

    def capabilities(self) -> tuple[Capability,...]:
        return (self._backend.capabilities() if self._backend else tuple(
            Capability(name,CapabilityState.NOT_ADAPTED,'Native adaptation is not enabled') for name in CORE_CAPABILITIES))

    def status(self) -> SessionStatus:
        with self._lock:
            return SessionStatus(self._state,self.account_id,self.pid,self._pending_count(),self._error)

    def _pending_count(self):
        pending={key for key,future in self._operations.items() if not future.done()}
        pending.update(tuple(getattr(self._backend,'_pending_native',{})))
        return len(pending)

    def operation_ids(self) -> tuple[str,...]:
        """Retained operation IDs, including work whose async waiter was cancelled."""
        with self._lock:
            return tuple(self._operations)

    def diagnostics(self) -> dict:
        with self._lock:
            return {'session_id':self.session_id,'state':self._state,'pid':self.pid,
                'callback_errors':sum(s.callback_errors for s in self._subscriptions),
                'dropped_events':sum(s.dropped for s in self._subscriptions),'abi_version':1,
                'retained_operations':len(self._operations),'operation_history_limit':self._history_limit,
                'max_pending_operations':self._pending_limit,
                'pending_media_cleanup':self._backend.pending_media_cleanup() if self._backend and hasattr(self._backend,'pending_media_cleanup') else 0,
                'watchdog':self._backend.watchdog_diagnostics() if self._backend and hasattr(self._backend,'watchdog_diagnostics') else {'state':'not_started'},
                'build':self._target.build.sha256 if self._target else None}

    def _send(self,method: str,*args,timeout: float=30) -> OperationResult:
        operation_id=uuid4().hex
        with self._lock:
            if self._state!='connected':
                fail(ErrorCode.SESSION_CLOSED,'Session is not connected')
            if self._pending_count()>=self._pending_limit:
                fail(ErrorCode.SESSION_BUSY,'Pending operation queue is full; task was not submitted',retryable=True)
            future=self._worker.submit(self._execute,operation_id,method,args)
            self._operations[operation_id]=future
            future.add_done_callback(lambda _:self._trim_history())
        try:
            return future.result(timeout)
        except cf.TimeoutError:
            return SendResult(operation_id,SendState.UNKNOWN,ErrorCode.RESULT_UNKNOWN,detail='Wait timed out; operation remains owned; do not resend')
        except cf.CancelledError:
            return SendResult(operation_id,SendState.FAILED,ErrorCode.SESSION_CLOSED,detail='Cancelled before native submission')

    def _trim_history(self):
        with self._lock:
            native_pending=getattr(self._backend,'_pending_native',{})
            completed=[key for key,future in self._operations.items() if future.done() and key not in native_pending]
            for key in completed[:-self._history_limit]:
                self._operations.pop(key,None);self._operation_overrides.pop(key,None)

    def _execute(self,operation_id,method,args):
        with self._lock:
            if self._state!='connected':fail(ErrorCode.SESSION_CLOSED,'Session no longer accepts this queued operation')
        current=inspect_process(self.pid)
        target=self._target
        if current.process_created!=target.process_created:
            self._invalidate(ErrorCode.PROCESS_EXITED)
            fail(ErrorCode.PROCESS_EXITED,'Selected process identity changed')
        if current.error:
            if current.error in (ErrorCode.PROCESS_EXITED,ErrorCode.NOT_LOGGED_IN,ErrorCode.UNSUPPORTED_BUILD,ErrorCode.LAYOUT_MISMATCH):
                self._invalidate(current.error)
            fail(current.error,current.detail)
        if current.account.wxid!=self.account_id or current.build!=target.build:
            self._invalidate(ErrorCode.ACCOUNT_CHANGED)
            fail(ErrorCode.ACCOUNT_CHANGED,'Account or build changed')
        try:
            result=self._backend.send(operation_id,method,*args)
            if result.error in (ErrorCode.ACCOUNT_CHANGED,ErrorCode.PROCESS_EXITED,ErrorCode.NOT_LOGGED_IN,ErrorCode.UNSUPPORTED_BUILD):
                self._invalidate(result.error)
            return result
        except Exception as error:
            if isinstance(error,FrameworkError) and error.code in (ErrorCode.ACCOUNT_CHANGED,ErrorCode.PROCESS_EXITED,ErrorCode.NOT_LOGGED_IN,ErrorCode.UNSUPPORTED_BUILD):
                self._invalidate(error.code)
            if operation_id not in getattr(self._backend,'_pending_native',{}):raise
            # Admission/queries may fail after native ownership was established.
            # Preserve a queryable operation ID rather than a permanently
            # exceptional Future or an implied safe-to-retry send failure.
            cls=OperationResult if method=='media.download' else SendResult
            return cls(operation_id,SendState.UNKNOWN,ErrorCode.RESULT_UNKNOWN,
                detail='Native ownership retained after a transport/query error; query this operation, do not resend')

    def _invalidate(self,error):
        with self._lock:
            self._error=error
            if self._state not in ('closing','closed'):self._state='failed'
            self._poll_stop.set()
            stop=getattr(self._backend,'stop_admission',None)
            if stop:stop()
            for future in tuple(self._operations.values()):future.cancel()

    def operation(self,operation_id: str) -> OperationResult:
        with self._lock:
            if operation_id in self._operation_overrides:
                return self._operation_overrides[operation_id]
            future=self._operations.get(operation_id)
        if future is None:
            fail(ErrorCode.INVALID_ARGUMENT,'Unknown or expired operation ID')
        if not future.done():
            return SendResult(operation_id,SendState.ACCEPTED)
        if future.cancelled():
            return SendResult(operation_id,SendState.FAILED,ErrorCode.SESSION_CLOSED,detail='Cancelled before native submission')
        try:result=future.result()
        except Exception:
            if operation_id not in getattr(self._backend,'_pending_native',{}):raise
            result=OperationResult(operation_id,SendState.UNKNOWN,ErrorCode.RESULT_UNKNOWN,
                detail='Native ownership retained after a prior execution error')
        with self._lock:
            if result.state==SendState.UNKNOWN and self._state=='connected':
                refreshed=self._worker.submit(self._refresh_native,operation_id)
            else:
                refreshed=None
        if refreshed is not None:
            try:
                result=refreshed.result(30)
                if result.error in (ErrorCode.ACCOUNT_CHANGED,ErrorCode.PROCESS_EXITED,ErrorCode.NOT_LOGGED_IN,ErrorCode.UNSUPPORTED_BUILD):
                    self._invalidate(result.error)
                if result.state in (SendState.COMPLETED,SendState.FAILED):
                    with self._lock:self._operation_overrides[operation_id]=result
                return result
            except cf.TimeoutError:return result
            except FrameworkError as error:
                if error.code in (ErrorCode.ACCOUNT_CHANGED,ErrorCode.PROCESS_EXITED,ErrorCode.NOT_LOGGED_IN,ErrorCode.UNSUPPORTED_BUILD):
                    self._invalidate(error.code)
                raise
        return result

    def send_text(self,chat_id: str,text: str, *, timeout: float=30) -> SendResult:
        return cast(SendResult,self._send('text.send',chat_id,text,timeout=timeout))
    def send_at_text(self,chat_id: str,text: str,members: list[str] | tuple[str,...], *, display_names: list[str] | None=None,timeout: float=30) -> SendResult:
        return cast(SendResult,self._send('group.mention',chat_id,text,tuple(members),tuple(display_names) if display_names else None,timeout=timeout))
    def send_image(self,chat_id: str,path: str | Path, *, timeout: float=30) -> SendResult:
        return cast(SendResult,self._send('image.send',chat_id,Path(path),timeout=timeout))
    def send_file(self,chat_id: str,path: str | Path, *, timeout: float=30) -> SendResult:
        return cast(SendResult,self._send('file.send',chat_id,Path(path),timeout=timeout))
    def send_voice(self,chat_id: str,path: str | Path, *, timeout: float=30) -> SendResult:
        return cast(SendResult,self._send('voice.send',chat_id,Path(path),timeout=timeout))
    def send_video(self,chat_id: str,path: str | Path, *, timeout: float=30) -> SendResult:
        return cast(SendResult,self._send('video.send',chat_id,Path(path),timeout=timeout))

    def request_media(self,event: Event, *, media_id: str | None=None,timeout: float=30) -> OperationResult:
        """Request received media; ready files arrive as media_update events."""
        return self._send('media.download',event,media_id,timeout=timeout)

    def cleanup_media(self) -> int:
        """Retry failed private temporary-copy cleanup, including after close."""
        cleanup=getattr(self._backend,'cleanup_media',None)
        remaining=cleanup() if cleanup else 0
        with self._lock:
            if not remaining and self._error==ErrorCode.MEDIA_CLEANUP_PENDING:self._error=None
        return remaining

    def close(self, *, timeout: float | None=30):
        with self._lock:
            retry=(self._closing is not None and self._closing.done() and
                (self._closing.cancelled() or self._closing.exception() is not None))
            if self._closing is None or retry:
                self._state='closing'
                self._poll_stop.set()
                stop=getattr(self._backend,'stop_admission',None)
                if stop:stop()
                for future in tuple(self._operations.values()):
                    future.cancel()
                self._closing=self._worker.submit(self._close_native)
            closing=self._closing
        try:
            closing.result(timeout)
        except cf.TimeoutError:
            with self._lock:self._error=ErrorCode.SHUTDOWN_PENDING
            fail(ErrorCode.SHUTDOWN_PENDING,'Native shutdown is still draining; use wait_closed()',retryable=True)
        # Callback shutdown must not run on the native owner thread. Reentrant
        # close from a callback never attempts to join its own thread.
        for subscription in tuple(self._subscriptions):
            if not subscription.close(timeout=timeout):
                fail(ErrorCode.SHUTDOWN_PENDING,'Event callback is still draining',retryable=True)
        with self._lock:
            self._state='closed'
            if self._error==ErrorCode.SHUTDOWN_PENDING:self._error=None
        self._worker.shutdown(wait=False)
        remaining=self.cleanup_media()
        if remaining:
            with self._lock:self._error=ErrorCode.MEDIA_CLEANUP_PENDING
            fail(ErrorCode.MEDIA_CLEANUP_PENDING,'Session/native closed; private temporary files still need cleanup_media()',retryable=True)

    def _close_native(self):
        if self._backend:
            self._backend.close()
            with self._lock:
                self._operation_overrides.update(getattr(self._backend,'_resolved_native',{}))

    def wait_closed(self, *, timeout: float | None=None):
        self.close(timeout=timeout)

    disconnect=close

    async def aconnect(self, *, timeout: float=30, allow_unverified: bool=False,receive: bool=False):
        return await asyncio.shield(asyncio.to_thread(self.connect,timeout=timeout,allow_unverified=allow_unverified,receive=receive))

    async def asend_text(self,chat_id: str,text: str, *, timeout: float=30):
        return await asyncio.shield(asyncio.to_thread(self.send_text,chat_id,text,timeout=timeout))

    async def asend_at_text(self,chat_id: str,text: str,members, *, display_names=None,timeout: float=30):
        return await asyncio.shield(asyncio.to_thread(self.send_at_text,chat_id,text,members,display_names=display_names,timeout=timeout))

    async def asend_image(self,chat_id: str,path: str | Path, *, timeout: float=30):
        return await asyncio.shield(asyncio.to_thread(self.send_image,chat_id,path,timeout=timeout))

    async def asend_file(self,chat_id: str,path: str | Path, *, timeout: float=30):
        return await asyncio.shield(asyncio.to_thread(self.send_file,chat_id,path,timeout=timeout))

    async def asend_voice(self,chat_id: str,path: str | Path, *, timeout: float=30):
        return await asyncio.shield(asyncio.to_thread(self.send_voice,chat_id,path,timeout=timeout))

    async def asend_video(self,chat_id: str,path: str | Path, *, timeout: float=30):
        return await asyncio.shield(asyncio.to_thread(self.send_video,chat_id,path,timeout=timeout))

    async def arequest_media(self,event: Event, *, media_id: str | None=None,timeout: float=30) -> OperationResult:
        return await asyncio.shield(asyncio.to_thread(self.request_media,event,media_id=media_id,timeout=timeout))

    async def aclose(self, *, timeout: float | None=30):
        return await asyncio.shield(asyncio.to_thread(self.close,timeout=timeout))

    def __enter__(self):
        return self.connect()
    def __exit__(self,*_):
        self.close()
