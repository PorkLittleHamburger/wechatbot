"""Verify image structure and decode bounded pixels before declaring ready."""
import warnings
import struct,zlib
from .errors import ErrorCode,fail
from ._rich.images import MAX_IMAGE_BYTES

MAX_PIXELS=32_000_000
MAX_FRAME_PIXELS=64_000_000
MAX_FRAMES=256


def validate_image(path):
    try:
        from PIL import Image,ImageFile
    except ImportError:
        fail(ErrorCode.DEPENDENCY_MISSING,'Strict media decoding requires the pinned Pillow runtime dependency')
    if ImageFile.LOAD_TRUNCATED_IMAGES:
        raise ValueError('Strict decoder is unavailable while process-wide truncated-image acceptance is enabled')
    try:
        return _decode(path,Image)
    except Exception as error:
        # Codec syntax errors, decompression limits and truncated streams share
        # the same bounded validation failure path; none strands a native Job.
        raise ValueError('Image failed strict structure/pixel decoding') from error


def _decode(path,Image):
    with warnings.catch_warnings():
        warnings.simplefilter('error',Image.DecompressionBombWarning)
        with Image.open(path) as image:
            width,height=image.size;format=image.format
            if format not in ('PNG','JPEG','GIF','WEBP') or width<1 or height<1 or width*height>MAX_PIXELS:
                raise ValueError('Image format or pixel count exceeds decoder contract')
            if format=='PNG':_verify_png(path)
            elif format=='JPEG':
                with open(path,'rb') as stream:
                    stream.seek(-2,2)
                    if stream.read()!=b'\xff\xd9':raise ValueError('JPEG end marker is missing')
            image.verify()
        # verify() checks structure/CRC but does not decode pixel data. Reopen
        # and force every accepted frame through its decoder as a second gate.
        count=0;pixels=0
        with Image.open(path) as image:
            while True:
                try:image.seek(count)
                except EOFError:break
                w,h=image.size;pixels+=w*h;count+=1
                if count>MAX_FRAMES or pixels>MAX_FRAME_PIXELS or w*h>MAX_PIXELS:
                    raise ValueError('Image frames exceed decode budget')
                image.load()
    if count<1:raise ValueError('Image has no decoded frames')
    return {'format':format,'width':width,'height':height,'frames':count}


def _verify_png(path):
    # Pillow can decode pixels despite a truncated IEND checksum. Require the
    # complete bounded container as well, including every chunk CRC and EOF.
    with open(path,'rb') as stream:
        if stream.read(8)!=b'\x89PNG\r\n\x1a\n':raise ValueError('PNG signature invalid')
        total=8;count=0;seen_data=False
        while True:
            raw=stream.read(8)
            if len(raw)!=8:raise ValueError('PNG chunk header truncated')
            length,kind=struct.unpack('>I4s',raw);total+=length+12;count+=1
            if total>MAX_IMAGE_BYTES or count>100000 or (count==1 and (kind!=b'IHDR' or length!=13)):
                raise ValueError('PNG structure exceeds bounds')
            crc=zlib.crc32(kind);remaining=length
            while remaining:
                block=stream.read(min(remaining,1024*1024))
                if not block:raise ValueError('PNG chunk truncated')
                crc=zlib.crc32(block,crc);remaining-=len(block)
            stored=stream.read(4)
            if len(stored)!=4 or struct.unpack('>I',stored)[0]!=(crc&0xffffffff):raise ValueError('PNG chunk CRC invalid')
            seen_data|=kind==b'IDAT'
            if kind==b'IEND':
                if length or not seen_data or stream.read(1):raise ValueError('PNG ending invalid')
                return
