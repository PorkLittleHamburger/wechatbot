"""SDK-owned process-exit guard. Never admits a message or loads a bridge.

Retains helper's file-backed startup diagnostics; see THIRD_PARTY_NOTICES.md.
"""
import argparse
import ctypes as c
from ctypes import wintypes as w
import hashlib
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time
from uuid import uuid4

from .errors import ErrorCode,FrameworkError,fail
from ._win32 import kernel,Reader


def guard_kernel():
    k=kernel()
    declarations={
        'CreateEventW':([c.c_void_p,w.BOOL,w.BOOL,w.LPCWSTR],w.HANDLE),
        'OpenEventW':([w.DWORD,w.BOOL,w.LPCWSTR],w.HANDLE),
        'SetEvent':([w.HANDLE],w.BOOL),'ResetEvent':([w.HANDLE],w.BOOL),
        'OpenMutexW':([w.DWORD,w.BOOL,w.LPCWSTR],w.HANDLE),
        'WaitForSingleObject':([w.HANDLE,w.DWORD],w.DWORD),
        'WaitForMultipleObjects':([w.DWORD,c.POINTER(w.HANDLE),w.BOOL,w.DWORD],w.DWORD),
    }
    for name,(args,result) in declarations.items():
        method=getattr(k,name);method.argtypes=args;method.restype=result
    return k


def checked(value):
    if not value:raise c.WinError(c.get_last_error())
    return value


def process_created(k,handle):
    values=[w.FILETIME() for _ in range(4)]
    checked(k.GetProcessTimes(handle,*(c.byref(value) for value in values)))
    return values[0].dwLowDateTime+(values[0].dwHighDateTime<<32)


def process_alive(k,pid,created):
    """True/False when verified, None when the identity cannot be read."""
    if type(pid) is not int or pid<=0 or type(created) is not int:return None
    handle=k.OpenProcess(0x101000,False,pid)
    if not handle:
        return None if c.get_last_error()==5 else False
    try:
        if process_created(k,handle)!=created:return False
        status=k.WaitForSingleObject(handle,0)
        if status==258:return True
        return False if status==0 else None
    except OSError:return None
    finally:k.CloseHandle(handle)


class Watchdog:
    def __init__(self,pid,created,dll,data_root,manifest):
        self.k=guard_kernel();self.child=None;self.handles={};self.state='created'
        self.lock=threading.RLock();self.journal_warning=None;self.activity_warning=None
        self.directory=Path(data_root).resolve()/'.guards'/uuid4().hex
        self.journal=self.directory/'owner.json';self.startup_log=self.directory/'startup.log'
        self.runtime_log=self.directory/'watchdog.log'
        with Reader(os.getpid()) as reader:owner_created=reader.created()
        from . import __version__
        self.record={'schema':1,'sdk_version':__version__,'owner_pid':os.getpid(),'owner_created':owner_created,
            'pid':pid,'created':created,'dll':str(Path(dll).resolve()),'dll_sha256':manifest['sha256'],
            'bridge_version':manifest['bridge_version'],'data_root':str(Path(data_root).resolve()),
            'operations':[],'snapshots':[]}
        token=uuid4().hex
        self.names={name:'Local\\wechatbot-api-'+name+'-'+token for name in ('stop','ready','active')}

    @property
    def warning(self):return self.activity_warning or self.journal_warning

    def update(self,*,operations=None,snapshots=None):
        with self.lock:
            if operations is not None:self.record['operations']=list(operations)
            if snapshots is not None:self.record['snapshots']=snapshots
            try:
                temporary=self.journal.with_suffix('.tmp')
                temporary.write_text(json.dumps(self.record),encoding='utf-8')
                temporary.replace(self.journal)
                self.journal_warning=None
            except OSError:
                self.journal_warning='Journal update failed; recovery may retain resources'
                logging.getLogger(__name__).error('Watchdog journal update failed; payload omitted')

    def start(self):
        try:self._start()
        except FrameworkError:raise
        except Exception as error:
            self.state='startup_failed'
            try:
                with self.startup_log.open('ab') as output:output.write((type(error).__name__+' watchdog startup failure\n').encode('utf-8'))
            except OSError:pass
            fail(ErrorCode.NATIVE_FAILURE,f'Watchdog startup failed; startup log: {self.startup_log}')

    def _start(self):
        try:reap_stale_guards(Path(self.record['data_root']))
        except (OSError,ValueError,RuntimeError):pass
        self.directory.mkdir(parents=True,exist_ok=False);self.update()
        if self.warning:fail(ErrorCode.NATIVE_FAILURE,'Cannot create watchdog journal')
        for name,value in self.names.items():self.handles[name]=checked(self.k.CreateEventW(None,True,False,value))
        args=[sys.executable,'-B','-X','utf8','-m','wechatbot_api._watchdog','--journal',str(self.journal)]
        for name,value in self.names.items():args+=['--'+name,value]
        # No unread pipes: import/startup failures are captured even before the
        # child's rotating logger exists. No visible console is created.
        with self.startup_log.open('ab') as output:
            self.child=subprocess.Popen(args,stdin=subprocess.DEVNULL,stdout=output,stderr=output,
                creationflags=subprocess.CREATE_NO_WINDOW,close_fds=True)
        # Record the child identity so a later session can distinguish a stale
        # journal from a still-running guard after this owner dies.
        with Reader(self.child.pid) as reader:guard_created=reader.created()
        with self.lock:
            self.record['guard_pid']=self.child.pid;self.record['guard_created']=guard_created
            self.update()
        if self.warning:fail(ErrorCode.NATIVE_FAILURE,f'Cannot persist watchdog guard identity; startup log: {self.startup_log}')
        handles=(w.HANDLE*2)(self.handles['ready'],int(self.child._handle))
        status=self.k.WaitForMultipleObjects(2,handles,False,10000)
        if status!=0:
            self.state='startup_failed'
            fail(ErrorCode.NATIVE_FAILURE,f'Watchdog did not become ready; startup log: {self.startup_log}')
        self.state='ready'

    def begin_call(self):
        checked(self.k.SetEvent(self.handles['active']))

    def end_call(self):
        if not self.k.ResetEvent(self.handles['active']):
            self.activity_warning='ABI activity flag stayed set; recovery will retain the module'
        else:self.activity_warning=None

    def close(self):
        with self.lock:self._close()

    def _close(self):
        if self.handles.get('stop'):checked(self.k.SetEvent(self.handles['stop']))
        if self.child:
            try:self.child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                fail(ErrorCode.SHUTDOWN_PENDING,'Watchdog is still stopping; ownership retained',retryable=True)
            self.child._handle.Close();self.child=None
        for handle in self.handles.values():self.k.CloseHandle(handle)
        self.handles.clear();self.state='stopped'

    def diagnostics(self):
        with self.lock:
            running=self.child is not None and self.child.poll() is None
            return {'state':'exited' if self.state=='ready' and not running else self.state,'running':running,
                'startup_log':str(self.startup_log),'runtime_log':str(self.runtime_log),'warning':self.warning}


class PendingOperations(dict):
    def __init__(self,guard,values):
        super().__init__(values);self.guard=guard;self._notify()
    def _notify(self):self.guard.update(operations=self)
    def __setitem__(self,key,value):super().__setitem__(key,value);self._notify()
    def pop(self,*args):
        value=super().pop(*args);self._notify();return value
    def clear(self):super().clear();self._notify()


def read_journal(path):
    from . import __version__
    path=Path(path)
    if path.stat().st_size>1024*1024:raise ValueError('Guard journal exceeds bounds')
    record=json.loads(path.read_text('utf-8'))
    if record['schema']!=1 or record['sdk_version']!=__version__:raise ValueError('Guard SDK/schema mismatch')
    for field in ('pid','created','owner_pid','owner_created'):
        if type(record[field]) is not int or record[field]<=0:raise ValueError('Invalid guard identity')
    operations=record['operations']
    if not isinstance(operations,list) or len(operations)>4096 or any(not isinstance(value,str) or len(value)!=32 or any(ch not in '0123456789abcdef' for ch in value) for value in operations):
        raise ValueError('Invalid owned operation IDs')
    if not isinstance(record['snapshots'],list) or len(record['snapshots'])>4096:
        raise ValueError('Invalid snapshot journal')
    for item in record['snapshots']:
        if not isinstance(item,dict) or any(not isinstance(item.get(key),str) or '\0' in item[key] or len(item[key])>32767 for key in ('root','owned')):
            raise ValueError('Invalid snapshot path')
    return record


def cleanup_snapshots(record):
    from ._outbound_snapshots import OutboundSnapshots
    from ._local_paths import local_spelling
    data_root=Path(local_spelling(str(Path(record['data_root']).resolve())))
    cleanup=OutboundSnapshots()
    for item in record['snapshots']:
        root=Path(item['root']);owned=Path(item['owned'])
        normal=Path(local_spelling(str(root.resolve())))
        if normal.name!='outbound' or normal.parent.parent!=data_root or owned.parent!=root or not owned.name.startswith('wca-out-'):
            raise ValueError('Snapshot cleanup is outside its registered root')
        cleanup.pending[owned]={'root':root,'owned':owned}
    return cleanup.retry_cleanup()


def updated_journal(path,initial):
    record=read_journal(path)
    for field in ('pid','created','owner_pid','owner_created','dll','dll_sha256','bridge_version','data_root'):
        if record[field]!=initial[field]:raise ValueError('Guard journal immutable identity changed')
    return record


def finish_snapshots(record,logger):
    while cleanup_snapshots(record):
        logger.info('OUTBOUND_CLEANUP_PENDING private snapshots retained')
        time.sleep(2)
    logger.info('RECOVERY_COMPLETE')


def reap_stale_guards(data_root):
    """Clean journals whose owner and guard are both confirmed gone.

    A new session on the same data root performs this bounded scan; a live or
    unverifiable owner/guard is never touched. Cleanup is still lost if no later
    session starts against this data root.
    """
    root=Path(data_root).resolve();guards=root/'.guards'
    if not guards.is_dir():return 0
    k=guard_kernel();removed=0
    for directory in tuple(guards.iterdir()):
        try:
            if not directory.is_dir() or directory.is_symlink():continue
            record=read_journal(directory/'owner.json')
            if Path(record['data_root']).resolve()!=root:continue
            if type(record.get('guard_pid')) is not int or type(record.get('guard_created')) is not int:
                continue
            if process_alive(k,record['owner_pid'],record['owner_created']) is not False:continue
            if process_alive(k,record['guard_pid'],record['guard_created']) is not False:continue
            if cleanup_snapshots(record):continue
            shutil.rmtree(directory)
            removed+=1
        except (OSError,ValueError,KeyError,TypeError,RuntimeError):
            continue
    return removed


def recover(record,target_alive,logger):
    from ._injector import Injector,Request,AbiInfo
    path=Path(record['dll'])
    if hashlib.sha256(path.read_bytes()).hexdigest()!=record['dll_sha256']:raise ValueError('Recovery DLL fingerprint changed')
    transport=Injector.attach_existing(record['pid'],path,record['created'])
    if transport.base:
        info=AbiInfo()
        if transport.call('WcaGetAbi',info) or (info.abi_version,info.request_size,info.bridge_version)!=(1,1312,record['bridge_version']):
            raise ValueError('Recovery ABI mismatch')
        operations=set(record['operations']);pending_logged=False
        while target_alive():
            for operation in tuple(operations):
                request=Request(operation_id=int(operation[:16],16))
                code=transport.call('WcaGetOperation',request)
                if code==7:operations.remove(operation);continue
                if code:raise RuntimeError('Owned operation could not be queried')
                if request.state in (2,3):
                    code=transport.call('WcaReleaseOperation',request)
                    if code==0:operations.remove(operation)
                    elif code!=4:raise RuntimeError('Owned operation release was refused')
            code=transport.call('WcaDrain',Request())
            if code==0:
                transport.unload();logger.info('NATIVE_RECOVERY_COMPLETE');break
            if code!=4:raise RuntimeError('Native drain was refused')
            if not pending_logged:logger.info('NATIVE_SHUTDOWN_PENDING module retained');pending_logged=True
            time.sleep(0.25)
        else:
            if not transport.release_if_exited():raise RuntimeError('Target identity cannot be confirmed exited')
    else:transport.release_handles()
    finish_snapshots(record,logger)


def main():
    parser=argparse.ArgumentParser()
    for name in ('journal','stop','ready','active'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args();journal=Path(args.journal);k=guard_kernel();handles=[];ready_signaled=False
    logger=logging.getLogger('wechatbot_api.watchdog');logger.setLevel(logging.INFO)
    handler=RotatingFileHandler(journal.parent/'watchdog.log',maxBytes=1024*1024,backupCount=2,encoding='utf-8')
    handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'));logger.addHandler(handler)
    try:
        record=read_journal(journal)
        for pid,created in ((record['owner_pid'],record['owner_created']),(record['pid'],record['created'])):
            with Reader(pid) as reader:
                if reader.created()!=created:raise ValueError('Guard process identity changed')
        owner=checked(k.OpenProcess(0x101000,False,record['owner_pid']));handles.append(owner)
        target=checked(k.OpenProcess(0x101000,False,record['pid']));handles.append(target)
        if process_created(k,owner)!=record['owner_created'] or process_created(k,target)!=record['created']:
            raise ValueError('Opened guard process identity changed')
        stop=checked(k.OpenEventW(0x100000,False,args.stop));handles.append(stop)
        ready=checked(k.OpenEventW(2,False,args.ready));handles.append(ready)
        active=checked(k.OpenEventW(0x100000,False,args.active));handles.append(active)
        mutex=checked(k.OpenMutexW(0x100000,False,f"Local\\wechatbot-api-{record['pid']}-{record['created']}"));handles.append(mutex)
        logger.info('WATCHDOG_READY');checked(k.SetEvent(ready));ready_signaled=True
        owner_gone=False
        def finalize():
            finish_snapshots(updated_journal(journal,record),logger)
        def confirmed_dead(handle):
            if k.WaitForSingleObject(handle,0xffffffff)!=0:raise RuntimeError('Guard process exit was not confirmed')
        waiting=(w.HANDLE*3)(stop,target,owner)
        status=k.WaitForMultipleObjects(3,waiting,False,0xffffffff)
        if status==0:
            logger.info('NORMAL_STOP')
            # The owner asked for a normal stop and owns its snapshot cleanup.
            if k.WaitForSingleObject(owner,0)==0:finalize()
            return
        if status==1:
            logger.info('TARGET_EXITED')
            # The module unloaded with the target; only registered snapshot
            # cleanup remains. Keep that responsibility until the owner either
            # acknowledges a normal stop or dies. The owner process object can
            # signal tens of milliseconds after the target one, so wait for it
            # instead of sampling it once.
            remaining=(w.HANDLE*2)(stop,owner)
            result=k.WaitForMultipleObjects(2,remaining,False,0xffffffff)
            if result==0:
                logger.info('NORMAL_STOP')
                if k.WaitForSingleObject(owner,0)==0:finalize()
                return
            if result!=1:raise RuntimeError('Guard wait failed')
            finalize();return
        if status!=2:raise RuntimeError('Guard wait failed')
        owner_gone=True
        logger.info('OWNER_EXITED')
        if k.WaitForSingleObject(active,0)!=258:
            logger.info('ABI_CALL_UNCERTAIN module retained until target exit')
            confirmed_dead(target)
            finalize();return
        def target_alive():
            code=k.WaitForSingleObject(target,0)
            if code not in (0,258):raise RuntimeError('Target liveness cannot be verified')
            return code==258
        if target_alive():recover(updated_journal(journal,record),target_alive,logger)
        else:finalize()
    except Exception as error:
        logger.error('%s error_type=%s payload omitted','RECOVERY_INCOMPLETE' if ready_signaled else 'WATCHDOG_STARTUP_FAILED',type(error).__name__)
        if not ready_signaled:raise
        try:
            # Do not unload or abandon a module that may belong to a live target.
            # When the owner is gone, wait for the target to exit first; otherwise
            # only finalize when both processes are confirmed dead.
            if 'target' in locals() and owner_gone:
                if k.WaitForSingleObject(target,0xffffffff)!=0:raise RuntimeError('Target exit was not confirmed')
                finish_snapshots(updated_journal(journal,record),logger)
            elif 'target' in locals() and k.WaitForSingleObject(target,0)==0 and k.WaitForSingleObject(owner,0)==0:
                finish_snapshots(updated_journal(journal,record),logger)
        except Exception as cleanup_error:
            logger.error('RECOVERY_CLEANUP_FAILED error_type=%s payload omitted',type(cleanup_error).__name__)
    finally:
        for handle in reversed(handles):k.CloseHandle(handle)
        handler.close();logger.removeHandler(handler)


if __name__=='__main__':main()
