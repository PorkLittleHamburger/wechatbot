from __future__ import annotations

import hashlib
import json
import struct
from importlib.resources import files
from pathlib import Path

from .errors import ErrorCode, FrameworkError, fail
from .models import BuildInfo, DiscoveryResult
from ._identity import read_identity


def build_registry():
    return json.loads(files('wechatbot_api').joinpath('data/builds.json').read_text('utf-8'))


def inspect_build(path: Path) -> BuildInfo:
    with path.open('rb') as source:
        dos=source.read(64)
        if len(dos)<64 or dos[:2]!=b'MZ':
            fail(ErrorCode.UNSUPPORTED_BUILD,'Not a PE image')
        source.seek(struct.unpack_from('<I',dos,0x3c)[0])
        header=source.read(24+64)
        if len(header)<88 or header[:4]!=b'PE\0\0':
            fail(ErrorCode.UNSUPPORTED_BUILD,'Invalid PE header')
        machine=struct.unpack_from('<H',header,4)[0]
        timestamp=struct.unpack_from('<I',header,8)[0]
        image_size=struct.unpack_from('<I',header,24+56)[0]
        stat=path.stat();source.seek(0)
        digest=hashlib.file_digest(source,'sha256').hexdigest()
        if path.stat().st_mtime_ns!=stat.st_mtime_ns or path.stat().st_size!=stat.st_size:
            fail(ErrorCode.LAYOUT_NOT_READY,'Core file changed while fingerprinting',retryable=True)
    architecture='x64' if machine==0x8664 else f'pe-{machine:x}'
    row=next((b for b in build_registry()['builds'] if (b['size'],b['sha256'],b['timestamp'],b['image_size'],b['architecture'])==
        (stat.st_size,digest,timestamp,image_size,architecture)),None)
    return BuildInfo(row['version'] if row else 'unknown',architecture,stat.st_size,digest,timestamp,image_size,path,bool(row))


def inspect_process(pid: int) -> DiscoveryResult:
    from ._win32 import Reader, modules
    build=None;created=0
    try:
        with Reader(pid) as process:
            created=process.created()
            before=modules(pid)
            core=before.get('weixin.dll')
            if not core:
                fail(ErrorCode.LAYOUT_NOT_READY,'Core module has not loaded',retryable=True)
            base,loaded_size,path=core
            build=inspect_build(Path(path))
            if not build.recognized:
                fail(ErrorCode.UNSUPPORTED_BUILD,'Core fingerprint has no registered layout')
            loaded=process.read(base,4096)
            nt=struct.unpack_from('<I',loaded,0x3c)[0]
            if (loaded_size,struct.unpack_from('<I',loaded,nt+8)[0],struct.unpack_from('<I',loaded,nt+24+56)[0])!=(
                build.image_size,build.timestamp,build.image_size):
                fail(ErrorCode.UNSUPPORTED_BUILD,'Loaded image differs from the file fingerprint')
            account=read_identity(process.read,base)
            if modules(pid).get('weixin.dll')!=core or not process.alive():
                fail(ErrorCode.PROCESS_EXITED,'Core changed during discovery',retryable=True)
            row=next(b for b in build_registry()['builds'] if b['sha256']==build.sha256)
            return DiscoveryResult(pid,created,build,account,None,'Read-only identity verified',row['bridge_enabled'])
    except FrameworkError as error:
        return DiscoveryResult(pid,created,build,None,error.code,str(error))
    except PermissionError:
        return DiscoveryResult(pid,created,build,None,ErrorCode.ACCESS_DENIED,'Core file access denied')
    except FileNotFoundError:
        return DiscoveryResult(pid,created,build,None,ErrorCode.PROCESS_EXITED,'Core file disappeared')
    except (OSError,struct.error) as error:
        return DiscoveryResult(pid,created,build,None,ErrorCode.LAYOUT_NOT_READY,f'Discovery failed: {type(error).__name__}')


def discover() -> tuple[DiscoveryResult, ...]:
    """Enumerate process/build/identity diagnostics. Never injects or calls WeChat."""
    from ._win32 import candidates
    return tuple(inspect_process(pid) for pid in candidates())
