"""Own snapshot directories independently of one-shot generator contexts."""
import os
from pathlib import Path
import shutil
import stat
import tempfile
import threading

from ._files import _io_path
from ._snapshot_access import grant_snapshot_read


class OutboundSnapshots:
    def __init__(self):
        self.active={};self.pending={};self.lock=threading.RLock()
        self.changed=None

    def _notify(self):
        if self.changed is not None:
            try:self.changed()
            except Exception:
                import logging
                logging.getLogger(__name__).error('Snapshot recovery journal update failed; payload omitted')

    def prepare(self,operation_id,prepare,path,directory):
        root=_io_path(Path(directory).resolve())
        root.mkdir(parents=True,exist_ok=True)
        owned=Path(tempfile.mkdtemp(prefix='wca-out-',dir=root))
        # Register before calling any fallible preparation or ACL operation.
        record={'root':root,'owned':owned,'context':None}
        with self.lock:self.active[operation_id]=record;self._notify()
        try:
            grant_snapshot_read(owned)
            context=prepare(path,owned)
            record['context']=context
            return context.__enter__()
        except BaseException:
            self.release(operation_id)
            raise

    def release(self,operation_id):
        with self.lock:
            record=self.active.pop(operation_id,None)
            if record is None:return
            # Generator __exit__ cannot be retried after its finally raises.
            # The independent outer directory survives that failure.
            self.pending[record['owned']]=record
            self._notify()
            context=record.pop('context',None)
            if context is not None:
                try:context.__exit__(None,None,None)
                except (OSError,ValueError,RuntimeError):pass
            self.retry_cleanup()

    @staticmethod
    def _check_tree(path):
        # Do not traverse any replaced directory/junction during recursive cleanup.
        for entry in os.scandir(path):
            info=entry.stat(follow_symlinks=False)
            if stat.S_ISLNK(info.st_mode) or getattr(info,'st_file_attributes',0)&0x400:
                raise ValueError('Snapshot tree contains a redirected path')
            if stat.S_ISDIR(info.st_mode):OutboundSnapshots._check_tree(entry.path)

    def retry_cleanup(self):
        with self.lock:
            for owned,record in tuple(self.pending.items()):
                root=record['root']
                try:
                    if not owned.is_absolute() or owned.parent!=root or root.resolve()!=root or owned.resolve()!=owned:
                        continue
                    if owned.exists():
                        self._check_tree(owned)
                        shutil.rmtree(owned)
                except (OSError,ValueError,RuntimeError):continue
                self.pending.pop(owned,None)
                self._notify()
            return len(self.pending)
