"""Account/session-bound native media references. No public CDN credentials."""
from collections import OrderedDict
from dataclasses import replace
import hashlib
import os
from pathlib import Path
import tempfile
import time
import threading
from uuid import uuid4

from .errors import ErrorCode,FrameworkError,fail
from .media import MediaHandle
from .models import Event,OperationResult,SendState
from ._files import _io_path
from ._image_validation import validate_image
from ._rich.image_metadata import parse_image_metadata,select_image_download,ImageMetadataError
from ._rich.images import MAX_IMAGE_BYTES
from ._rich.file_metadata import parse_file_metadata,FileMetadataError
from ._rich.video_metadata import parse_video_metadata,select_video_download,VideoMetadataError

MAX_INCOMING_FILE_BYTES=256*1024*1024


class IncomingMedia:
    def __init__(self,backend):
        self.backend=backend;self.references=OrderedDict();self.active={}
        self.cleanup_pending={};self._cleanup_lock=threading.RLock()

    def prepare_image(self,event,xml):
        payload=dict(event.content)
        try:
            metadata=parse_image_metadata(xml)
            filekey,aeskey,image_type,quality=select_image_download(metadata)
            if not filekey or len(filekey.encode('utf-8'))>1023 or len(aeskey) not in (32,64) or any(c not in '0123456789abcdefABCDEF' for c in aeskey):
                raise ImageMetadataError('Image has no supported native reference')
            expected=metadata.hdlength if image_type==1 else metadata.cdnthumblength if image_type==3 else metadata.length
            if expected is not None and expected>MAX_IMAGE_BYTES:
                raise ImageMetadataError('Image exceeds the SDK byte limit')
        except ImageMetadataError:
            payload.update(media_state='unavailable',media_reason='No supported bounded image reference')
            return replace(event,content=payload)
        media_id=uuid4().hex
        payload.update(media_id=media_id,media_state='pending',media_reason='awaiting_request',
            image_quality=quality,image_metadata={'md5':metadata.md5 or None,'width':metadata.width,'height':metadata.height})
        event=replace(event,content=payload)
        self.references[media_id]={'event':event,'filekey':filekey,'aeskey':aeskey,'image_type':image_type}
        while len(self.references)>256:
            _,old=self.references.popitem(last=False)
            self._update(old,'unavailable',error=ErrorCode.LAYOUT_NOT_READY,reason='Media reference expired from bounded cache')
        return event

    def _update(self,record,state,*,handle=None,error=None,reason='',native_error=None):
        source=record['event']
        event=replace(source,event_id=uuid4().hex,kind='media_update',text=None,reference=None,
            content={'message_event_id':source.event_id,'media_id':record.get('media_id') or source.content['media_id'],
                'item_path':record.get('item_path'),
                'media_state':state,'error':error.value if error else None,'reason':reason,
                'native_error':native_error,
                'media_metadata':record.get('decoded'),
                'sha256':handle.sha256 if handle else None},media=handle,observed_at=time.time())
        self.backend._emit(event)

    def prepare_rich(self,event,structured,*,reference=False):
        """Bind private parser objects to opaque IDs in the final public snapshot."""
        records=[];items=[]
        public=structured.public()
        def walk(private,visible,path):
            for index,(item,node) in enumerate(zip(private,visible)):
                location=path+(index,)
                if item.kind=='image' and item.image is not None:
                    metadata=item.image
                    key,aes,type_,quality=select_image_download(metadata)
                    if key and len(key.encode('utf-8'))<=1023 and len(aes) in (32,64) and all(c in '0123456789abcdefABCDEF' for c in aes):
                        media_id=uuid4().hex
                        node.update(media_id=media_id,image_status='pending',image_path='',image_error='',image_quality=quality)
                        items.append({'media_id':media_id,'kind':'image','state':'pending','item_path':location,'quality':quality})
                        records.append({'media_id':media_id,'item_path':location,'filekey':key,'aeskey':aes,'image_type':type_,
                            'expected_size':item.image_size or None,'expected_md5':metadata.md5 or None})
                    else:
                        node.update(image_status='unavailable',image_path='',image_error='Native image reference exceeds supported bounds')
                if item.children:walk(item.children,node.get('children',[]),location)
        walk(structured.items,public['forwarded_records'],())
        if reference:
            quoted=dict(event.reference);quoted['structured_content']=public
            event=replace(event,reference=quoted,content={**event.content,'media_items':items})
        else:event=replace(event,content={**event.content,**public,'media_items':items})
        for record in records:
            record['event']=event;self.references[record['media_id']]=record
        while len(self.references)>256:
            _,old=self.references.popitem(last=False)
            self._update(old,'unavailable',error=ErrorCode.LAYOUT_NOT_READY,reason='Media reference expired from bounded cache')
        return event

    def prepare_file(self,event,xml):
        try:
            metadata=parse_file_metadata(xml)
            if metadata is None:return event
        except FileMetadataError:
            return replace(event,content={**event.content,'media_state':'unavailable','media_reason':'Invalid ordinary-file metadata'})
        event=replace(event,content_type='file',content={**event.content,'file_metadata':{
            'name':metadata.title or None,'size':metadata.size,'extension':metadata.extension or None,'md5':metadata.md5 or None}})
        try:
            filekey=metadata.cdnattachurl or metadata.filekey
            if not filekey or len(filekey.encode('utf-8'))>1023 or len(metadata.aeskey) not in (32,64) or any(c not in '0123456789abcdefABCDEF' for c in metadata.aeskey) or metadata.size is None or not 0<metadata.size<=MAX_INCOMING_FILE_BYTES:
                raise FileMetadataError('No bounded ordinary-file reference')
        except FileMetadataError:
            return replace(event,content={**event.content,'media_state':'unavailable','media_reason':'No supported bounded ordinary-file reference'})
        media_id=uuid4().hex
        event=replace(event,content={**event.content,'media_id':media_id,
            'media_state':'pending','media_reason':'awaiting_request'})
        self.references[media_id]={'event':event,'filekey':filekey,'aeskey':metadata.aeskey,'image_type':5,
            'media_kind':'file','expected_size':metadata.size,'expected_md5':metadata.md5}
        while len(self.references)>256:
            _,old=self.references.popitem(last=False)
            self._update(old,'unavailable',error=ErrorCode.LAYOUT_NOT_READY,reason='Media reference expired from bounded cache')
        return event

    def prepare_voice(self,event,xml,payload):
        from ._voice_validation import _voice_data,parse_voice_xml,cdn_voice_reference
        if not payload:
            try:record=cdn_voice_reference(xml)
            except ValueError:
                return replace(event,content={**event.content,'media_state':'unavailable','media_reason':'No complete inline bytes or supported bounded voice reference'})
            media_id=uuid4().hex
            event=replace(event,content={**event.content,'media_id':media_id,'media_state':'pending',
                'media_reason':'awaiting_request','voice_metadata':{'source_format':'SILK','source':'cdn',
                    'declared_duration_ms':record['declared_duration_ms'],'duration_ms':None}})
            record['event']=event;self.references[media_id]=record
            while len(self.references)>256:
                _,old=self.references.popitem(last=False)
                self._update(old,'unavailable',error=ErrorCode.LAYOUT_NOT_READY,reason='Media reference expired from bounded cache')
            return event
        try:
            payload,duration=_voice_data(payload,xml)
            declared_duration=int(parse_voice_xml(xml)[1].get('voicelength'))
        except ValueError:
            return replace(event,content={**event.content,'media_state':'unavailable','media_reason':'Complete supported voice bytes unavailable'})
        media_id=uuid4().hex
        event=replace(event,content={**event.content,'media_id':media_id,'media_state':'pending',
            'media_reason':'awaiting_request','voice_metadata':{'source_format':'SILK','declared_duration_ms':declared_duration,'duration_ms':None}})
        self.references[media_id]={'event':event,'media_kind':'voice','payload':payload,'duration_ms':duration,'declared_duration_ms':declared_duration}
        while len(self.references)>256:
            _,old=self.references.popitem(last=False)
            self._update(old,'unavailable',error=ErrorCode.LAYOUT_NOT_READY,reason='Media reference expired from bounded cache')
        return event

    def prepare_video(self,event,xml):
        try:
            metadata=parse_video_metadata(xml)
            key,aes,size,md5,quality=select_video_download(metadata)
            if not key or not 0<size<=MAX_INCOMING_FILE_BYTES or metadata.duration is not None and metadata.duration>600:
                raise VideoMetadataError('No bounded complete video reference')
        except VideoMetadataError:
            return replace(event,content={**event.content,'media_state':'unavailable','media_reason':'No supported bounded video reference'})
        media_id=uuid4().hex
        event=replace(event,content={**event.content,'media_id':media_id,'media_state':'pending',
            'media_reason':'awaiting_request','video_metadata':{'size':size,'md5':md5,'quality':quality,'declared_duration_seconds':metadata.duration}})
        self.references[media_id]={'event':event,'media_kind':'video','filekey':key,'aeskey':aes,'image_type':4,
            'expected_size':size,'expected_md5':md5}
        while len(self.references)>256:
            _,old=self.references.popitem(last=False)
            self._update(old,'unavailable',error=ErrorCode.LAYOUT_NOT_READY,reason='Media reference expired from bounded cache')
        return event

    def _voice_result(self,operation_id,media_id,record):
        from ._voice_decode import decoder,decode_wav
        module=decoder() # Missing dependency is pre-admission; keep the reference.
        self.references.pop(media_id)
        owned=None;destination=None
        try:
            payload=decode_wav(module,record.pop('payload'),record['duration_ms'])
            root=_io_path((self.backend.root/self.backend.target.account.wxid/'media').resolve())
            root.mkdir(parents=True,exist_ok=True)
            owned=Path(tempfile.mkdtemp(prefix='wca-media-',dir=root));destination=owned/'payload'
            with destination.open('xb') as output:output.write(payload)
            handle=MediaHandle(destination,root=owned,media_id=media_id,expected_sha256=hashlib.sha256(payload).hexdigest())
            record['decoded']={'format':'WAV','sample_rate':24000,'channels':1,'sample_width':2,
                'duration_ms':record['duration_ms'],'declared_duration_ms':record['declared_duration_ms']}
        except (OSError,ValueError):
            if owned is not None:
                self._remember_cleanup(owned,destination);self.retry_cleanup()
            self._update(record,'failed',error=ErrorCode.NATIVE_FAILURE,reason='Complete voice decode or SDK copy failed')
            return OperationResult(operation_id,SendState.FAILED,ErrorCode.NATIVE_FAILURE)
        self._update(record,'ready',handle=handle)
        return OperationResult(operation_id,SendState.COMPLETED,native_message_id=record['event'].native_message_id,
            accepted_parts=1,detail='Complete received SILK decoded to a readable SDK-owned PCM WAV')

    def download(self,operation_id,event,media_id=None):
        from ._injector import ImageDownloadRequest,FileDownloadRequest,VoiceDownloadRequest,AdmissionCancelled
        if not isinstance(event,Event) or event.account_id!=self.backend.target.account.wxid or event.session_id!=self.backend.session_id:
            fail(ErrorCode.INVALID_ARGUMENT,'Media event does not belong to this session')
        media_id=event.content.get('media_id') if media_id is None else media_id
        if not isinstance(media_id,str):fail(ErrorCode.INVALID_ARGUMENT,'Select a valid media_id for this message')
        record=self.references.get(media_id)
        # Session assigns the public delivery sequence after map_event stores
        # this reference; all other immutable source fields must still match.
        if record is None or record['event']!=replace(event,sequence=record['event'].sequence):
            fail(ErrorCode.INVALID_ARGUMENT,'Media reference is unknown, expired or already requested')
        if not self.backend.allow_unverified and (not isinstance(event.chat_id,str) or
            event.chat_id.endswith('@chatroom') and ('item_path' in record or record.get('media_kind')=='voice')):
            fail(ErrorCode.NOT_VERIFIED,'This group voice/rich media scenario awaits live acceptance')
        if 'item_path' in record and not self.backend.allow_unverified:
            path=record['item_path']
            verified=record['image_type']==1 and (
                event.content_type=='reference' and event.reference and event.reference.get('type')==3 and len(path)==1 or
                event.content_type=='forwarded' and 1<=len(path)<=2)
            if not verified:fail(ErrorCode.NOT_VERIFIED,'This rich-content image scenario awaits live acceptance')
        if record.get('media_kind')=='voice':
            return self._voice_result(operation_id,media_id,record)
        ordinary_file=record.get('media_kind')=='file'
        video=record.get('media_kind')=='video'
        voice=record.get('media_kind')=='voice_cdn'
        if voice:
            if not self.backend.allow_unverified and not event.chat_id.endswith('@chatroom'):
                fail(ErrorCode.NOT_VERIFIED,'Private CDN voice reception awaits live acceptance')
            from ._voice_decode import decoder
            decoder()
        if video:
            from ._video_validation import decoder
            decoder() # Missing dependency must not submit a native download.
        self.references.pop(media_id)
        self.active[operation_id]=record;self.backend._pending_native[operation_id]='voice.download' if voice else 'file.download' if ordinary_file else 'video.download' if video else 'image.download'
        cls=VoiceDownloadRequest if voice else FileDownloadRequest if ordinary_file else ImageDownloadRequest
        request=cls(operation_id=int(operation_id[:16],16),account=event.account_id.encode('ascii'),
            target=event.account_id.encode('ascii'),filekey=record['filekey'].encode('utf-8'),
            aeskey=record['aeskey'].encode('ascii'),image_type=record['image_type'],
            **({'expected_size':record['expected_size']} if ordinary_file or voice else {}))
        try:code=self.backend.transport.call('WcaDownloadVoice' if voice else 'WcaDownloadFile' if ordinary_file else 'WcaDownloadImage',request)
        except AdmissionCancelled:
            self.active.pop(operation_id);self.backend._pending_native.pop(operation_id,None)
            self._update(record,'unavailable',error=ErrorCode.SESSION_CLOSED,reason='Cancelled before native download submission')
            return OperationResult(operation_id,SendState.FAILED,ErrorCode.SESSION_CLOSED)
        # The native Job already owns the keys after successful admission; do
        # not retain a second credential copy through the wait/result lifecycle.
        if code==4:
            self.active.pop(operation_id);self.backend._pending_native.pop(operation_id,None)
            self.references[media_id]=record
            return OperationResult(operation_id,SendState.FAILED,ErrorCode.SESSION_BUSY,detail='Download was not submitted')
        record.pop('filekey',None);record.pop('aeskey',None)
        if code:
            if code==5:
                return OperationResult(operation_id,SendState.UNKNOWN,ErrorCode.RESULT_UNKNOWN,detail='Native download admission uncertain')
            self.active.pop(operation_id);self.backend._pending_native.pop(operation_id,None)
            error=ErrorCode.ACCOUNT_CHANGED if code==3 else ErrorCode.NATIVE_FAILURE
            self._update(record,'failed',error=error,reason='Native download rejected request')
            return OperationResult(operation_id,SendState.FAILED,error)
        while True:
            result=self.poll_operation(operation_id)
            if result is not None:return result
            time.sleep(0.02)

    def poll_operation(self,operation_id):
        from ._injector import Request,MediaRequest
        record=self.active[operation_id]
        request=Request(operation_id=int(operation_id[:16],16))
        code=self.backend.transport.call('WcaGetOperation',request)
        if code==7:
            self.backend._pending_native.pop(operation_id,None);self.active.pop(operation_id)
            self._discard_record_copy(record)
            self._update(record,'unavailable',error=ErrorCode.RESULT_UNKNOWN,reason='Native download ownership record missing')
            return OperationResult(operation_id,SendState.UNKNOWN,ErrorCode.RESULT_UNKNOWN)
        if code:fail(ErrorCode.RESULT_UNKNOWN,'Native download result cannot be queried')
        if request.state==4:
            from ._native import operation_error
            return OperationResult(operation_id,SendState.UNKNOWN,operation_error(request.state,request.native_error),detail='Native download cleanup remains uncertain')
        if request.state not in (2,3):return None
        if request.state==2 and 'handle' not in record and 'copy_error' not in record:
            result=MediaRequest(operation_id=request.operation_id)
            code=self.backend.transport.call('WcaGetMediaResult',result)
            if code==4:return None
            if code:fail(ErrorCode.RESULT_UNKNOWN,'Native media path cannot be read')
            try:record['handle'],record['decoded']=self._copy_result(result.path,record.get('media_id') or record['event'].content['media_id'],record)
            except FrameworkError as error:record['copy_error']=error.code
            except (OSError,ValueError):record['copy_error']=ErrorCode.NATIVE_FAILURE
        code=self.backend.transport.call('WcaReleaseOperation',request)
        if code==4:return None
        if code:fail(ErrorCode.RESULT_UNKNOWN,'Native media release guard failed')
        self.backend._pending_native.pop(operation_id,None);self.active.pop(operation_id)
        if request.state==2 and 'handle' in record:
            handle=record.pop('handle')
            self._update(record,'ready',handle=handle)
            return OperationResult(operation_id,SendState.COMPLETED,native_message_id=record['event'].native_message_id,
                accepted_parts=1,detail='Downloaded bytes copied and checked; native staging released')
        reason='SDK media copy or validation failed' if record.get('copy_error') else 'Native media download failed'
        self._discard_record_copy(record)
        from ._native import operation_error
        error=record.get('copy_error',operation_error(request.state,request.native_error))
        self._update(record,'failed',error=error,reason=reason,native_error=request.native_error)
        return OperationResult(operation_id,SendState.FAILED,error,detail=reason,native_error=request.native_error)

    def _copy_result(self,native_path,media_id,record):
        root=_io_path((self.backend.root/self.backend.target.account.wxid/'media').resolve())
        root.mkdir(parents=True,exist_ok=True)
        owned=Path(tempfile.mkdtemp(prefix='wca-media-',dir=root));destination=owned/'payload'
        digest=hashlib.sha256();md5=hashlib.md5();count=0;header=b''
        ordinary_file=record.get('media_kind')=='file';video=record.get('media_kind')=='video';voice=record.get('media_kind')=='voice_cdn'
        maximum=262144 if voice else MAX_INCOMING_FILE_BYTES if ordinary_file or video else MAX_IMAGE_BYTES
        try:
            with _io_path(Path(native_path).absolute()).open('rb') as source,destination.open('xb') as output:
                before=os.fstat(source.fileno())
                if not 0<before.st_size<=maximum:raise ValueError('Media byte count invalid')
                while chunk:=source.read(1024*1024):
                    count+=len(chunk)
                    if count>maximum:raise ValueError('Media exceeds byte limit')
                    if not header:header=chunk[:32]
                    digest.update(chunk);md5.update(chunk);output.write(chunk)
                after=os.fstat(source.fileno())
            if count!=before.st_size or after.st_size!=before.st_size or after.st_mtime_ns!=before.st_mtime_ns:
                raise ValueError('Native image changed while copying')
            if record.get('expected_size') and count!=record['expected_size'] or record.get('expected_md5') and md5.hexdigest()!=record['expected_md5']:
                raise ValueError('Media reference integrity mismatch')
            if voice:
                from ._voice_validation import _voice_data
                from ._voice_decode import decoder,decode_wav
                silk,duration=_voice_data(destination.read_bytes(),record['voice_validation_xml'])
                wav=decode_wav(decoder(),silk,duration)
                with destination.open('wb') as output:output.write(wav)
                metadata={'format':'WAV','source':'cdn','sample_rate':24000,'channels':1,'sample_width':2,
                    'duration_ms':duration,'declared_duration_ms':record['declared_duration_ms']}
                return MediaHandle(destination,root=owned,media_id=media_id,expected_sha256=hashlib.sha256(wav).hexdigest()),metadata
            if ordinary_file or video:
                if count!=record['expected_size'] or record.get('expected_md5') and md5.hexdigest()!=record['expected_md5']:
                    raise ValueError('Ordinary-file metadata integrity mismatch')
                if video:
                    from ._video_validation import validate_video
                    metadata=validate_video(destination)
                else:metadata={'format':'file','size':count,'md5_checked':bool(record.get('expected_md5'))}
                return MediaHandle(destination,root=owned,media_id=media_id,expected_sha256=digest.hexdigest()),metadata
            if not (header.startswith(b'\x89PNG\r\n\x1a\n') or header.startswith(b'\xff\xd8\xff') or header.startswith((b'GIF87a',b'GIF89a')) or header.startswith(b'RIFF') and header[8:12]==b'WEBP'):
                raise ValueError('Native download did not return supported image bytes')
            metadata=validate_image(destination)
            return MediaHandle(destination,root=owned,media_id=media_id,expected_sha256=digest.hexdigest()),metadata
        except BaseException:
            self._remember_cleanup(owned,destination)
            self.retry_cleanup()
            raise

    def _remember_cleanup(self,owned,destination,handle=None):
        with self._cleanup_lock:
            self.cleanup_pending[owned]=(destination,handle)

    def _discard_record_copy(self,record):
        handle=record.pop('handle',None)
        if handle is not None:
            self._remember_cleanup(handle.path.parent,handle.path,handle)
            self.retry_cleanup()

    def retry_cleanup(self):
        with self._cleanup_lock:
            for owned,(destination,handle) in tuple(self.cleanup_pending.items()):
                try:
                    if owned.exists() and (owned.is_symlink() or owned.resolve()!=owned or destination.parent!=owned):
                        continue
                    if handle is not None:
                        # A successful release can transfer the last cleanup
                        # responsibility to another subscriber's live lease.
                        with handle._resource.lock:
                            handle.release()
                            shared=handle._resource.references>0
                        if shared:
                            self.cleanup_pending.pop(owned,None)
                            continue
                    else:destination.unlink(missing_ok=True)
                    if owned.exists():owned.rmdir()
                except (OSError,ValueError,FrameworkError):
                    continue
                self.cleanup_pending.pop(owned,None)
            return len(self.cleanup_pending)

    def cancel_references(self):
        for record in tuple(self.references.values()):
            self._update(record,'unavailable',error=ErrorCode.SESSION_CLOSED,reason='Session closed before download request')
        self.references.clear()

    def discard_unpublished(self,event):
        # Rich messages can own several nested selectors without a top-level
        # media_id. None can be requested when every subscriber rejected it.
        for media_id,record in tuple(self.references.items()):
            source=record['event']
            if (source.event_id,source.account_id,source.session_id)==(event.event_id,event.account_id,event.session_id):
                self.references.pop(media_id,None)

    def close(self):
        self.cancel_references()
        for record in self.active.values():
            self._discard_record_copy(record)
            self._update(record,'unavailable',error=ErrorCode.RESULT_UNKNOWN,reason='Target exited before download was resolved')
        self.active.clear()
        self.retry_cleanup()
