"""Strict local MP4 decoding before publishing an incoming video file."""
import importlib
import time
from .errors import ErrorCode,fail
from ._videos import inspect_video


def decoder():
    try:
        module=importlib.import_module('av')
        if module.__version__!='18.1.0':raise ImportError('Unverified decoder version')
    except (ImportError,OSError,AttributeError):
        fail(ErrorCode.DEPENDENCY_MISSING,'Incoming video decode requires the pinned video extra')
    return module


def validate_video(path):
    module=decoder();info=inspect_video(path)
    if info.duration_seconds>600:raise ValueError('Video duration exceeds limit')
    deadline=time.monotonic()+30;frames=0;pixels=0;processed=0;packets=0;width=height=0
    try:
        with module.open(str(path),format='mp4',options={'enable_drefs':'0','use_absolute_path':'0','protocol_whitelist':'file'}) as container:
            videos=list(container.streams.video);audio=list(container.streams.audio)
            if len(videos)!=1 or len(audio)>2:raise ValueError('Unsupported media track count')
            stream=videos[0]
            if not 0<stream.codec_context.width*stream.codec_context.height<=8294400:
                raise ValueError('Video dimensions exceed limit')
            for item in videos+audio:
                item.codec_context.options={'err_detect':'explode','threads':'1'}
                if item.duration is not None and item.time_base is not None and float(item.duration*item.time_base)>600:
                    raise ValueError('Track duration exceeds limit')
            track_frames={item.index:0 for item in videos+audio}
            audio_time={item.index:0.0 for item in audio}
            audio_block={item.index:0.0 for item in audio}
            timeline={}
            audio_seconds=0
            for packet in container.demux(*(videos+audio)):
                packets+=1
                if packets>100000 or time.monotonic()>deadline:raise ValueError('Video packet budget exceeded')
                if packet.is_corrupt:raise ValueError('Corrupt media packet')
                for frame in packet.decode():
                    processed+=1;track_frames[packet.stream.index]+=1
                    if processed>100000 or time.monotonic()>deadline:raise ValueError('Video decode budget exceeded')
                    if getattr(frame,'is_corrupt',False):raise ValueError('Corrupt media frame')
                    if frame.pts is not None and frame.time_base is not None:
                        stamp=float(frame.pts*frame.time_base)
                        lower,upper=timeline.get(packet.stream.index,(stamp,stamp))
                        lower=min(lower,stamp);upper=max(upper,stamp)
                        if upper-lower>600:raise ValueError('Decoded timeline exceeds limit')
                        timeline[packet.stream.index]=(lower,upper)
                    if isinstance(frame,module.VideoFrame):
                        count=frame.width*frame.height;frames+=1;pixels+=count
                        if not 0<count<=8294400 or frames>36000 or pixels>2000000000:
                            raise ValueError('Video frame budget exceeded')
                        if not width:width,height=frame.width,frame.height
                        if (width,height)!=(frame.width,frame.height):raise ValueError('Changing video dimensions unsupported')
                    else:
                        if not 0<frame.sample_rate<=192000 or len(frame.layout.channels)>8:raise ValueError('Audio format exceeds limit')
                        audio_seconds+=frame.samples/frame.sample_rate
                        audio_time[packet.stream.index]+=frame.samples/frame.sample_rate
                        audio_block[packet.stream.index]=max(audio_block[packet.stream.index],frame.samples/frame.sample_rate)
                        if audio_seconds>1200:raise ValueError('Audio duration exceeds limit')
            if not frames or stream.frames and stream.frames!=frames:
                raise ValueError('Video frame count incomplete')
            if any(not track_frames[item.index] for item in audio):raise ValueError('Audio track has no decodable frames')
            for item in audio:
                if item.duration is None or item.time_base is None or item.duration<=0:
                    raise ValueError('Audio track duration unavailable')
                expected=float(item.duration*item.time_base)
                tolerance=1/item.codec_context.sample_rate
                if audio_time[item.index]+tolerance<expected or audio_time[item.index]-expected>audio_block[item.index]+tolerance:
                    raise ValueError('Audio decoded duration incomplete')
    except Exception:
        raise ValueError('Video could not be completely decoded') from None
    return {'format':'MP4','duration_seconds':info.duration_seconds,'width':width,'height':height,
        'video_frames':frames,'audio_tracks':len(audio),'fully_decoded':True}
