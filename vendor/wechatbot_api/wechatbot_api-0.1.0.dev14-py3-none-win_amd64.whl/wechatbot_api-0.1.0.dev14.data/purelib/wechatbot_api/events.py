from __future__ import annotations

import asyncio
import logging
import queue
import threading
from collections.abc import Callable, Iterator
from dataclasses import replace
from uuid import uuid4

from .models import Event

logger=logging.getLogger(__name__)
_END=object()


class Subscription:
    """Bounded, ordered subscription. Callback runs on a private dispatcher."""
    def __init__(self, callback: Callable[[Event],None] | None=None, *, capacity: int=1024):
        if type(capacity) is not int or capacity<1:
            raise ValueError('capacity must be a positive integer')
        self._queue=queue.Queue(capacity)
        self._lock=threading.Lock()
        self._closed=False
        self._dropped=0
        self._unreported=0
        self.callback_errors=0
        self._callback=callback
        self._thread=None
        self._following=None
        if callback is not None:
            self._thread=threading.Thread(target=self._dispatch,name='wechatbot-event-dispatch',daemon=True)
            self._thread.start()

    @property
    def dropped(self) -> int:
        with self._lock:
            return self._dropped

    def _offer(self,event: Event):
        with self._lock:
            if self._closed:
                return False
            if self._queue.full():
                self._dropped+=1;self._unreported+=1
                return False
            if event.media is not None:
                event=replace(event,media=event.media.retain())
            value=event
            if self._unreported and not self._queue.full():
                gap=replace(event,event_id=uuid4().hex,kind='diagnostic',chat_id=None,sender_id=None,
                    native_message_id=None,native_timestamp=None,content_type=None,text=None,mentions=(),reference=None,media=None,bridge_sequence=None,
                    content={'code':'EVENT_GAP','dropped':self._unreported})
                value=(gap,event)
                self._unreported=0
            try:
                self._queue.put_nowait(value)
                return True
            except queue.Full:
                if event.media is not None:event.media.release()
                self._dropped+=1
                self._unreported+=1
                return False

    def get(self,timeout: float | None=None) -> Event:
        if self._callback is not None and threading.current_thread() is not self._thread:
            raise RuntimeError('Callback subscription cannot also be consumed as an iterator')
        while True:
            with self._lock:
                if self._following is not None:
                    value=self._following;self._following=None
                    return value
                if self._closed and self._queue.empty():
                    raise StopIteration
            try:
                value=self._queue.get(timeout=0.1 if timeout is None else timeout)
            except queue.Empty:
                if timeout is not None:
                    raise
                continue
            if isinstance(value,tuple):
                with self._lock:
                    self._following=value[1]
                return value[0]
            return value

    def __iter__(self) -> Iterator[Event]:
        while True:
            try:
                yield self.get()
            except StopIteration:
                return

    async def __aiter__(self):
        # Poll with a bounded wait: cancelling an async iterator cannot strand a
        # thread waiting forever, or consume a future event after cancellation.
        while True:
            try:
                value=self.get(timeout=0)
            except queue.Empty:
                await asyncio.sleep(0.01)
                continue
            except StopIteration:
                return
            yield value

    def _dispatch(self):
        for event in self:
            try:
                self._callback(event)
            except Exception:
                self.callback_errors+=1
                logger.error('Event callback failed; event body omitted')

    def close(self, *, wait: bool=True, timeout: float | None=None):
        with self._lock:
            self._closed=True
        if wait and self._thread and self._thread is not threading.current_thread():
            self._thread.join(timeout)
        return not self._thread or not self._thread.is_alive()
