import re
from xml.etree import ElementTree as ET
from uuid import uuid4

from .models import Event
from ._rich.replies import parse_reply
from ._rich.forwarded import parse_forwarded,parse_link,parse_reference_content,ForwardedError


def mentions(source):
    if len(source)>4095 or re.search(r'<!\s*(?:DOCTYPE|ENTITY)\b',source,re.I):
        return ()
    try:
        root=ET.fromstring(source)
    except (ET.ParseError,ValueError):
        return ()
    node=root if root.tag=='atuserlist' else root.find('.//atuserlist')
    if node is None or not node.text:
        return ()
    return tuple(dict.fromkeys(x.strip() for x in node.text.split(',') if re.fullmatch(r'[a-zA-Z0-9_.@-]{1,127}',x.strip()) and not x.strip().endswith('@chatroom')))


def unavailable_media(value):
    """A parsed CDN reference is not a queued or completed download."""
    if hasattr(value,'public'):
        value=value.public()
    if isinstance(value,dict):
        value={key:unavailable_media(item) for key,item in value.items()}
        if value.get('image_status')=='pending':
            value.update(image_status='unavailable',image_error='Native downloader not adapted')
        return value
    if isinstance(value,list):
        return [unavailable_media(item) for item in value]
    return value


def map_event(raw,account_id,session_id,*,image_sink=None,file_sink=None,voice_sink=None,video_sink=None,rich_sink=None):
    sender=bytes(raw.sender).decode('utf-8','strict')
    receiver=bytes(raw.receiver).decode('utf-8','strict')
    content=bytes(raw.content).decode('utf-8','strict')
    source=bytes(raw.mention_source).decode('utf-8','strict')
    chat=sender if sender.endswith('@chatroom') else receiver if receiver.endswith('@chatroom') else receiver if sender==account_id else sender
    actual_sender=sender if not sender.endswith('@chatroom') else None
    if sender.endswith('@chatroom') and ':\n' in content:
        candidate,body=content.split(':\n',1)
        if re.fullmatch(r'[a-zA-Z0-9_.@-]{1,127}',candidate) and not candidate.endswith('@chatroom'):
            actual_sender=candidate;content=body
    kind={1:'text',3:'image',34:'voice',43:'video',47:'emoticon',49:'app',62:'video',10000:'system',10002:'system'}.get(raw.type,'unknown')
    text=content if kind=='text' and not raw.flags else None
    payload={'native_type':raw.type,'content_available':not bool(raw.flags),'is_self':actual_sender==account_id}
    reference=None;rich=None
    if kind=='app' and not raw.flags:
        reply=parse_reply(content)
        if reply:
            kind='reference';text=reply['text'];reference=reply['reply']
            rich=parse_reference_content(reference['type'],reference['content'])
            if not reference['content']:
                rich=None;reference.update(content=None,availability='unavailable',failure_reason='missing_body')
            reference['structured_content']=unavailable_media(rich)
            # Native embedded XML may contain CDN credentials. Only plain quoted
            # text remains public; structured data replaces other embedded bodies.
            if reference['type']!=1:reference['content']=None
            reference['sender_name']=reference['sender_name'] or None
        else:
            try:
                forwarded=parse_forwarded(content)
                if forwarded:
                    kind='forwarded';rich=forwarded;payload.update(unavailable_media(forwarded.public()))
                else:
                    link=parse_link(content)
                    if link:kind='link';payload.update(unavailable_media(link))
            except ForwardedError as error:
                payload.update(availability='unavailable',failure_reason=error.reason)
    if kind in ('image','file','voice','video','emoticon'):
        payload.update(media_state='unavailable',media_reason='Native downloader not adapted')
    # Preserve original XML/content in the private processing path only; public
    # structured snapshots do not expose CDN credentials by default.
    event=Event(uuid4().hex,account_id,session_id,int(raw.sequence),
        'notification' if kind=='system' else 'message',chat,actual_sender,
        str(raw.native_message_id) if raw.native_message_id else None,None,kind,text,
        mentions(source),reference,payload,bridge_sequence=int(raw.sequence))
    if kind=='image' and not raw.flags and image_sink:return image_sink(event,content)
    if kind=='app' and not raw.flags and file_sink:return file_sink(event,content)
    if kind=='voice' and not raw.flags and voice_sink:
        return voice_sink(event,content,bytes(raw.voice[:raw.voice_size]) if 0<raw.voice_size<=len(raw.voice) else b'')
    if kind=='video' and not raw.flags and video_sink:return video_sink(event,content)
    if kind in ('reference','forwarded') and rich is not None and rich_sink:
        return rich_sink(event,rich,reference=kind=='reference')
    return event
