"""Private target-process ABI transport; public consumers never need ctypes."""
from __future__ import annotations

import ctypes as c
from ctypes import wintypes as w
import struct
from pathlib import Path

from ._win32 import kernel, modules, win_error, Reader
from .errors import ErrorCode, fail


class Request(c.Structure):
    _fields_=[('size',c.c_uint32),('abi_version',c.c_uint32),('status',c.c_uint32),('state',c.c_uint32),
        ('operation_id',c.c_uint64),('native_error',c.c_uint32),('reserved',c.c_uint32),
        ('account',c.c_char*128),('target',c.c_char*128),('text',c.c_char*1024)]
    def __init__(self,**values):
        super().__init__(size=c.sizeof(type(self)),abi_version=1,**values)


class AbiInfo(c.Structure):
    _fields_=[('size',c.c_uint32),('abi_version',c.c_uint32),('request_size',c.c_uint32),
        ('bridge_version',c.c_uint32),('capability_bits',c.c_uint64)]
    def __init__(self):
        super().__init__(size=c.sizeof(type(self)))


class NativeEvent(c.Structure):
    _fields_=[('size',c.c_uint32),('abi_version',c.c_uint32),('present',c.c_uint32),('type',c.c_uint32),
        ('flags',c.c_uint32),('dropped',c.c_uint32),('sequence',c.c_uint64),('native_message_id',c.c_uint64),
        ('sender',c.c_char*128),('receiver',c.c_char*128),('mention_source',c.c_char*4096),('content',c.c_char*262144),
        ('voice_size',c.c_uint32),('voice_reserved',c.c_uint32),('voice',c.c_uint8*262144)]
    def __init__(self,**values):
        super().__init__(size=c.sizeof(type(self)),abi_version=1,**values)


class AtRequest(Request):
    _fields_=[('members',c.c_char*1024)]


class MediaRequest(Request):
    _fields_=[('path',c.c_wchar*32768)]


class VideoRequest(MediaRequest):
    _fields_=[('duration_seconds',c.c_uint32),('reserved_video',c.c_uint32)]


class ImageDownloadRequest(Request):
    _fields_=[('filekey',c.c_char*1024),('aeskey',c.c_char*65),('reserved_download',c.c_uint8*3),('image_type',c.c_uint32)]


class FileDownloadRequest(ImageDownloadRequest):
    _fields_=[('expected_size',c.c_uint64)]


class VoiceDownloadRequest(FileDownloadRequest):
    pass


def exports(path: Path) -> dict[str,int]:
    data=path.read_bytes();nt=struct.unpack_from('<I',data,0x3c)[0]
    count=struct.unpack_from('<H',data,nt+6)[0];opt_size=struct.unpack_from('<H',data,nt+20)[0]
    sections=[]
    for n in range(count):
        off=nt+24+opt_size+n*40
        virtual_size,va,raw_size,raw=struct.unpack_from('<IIII',data,off+8)
        sections.append((va,max(virtual_size,raw_size),raw))
    def offset(rva):
        for va,size,raw in sections:
            if va<=rva<va+size:
                return raw+rva-va
        fail(ErrorCode.ABI_MISMATCH,'Export RVA outside image sections')
    export_rva,export_size=struct.unpack_from('<II',data,nt+24+112)
    directory=offset(export_rva)
    _,names_count,functions_rva,names_rva,ordinals_rva=struct.unpack_from('<IIIII',data,directory+20)
    result={}
    for n in range(names_count):
        name=offset(struct.unpack_from('<I',data,offset(names_rva)+n*4)[0])
        text=data[name:data.index(b'\0',name)].decode('ascii')
        ordinal=struct.unpack_from('<H',data,offset(ordinals_rva)+n*2)[0]
        address=struct.unpack_from('<I',data,offset(functions_rva)+ordinal*4)[0]
        if export_rva<=address<export_rva+export_size:
            fail(ErrorCode.ABI_MISMATCH,'Forwarded bridge exports are not supported')
        result[text]=address
    return result


def _system_address(local_base,entry,local_path,remote,local_read,remote_read):
    if not remote or Path(remote[2]).resolve()!=Path(local_path).resolve():
        fail(ErrorCode.NATIVE_FAILURE,'Remote system function module path differs from its local owner')
    def identity(base,read):
        dos=read(base,64)
        if dos[:2]!=b'MZ':fail(ErrorCode.NATIVE_FAILURE,'System owner has an invalid PE header')
        offset=struct.unpack_from('<I',dos,60)[0]
        if not 64<=offset<=1048576:fail(ErrorCode.NATIVE_FAILURE,'System owner PE header is outside bounds')
        nt=read(base+offset,84)
        if nt[:4]!=b'PE\0\0' or struct.unpack_from('<H',nt,24)[0]!=0x20b:
            fail(ErrorCode.NATIVE_FAILURE,'System owner must be a PE32+ image')
        return struct.unpack_from('<H',nt,4)[0],struct.unpack_from('<I',nt,8)[0],struct.unpack_from('<I',nt,80)[0]
    local_identity=identity(local_base,local_read)
    if identity(remote[0],remote_read)!=local_identity or local_identity[0]!=0x8664 or remote[1]!=local_identity[2]:
        fail(ErrorCode.NATIVE_FAILURE,'Local and remote system module identities differ')
    offset=entry-local_base
    if not 0<=offset<remote[1]:fail(ErrorCode.NATIVE_FAILURE,'System export lies outside its owner image')
    return remote[0]+offset


class AdmissionCancelled(Exception):
    """SDK-only marker: no native entry thread has started for this request."""


class Injector:
    def __init__(self,pid: int,path: Path,created: int):
        self.pid=pid;self.path=path.resolve();self.k=kernel();self.process=None;self.base=None
        self._mutex=None;self._pending=[];self._exports=exports(self.path)
        self._watchdog=None;self._stop_submission=None
        self._configure_api()
        c.set_last_error(0)
        mutex=self.k.CreateMutexW(None,True,f'Local\\wechatbot-api-{pid}-{created}')
        code=c.get_last_error()
        if not mutex:
            win_error('Creating session ownership mutex failed')
        if code==183:
            self.k.CloseHandle(mutex)
            fail(ErrorCode.SESSION_BUSY,'Another framework session owns this process')
        self._mutex=mutex
        try:
            loaded=modules(pid)
            if any(name in loaded for name in ('wca_bridge.dll','text_bridge.dll','selftest_bridge.dll')):
                fail(ErrorCode.SESSION_BUSY,'A native bridge is already loaded in this process')
            self._open_checked(created)
        except BaseException:
            self.release_handles()
            raise

    def _configure_api(self):
        signatures={
            'VirtualAllocEx':([w.HANDLE,c.c_void_p,c.c_size_t,w.DWORD,w.DWORD],c.c_void_p),
            'VirtualFreeEx':([w.HANDLE,c.c_void_p,c.c_size_t,w.DWORD],w.BOOL),
            'WriteProcessMemory':([w.HANDLE,c.c_void_p,c.c_void_p,c.c_size_t,c.POINTER(c.c_size_t)],w.BOOL),
            'CreateRemoteThread':([w.HANDLE,c.c_void_p,c.c_size_t,c.c_void_p,c.c_void_p,w.DWORD,c.POINTER(w.DWORD)],w.HANDLE),
            'WaitForSingleObject':([w.HANDLE,w.DWORD],w.DWORD),
            'GetExitCodeThread':([w.HANDLE,c.POINTER(w.DWORD)],w.BOOL),
            'GetModuleHandleW':([w.LPCWSTR],w.HMODULE),
            'GetProcAddress':([w.HMODULE,c.c_char_p],c.c_void_p),
            'GetModuleHandleExW':([w.DWORD,c.c_void_p,c.POINTER(w.HMODULE)],w.BOOL),
            'GetModuleFileNameW':([w.HMODULE,w.LPWSTR,w.DWORD],w.DWORD),
            'CreateMutexW':([c.c_void_p,w.BOOL,w.LPCWSTR],w.HANDLE),
            'ReleaseMutex':([w.HANDLE],w.BOOL),
        }
        for name,(args,result) in signatures.items():
            method=getattr(self.k,name);method.argtypes=args;method.restype=result

    def _open_checked(self,created):
        self.process=self.k.OpenProcess(0x10043a,False,self.pid)
        if not self.process:win_error('Opening target for bridge connection failed')
        times=[w.FILETIME() for _ in range(4)]
        if not self.k.GetProcessTimes(self.process,*(c.byref(value) for value in times)):
            win_error('Verifying opened target creation time failed')
        actual=times[0].dwLowDateTime+(times[0].dwHighDateTime<<32)
        if actual!=created:fail(ErrorCode.PROCESS_EXITED,'Opened process differs from the selected process')

    @classmethod
    def attach_existing(cls,pid,path,created):
        value=cls.__new__(cls)
        value.pid=pid;value.path=Path(path).resolve();value.k=kernel()
        value.process=None;value.base=None;value._mutex=None;value._pending=[];value._watchdog=None;value._stop_submission=None
        value._exports=exports(value.path);value._configure_api()
        try:
            value._open_checked(created)
            loaded=modules(pid).get(value.path.name.lower())
            if loaded:
                if Path(loaded[2]).resolve()!=value.path:fail(ErrorCode.ABI_MISMATCH,'Recovery module full path differs')
                value.base=loaded[0]
            return value
        except BaseException:
            value.release_handles();raise

    def system_function(self,name: bytes):
        local=self.k.GetProcAddress(self.k.GetModuleHandleW('kernel32.dll'),name)
        if not local:
            win_error('Resolving system entry failed')
        owner=w.HMODULE()
        if not self.k.GetModuleHandleExW(6,local,c.byref(owner)):
            win_error('Resolving system entry owner failed')
        path=c.create_unicode_buffer(32768)
        if not self.k.GetModuleFileNameW(owner,path,len(path)):
            win_error('Resolving system module path failed')
        remote=modules(self.pid).get(Path(path.value).name.lower())
        with Reader(self.pid) as reader:
            return _system_address(owner.value,local,path.value,remote,c.string_at,reader.read)

    def _thread(self,address,parameter,*,admission=False):
        guard=getattr(self,'_watchdog',None)
        if guard:guard.begin_call()
        gate=getattr(self,'_stop_submission',None) if admission else None
        try:
            if gate:
                with gate.lock:
                    if gate.stopped:raise AdmissionCancelled()
                    thread=self.k.CreateRemoteThread(self.process,None,0,address,parameter,0,None)
                    if not thread:win_error('Starting ABI call failed')
                    self._pending.append(thread)
            else:
                thread=self.k.CreateRemoteThread(self.process,None,0,address,parameter,0,None)
                if not thread:win_error('Starting ABI call failed')
                self._pending.append(thread)
        except BaseException:
            if guard and not self._pending:guard.end_call()
            raise
        # The owner worker retains thread, argument memory and module lifetime.
        # Public wait timeouts do not terminate this call or free its arguments.
        result=self.k.WaitForSingleObject(thread,0xffffffff)
        if result!=0:
            fail(ErrorCode.NATIVE_FAILURE,'ABI thread wait failed; resources retained')
        value=w.DWORD()
        if not self.k.GetExitCodeThread(thread,c.byref(value)):
            win_error('Reading ABI result failed')
        self.k.CloseHandle(thread);self._pending.remove(thread)
        if guard and not self._pending:guard.end_call()
        return value.value

    def _allocate(self,data):
        address=self.k.VirtualAllocEx(self.process,None,len(data),0x3000,4)
        if not address:
            win_error('Allocating ABI arguments failed')
        count=c.c_size_t();buffer=c.create_string_buffer(data)
        if not self.k.WriteProcessMemory(self.process,address,buffer,len(data),c.byref(count)) or count.value!=len(data):
            self.k.VirtualFreeEx(self.process,address,0,0x8000)
            win_error('Writing ABI arguments failed')
        return address

    def load(self):
        argument=self._allocate((str(self.path)+'\0').encode('utf-16-le'))
        try:
            self._thread(self.system_function(b'LoadLibraryW'),argument)
        finally:
            if not self._pending:
                self.k.VirtualFreeEx(self.process,argument,0,0x8000)
        loaded=modules(self.pid).get(self.path.name.lower())
        if not loaded or Path(loaded[2]).resolve()!=self.path:
            fail(ErrorCode.NATIVE_FAILURE,'Bridge load or full-path ownership verification failed')
        self.base=loaded[0]

    def call(self,name,value):
        if not self.base or name not in self._exports:
            fail(ErrorCode.ABI_MISMATCH,'Bridge entry missing')
        address=self._allocate(bytes(value))
        try:
            admission=name.startswith('WcaSubmit') or name in ('WcaDownloadImage','WcaDownloadFile','WcaDownloadVoice')
            status=self._thread(self.base+self._exports[name],address,admission=admission)
            count=c.c_size_t()
            if not self.k.ReadProcessMemory(self.process,address,c.byref(value),c.sizeof(value),c.byref(count)) or count.value!=c.sizeof(value):
                win_error('Reading ABI reply failed')
            return status
        finally:
            if not self._pending:
                self.k.VirtualFreeEx(self.process,address,0,0x8000)

    def unload(self):
        if self.base:
            status=self._thread(self.system_function(b'FreeLibrary'),self.base)
            if not status or self.path.name.lower() in modules(self.pid):
                fail(ErrorCode.SHUTDOWN_PENDING,'Bridge remains loaded; ownership retained',retryable=True)
            self.base=None
        self.release_handles()

    def release_handles(self):
        if self._pending or self.base:
            fail(ErrorCode.SHUTDOWN_PENDING,'Native resources are still owned',retryable=True)
        guard=getattr(self,'_watchdog',None)
        if guard:guard.close()
        if self.process:
            self.k.CloseHandle(self.process);self.process=None
        if self._mutex:
            self.k.ReleaseMutex(self._mutex);self.k.CloseHandle(self._mutex);self._mutex=None

    def exited(self):
        """Only the signaled process object proves exit; exit code 259 can be legal."""
        if not self.process:
            return False
        status=self.k.WaitForSingleObject(self.process,0)
        if status==0:return True
        if status==258:return False
        win_error('Checking target exit state failed')

    def release_if_exited(self):
        """A confirmed dead process owns no executable memory or native tasks."""
        if not self.exited():
            return False
        for thread in self._pending:
            self.k.CloseHandle(thread)
        self._pending.clear();self.base=None
        self.release_handles()
        return True
