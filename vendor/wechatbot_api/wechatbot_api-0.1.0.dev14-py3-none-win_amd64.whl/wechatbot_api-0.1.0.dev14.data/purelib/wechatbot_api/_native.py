from __future__ import annotations

import hashlib
import json
import re
import time
from importlib.resources import files
from pathlib import Path

from .discovery import inspect_process
from .errors import ErrorCode, FrameworkError, fail
from .models import Capability, CapabilityState, SendResult, SendState


def operation_error(state,native_error=0):
    if state==2:return None
    if native_error==1307:return ErrorCode.ACCOUNT_CHANGED # Win32 ERROR_INVALID_OWNER; native identity guard.
    return ErrorCode.RESULT_UNKNOWN if state==4 else ErrorCode.NATIVE_FAILURE


class NativeBackend:
    def __init__(self,target,data_root: Path, *, allow_unverified: bool=False, receive: bool=False,session_id: str='',history_limit: int=1024):
        self.target=target;self.root=data_root;self.transport=None
        self.allow_unverified=allow_unverified
        self.receive=receive;self.session_id=session_id;self._emit=None;self._native_dropped=0
        from ._outbound_snapshots import OutboundSnapshots
        self._outbound=OutboundSnapshots();self._snapshots=self._outbound.active
        self._pending_native={};self._resolved_native={}
        self._history_limit=history_limit
        from ._incoming_media import IncomingMedia
        from ._submission import SubmissionGate
        self._incoming=IncomingMedia(self);self._guard=None;self._stop_submission=SubmissionGate()

    def capabilities(self):
        from .session import CORE_CAPABILITIES
        from ._voice_decode import decoder as voice_decoder
        from ._video_validation import decoder as video_decoder
        try:voice_decoder();voice_decoder_available=True
        except FrameworkError:voice_decoder_available=False
        try:video_decoder();video_decoder_available=True
        except FrameworkError:video_decoder_available=False
        verified={
            'reference.receive':('Private text quote/body and byte-exact quoted original PNG verified; group quoted text and original PNG passed under development opt-in; other quote containers pending',('private.text','private.original_png')),
            'forwarded.receive':('Private two-level embedded record and byte-exact nested original PNG verified; group depth-2 nested original image passed under development opt-in; deeper/other variants pending',('private.depth2.original_png',)),
            'video.receive':('Independent private/group H.264 MP4 downloaded; complete decode/source-frame equality, read/export/close/release, playback confirmed; other formats pending',('private.h264.silent','group.h264.silent')),
            'voice.receive':('Private inline/group CDN single-frame SILK fully decoded to WAV, read/export/close/release verified; multi-frame/other variants pending',('private.inline.silk.single_frame','group.cdn.silk.single_frame')),
            'file.receive':('Private/group 55-byte ordinary-file download matched source, read/export/close/release and contents confirmed',('private.ordinary','group.ordinary')),
            'image.receive':('Private/group original PNG download matched source SHA-256; read/export/close/release and image display confirmed',('private.png','group.png')),
            'video.send':('Filehelper/private/group native H.264 silent video, SDK reception and playback confirmed; other formats pending',('filehelper.mp4','private.h264.silent','group.h264.silent')),
            'voice.send':('Filehelper/private/group WAV -> Tencent SILK voice bubble confirmed playable; private SDK decode also verified',('filehelper.voice','private.wav','group.wav')),
            'file.send':('Filehelper/private/group ordinary-file send, byte-exact SDK receipt and actual contents confirmed',('filehelper.ordinary','private.ordinary','group.ordinary')),
            'image.send':('Filehelper/private/group PNG native image, byte-exact SDK receipt and actual image display confirmed; other formats pending',('filehelper.png','private.png','group.png')),
            'text.send':('Filehelper native completion and independent private/group SDK receipt and recipient text confirmation',('filehelper','private','group')),
            'text.receive':('Public SDK independently sent private/group marker receipt verified',('private','group')),
            'group.mention':('One- and two-member actual cached names: native field, receiver mention metadata and recipient clickable tags verified; larger/mixed-label sets pending',('group.single_member.cached_name','group.two_member.cached_name')),
            'group.members.read':('Stable account-bound cached members; incomplete; roles unknown',('cache',)),
            'contacts.read':('Stable account-bound cached names and remarks; relationship unknown',('cache',)),
        }
        return (Capability('text.send.filehelper',CapabilityState.SUPPORTED,
            'One public-SDK live native completion and clean disconnect verified',('filehelper',)),
            Capability('voice.receive.cdn',CapabilityState.SUPPORTED if voice_decoder_available else CapabilityState.UNAVAILABLE,
                'Group format-4 single-frame SILK type15 download/WAV/read/export/close/release verified; private/conditional variants pending' if voice_decoder_available else 'Pinned voice extra required',('group.silk.single_frame',)),
            )+tuple(Capability(name,CapabilityState.UNAVAILABLE,'Incoming voice decode requires the pinned voice extra') if name=='voice.receive' and not voice_decoder_available else
            Capability(name,CapabilityState.UNAVAILABLE,'Incoming video decode requires the pinned video extra') if name=='video.receive' and not video_decoder_available else
            Capability(name,CapabilityState.SUPPORTED,*verified[name]) if name in verified else Capability(name,
            CapabilityState.NOT_VERIFIED if name in ('video.receive','voice.receive','file.receive','image.receive','video.send','voice.send','file.send','text.send','reference.receive','forwarded.receive') else CapabilityState.NOT_ADAPTED,
            'Parsed offline; real rich-content validation pending' if name in ('reference.receive','forwarded.receive') else
            'Filehelper verified; plain private/group targets await validation' if name=='text.send' else
            'Native ordinary-file candidate implemented; live validation pending' if name=='file.send' else
            'Native ordinary-file download candidate implemented; explicit request_media opt-in and live validation required' if name=='file.receive' else
            'Copied complete voice payload and bounded WAV decode candidate; explicit request_media opt-in and live validation required' if name=='voice.receive' else
            'Bounded type-4 video download and full MP4 decode candidate; explicit request_media opt-in and live validation required' if name=='video.receive' else
            'Native image download candidate implemented; explicit request_media opt-in and live validation required' if name=='image.receive' else 'Native path not yet adapted',
            ('private','group') if name=='text.send' else ()) for name in CORE_CAPABILITIES)

    def connect(self,emit):
        from ._injector import Injector, Request, AbiInfo
        root=files('wechatbot_api')
        path=Path(str(root.joinpath('bin/wca_bridge.dll')))
        manifest=json.loads(root.joinpath('data/native.json').read_text('utf-8-sig'))
        from . import __version__
        if manifest.get('sdk_version')!=__version__:
            fail(ErrorCode.ABI_MISMATCH,'SDK/native manifest version mismatch')
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=manifest['sha256']:
            fail(ErrorCode.ABI_MISMATCH,'Packaged native component hash mismatch')
        current=inspect_process(self.target.pid)
        if current!=self.target:
            fail(ErrorCode.ACCOUNT_CHANGED,'Target identity changed before injection')
        self.transport=Injector(self.target.pid,path,self.target.process_created)
        self.transport._stop_submission=self._stop_submission
        from ._watchdog import Watchdog,PendingOperations
        self._guard=Watchdog(self.target.pid,self.target.process_created,path,self.root,manifest)
        self.transport._watchdog=self._guard
        self._guard.start()
        self._pending_native=PendingOperations(self._guard,self._pending_native)
        self._outbound.changed=self._sync_guard_snapshots
        self.transport.load()
        info=AbiInfo()
        if self.transport.call('WcaGetAbi',info)!=0 or (info.abi_version,info.request_size,info.bridge_version)!=(1,1312,manifest['bridge_version']):
            fail(ErrorCode.ABI_MISMATCH,'SDK/native ABI mismatch')
        request=Request(account=self.target.account.wxid.encode('ascii'))
        code=self.transport.call('WcaConnect',request)
        if code:
            fail(ErrorCode.ACCOUNT_CHANGED if code==3 else ErrorCode.UNSUPPORTED_BUILD if code==2 else ErrorCode.NATIVE_FAILURE,
                 f'Native connect rejected target ({code})')
        self._emit=emit
        if self.receive:
            if self.transport.call('WcaStartReceiver',request)!=0:
                fail(ErrorCode.NATIVE_FAILURE,'Native receive Hook initialization failed')

    def poll(self):
        if not self.receive:
            return
        from ._injector import NativeEvent
        from ._event_mapping import map_event
        from .models import Event
        from uuid import uuid4
        for _ in range(64):
            raw=NativeEvent()
            code=self.transport.call('WcaPollEvent',raw)
            if code:
                fail(ErrorCode.ACCOUNT_CHANGED if code==3 else ErrorCode.NATIVE_FAILURE,'Receive channel rejected account or event')
            if raw.dropped>self._native_dropped:
                self._emit(Event(uuid4().hex,self.target.account.wxid,self.session_id,raw.sequence,'diagnostic',
                    content={'code':'EVENT_GAP','source':'native','dropped':raw.dropped-self._native_dropped}))
                self._native_dropped=raw.dropped
            if not raw.present:
                break
            if raw.type==0xfffffffe:
                self._emit(Event(uuid4().hex,self.target.account.wxid,self.session_id,raw.sequence,'diagnostic',
                    content=json.loads(bytes(raw.content).decode('utf-8'))))
                continue
            try:
                mapped=map_event(raw,self.target.account.wxid,self.session_id,image_sink=self._incoming.prepare_image,file_sink=self._incoming.prepare_file,voice_sink=self._incoming.prepare_voice,video_sink=self._incoming.prepare_video,rich_sink=self._incoming.prepare_rich)
            except Exception:
                mapped=Event(uuid4().hex,self.target.account.wxid,self.session_id,raw.sequence,'diagnostic',
                    content={'code':'EVENT_DECODE_FAILED','native_type':raw.type})
            delivered=self._emit(mapped)
            if delivered is False:
                self._incoming.discard_unpublished(mapped)

    def arm_mention_probe(self,peer,marker):
        from ._injector import Request
        request=Request(account=self.target.account.wxid.encode('ascii'),target=peer.encode('ascii'),text=marker.encode('utf-8'))
        if self.transport.call('WcaArmMentionProbe',request)!=0:
            fail(ErrorCode.NATIVE_FAILURE,'Native diagnostic probe could not be armed')

    def mention_probe_stats(self):
        from ._injector import Request
        request=Request()
        if self.transport.call('WcaGetMentionProbeStats',request)!=0:
            fail(ErrorCode.NATIVE_FAILURE,'Native diagnostic stats unavailable')
        return {'send_calls':request.state,'text_calls':request.native_error,'marker_matches':request.reserved}

    def send(self,operation_id,method,*args):
        from ._injector import Request
        if self._guard:
            guard=self._guard.diagnostics()
            if not guard['running']:
                fail(ErrorCode.NATIVE_FAILURE,'Watchdog exited; close this session before admitting new work')
            if guard.get('warning'):
                # Recovery cannot currently record ownership. Try to persist the
                # journal again before refusing to admit native work.
                self._guard.update()
                if self._guard.diagnostics().get('warning'):
                    fail(ErrorCode.NATIVE_FAILURE,
                        'Watchdog recovery journal is unavailable; native submission was not admitted',retryable=True)
        if method=='media.download':
            return self._incoming.download(operation_id,*args)
        if method=='image.download':
            return self._incoming.download(operation_id,args[0])
        if method not in ('text.send','group.mention','image.send','file.send','voice.send','video.send'):
            fail(ErrorCode.NOT_ADAPTED,f'{method} native path has not been adapted')
        target,text=args[:2]
        image=method=='image.send'
        voice=method=='voice.send'
        video=method=='video.send'
        media=method in ('image.send','file.send','voice.send','video.send')
        source_path=text if media else None
        if media:
            text=''
        if not isinstance(target,str) or not re.fullmatch(r'[a-zA-Z0-9_.@-]{1,127}',target):
            fail(ErrorCode.INVALID_ARGUMENT,'Target must be an original WeChat identifier')
        if not media and (not isinstance(text,str) or not text or '\0' in text or len(text.encode('utf-8'))>1023):
            fail(ErrorCode.INVALID_ARGUMENT,'Text must contain 1–1023 UTF-8 bytes without NUL')
        entry='WcaSubmitText'
        cls=Request;extra={}
        if media:
            from ._injector import MediaRequest
            from ._files import prepare_file
            from ._voices import prepare_voice,EncoderUnavailable
            try:
                snapshot=self._outbound.prepare(operation_id,prepare_voice if voice else prepare_file,
                    source_path,self.root/self.target.account.wxid/'outbound')
                with snapshot.path.open('rb') as stream:
                    signature=stream.read(32)
                if image and not (signature.startswith(b'\x89PNG\r\n\x1a\n') or signature.startswith(b'\xff\xd8\xff')):
                    raise ValueError('Image candidate currently accepts PNG/JPEG contents')
                if image and not self.allow_unverified and not signature.startswith(b'\x89PNG\r\n\x1a\n'):
                    raise ValueError('Verified image scenario currently covers PNG only')
                if video:
                    from ._videos import inspect_video
                    video_info=inspect_video(snapshot.path)
            except EncoderUnavailable as error:
                self._release_snapshot(operation_id)
                fail(ErrorCode.DEPENDENCY_MISSING,str(error))
            except (OSError,ValueError) as error:
                self._release_snapshot(operation_id)
                fail(ErrorCode.INVALID_ARGUMENT,str(error))
            except RuntimeError as error:
                self._release_snapshot(operation_id)
                fail(ErrorCode.NATIVE_FAILURE,str(error))
            cls=MediaRequest;entry='WcaSubmitImage' if image else 'WcaSubmitVoice' if voice else 'WcaSubmitFile';extra={'path':str(snapshot.path)}
            if video:
                from ._injector import VideoRequest
                cls=VideoRequest;entry='WcaSubmitVideo';extra['duration_seconds']=video_info.duration_seconds
        if method=='group.mention':
            from ._injector import AtRequest
            members,labels=args[2:]
            if not target.endswith('@chatroom') or not 1<=len(members)<=8 or len(set(members))!=len(members) or any(not isinstance(x,str) or not re.fullmatch(r'[a-zA-Z0-9_.@-]{1,127}',x) or x.endswith('@chatroom') for x in members):
                fail(ErrorCode.INVALID_ARGUMENT,'Native mention needs a room and 1–8 unique personal wxids')
            if len(members)>2 and not self.allow_unverified:
                fail(ErrorCode.NOT_VERIFIED,'Mention sets larger than two await independent live validation')
            cached_names=None
            if labels is None or not self.allow_unverified:
                from ._cache import inspect_cache
                snapshot=inspect_cache(self.target.pid,self.target.account.wxid,target)
                cached_names={row.wxid:tuple(x for x in (row.group_nickname,row.wechat_name) if x) for row in snapshot.records}
            if labels is None:
                labels=tuple(next(iter(cached_names.get(member,())),None) for member in members)
            if labels is None or len(labels)!=len(members) or any(not isinstance(x,str) or not x or any(ord(c)<32 for c in x) for x in labels):
                fail(ErrorCode.INVALID_ARGUMENT,'No verified name is cached; supply explicit display_names')
            if not self.allow_unverified and any(label not in cached_names.get(member,()) for member,label in zip(members,labels)):
                fail(ErrorCode.NOT_VERIFIED,'Verified mention scenario requires an actual cached member name')
            text=' '.join('@'+label+'\u2005' for label in labels)+' '+text
            if len(text.encode('utf-8'))>1023:
                fail(ErrorCode.INVALID_ARGUMENT,'Mention text exceeds the native byte limit')
            cls=AtRequest;entry='WcaSubmitAtText';extra={'members':','.join(members).encode('ascii')}
        request=cls(operation_id=int(operation_id[:16],16),account=self.target.account.wxid.encode('ascii'),
            target=target.encode('ascii'),text=text.encode('utf-8'),**extra)
        self._pending_native[operation_id]=method
        from ._injector import AdmissionCancelled
        try:code=self.transport.call(entry,request)
        except AdmissionCancelled:
            self._pending_native.pop(operation_id,None);self._release_snapshot(operation_id)
            return SendResult(operation_id,SendState.FAILED,ErrorCode.SESSION_CLOSED,detail='Cancelled before native submission')
        if code:
            if code==4:
                self._pending_native.pop(operation_id,None)
                self._release_snapshot(operation_id)
                return SendResult(operation_id,SendState.FAILED,ErrorCode.SESSION_BUSY,detail='Native task not submitted')
            # A partially scheduled task must remain owned. close() will retain
            # the module if the native drain refuses unloading.
            if code!=5:
                self._pending_native.pop(operation_id,None);self._release_snapshot(operation_id)
            return SendResult(operation_id,SendState.UNKNOWN if code==5 else SendState.FAILED,
                ErrorCode.RESULT_UNKNOWN if code==5 else ErrorCode.ACCOUNT_CHANGED if code==3 else ErrorCode.NATIVE_FAILURE,detail=f'Native submit code {code}')
        # Extension requests are submission envelopes only. All operation APIs
        # require the base ABI, regardless of the submitted operation kind.
        query=Request(operation_id=request.operation_id)
        request=query
        while True:
            code=self.transport.call('WcaGetOperation',request)
            if code:
                fail(ErrorCode.RESULT_UNKNOWN,'Native operation result cannot be queried')
            if request.state in (2,3):
                # A completion may precede the functor's destruction. Retain
                # arguments and snapshots until the task release guard passes.
                released=self.transport.call('WcaReleaseOperation',request)
                if released==4:
                    # A cleanup fault can change a previously observed terminal
                    # state to UNKNOWN. Re-query instead of spinning on release.
                    time.sleep(0.02)
                    continue
                if released!=0:
                    fail(ErrorCode.RESULT_UNKNOWN,'Native release guard failed; module retained')
                self._pending_native.pop(operation_id,None)
                self._release_snapshot(operation_id)
                return SendResult(operation_id,SendState.COMPLETED if request.state==2 else SendState.FAILED,
                    operation_error(request.state,request.native_error),accepted_parts=1,
                    detail='Native media manager execution completed; no recipient receipt' if request.state==2 and media else
                    'Native completion; no recipient receipt' if request.state==2 else 'Native task failed')
            if request.state==4:
                return SendResult(operation_id,SendState.UNKNOWN,operation_error(request.state,request.native_error),detail='Native exception; module retained')
            time.sleep(0.02)

    def _release_snapshot(self,operation_id):
        self._outbound.release(operation_id)

    def refresh_operation(self,operation_id):
        if operation_id in self._resolved_native:
            return self._resolved_native[operation_id]
        if operation_id not in self._pending_native:
            return SendResult(operation_id,SendState.UNKNOWN,ErrorCode.RESULT_UNKNOWN)
        if self._pending_native[operation_id] in ('image.download','file.download','video.download','voice.download'):
            from .models import OperationResult
            result=self._incoming.poll_operation(operation_id)
            if result is None:return OperationResult(operation_id,SendState.ACCEPTED)
            if operation_id not in self._pending_native:
                self._resolved_native[operation_id]=result
                while len(self._resolved_native)>self._history_limit:
                    self._resolved_native.pop(next(iter(self._resolved_native)))
            return result
        from ._injector import Request
        query=Request(operation_id=int(operation_id[:16],16))
        code=self.transport.call('WcaGetOperation',query)
        if code==7:
            # No owned job can be released. Absence alone is not proof of a
            # failed external operation; retain the unknown result contract.
            self._pending_native.pop(operation_id,None)
            self._release_snapshot(operation_id)
            return SendResult(operation_id,SendState.UNKNOWN,ErrorCode.RESULT_UNKNOWN)
        if code:
            fail(ErrorCode.RESULT_UNKNOWN,'Native operation cannot be refreshed')
        if query.state in (2,3):
            released=self.transport.call('WcaReleaseOperation',query)
            if released==0:
                self._pending_native.pop(operation_id,None);self._release_snapshot(operation_id)
                result=SendResult(operation_id,SendState.COMPLETED if query.state==2 else SendState.FAILED,
                    operation_error(query.state,query.native_error),accepted_parts=1,
                    detail='Later native completion; no recipient receipt')
                self._resolved_native[operation_id]=result
                while len(self._resolved_native)>self._history_limit:
                    self._resolved_native.pop(next(iter(self._resolved_native)))
                return result
            if released!=4:
                fail(ErrorCode.RESULT_UNKNOWN,'Native release after refresh failed')
        return SendResult(operation_id,SendState.UNKNOWN if query.state==4 else SendState.ACCEPTED,
            operation_error(query.state,query.native_error) if query.state==4 else None)

    def _release_sdk_files(self):
        # Clean SDK-owned files while the guard can still finalize recovery. The
        # guard's normal-stop acknowledgement may only happen after this step.
        self._incoming.close()
        for operation_id in tuple(self._snapshots):
            self._release_snapshot(operation_id)

    def close(self):
        from ._injector import Request
        self.stop_admission()
        self._incoming.cancel_references()
        self._incoming.retry_cleanup()
        if not self.transport:
            return
        if self.transport.exited():
            self._release_sdk_files()
            if not self.transport.release_if_exited():
                fail(ErrorCode.NATIVE_FAILURE,'Target exit was not confirmed after SDK file cleanup')
            self._process_exited();return
        if not self.transport.base:
            self.transport.release_handles();self.transport=None;return
        request=Request()
        while True:
            try:
                if self.transport.exited():
                    self._release_sdk_files()
                    if self.transport.release_if_exited():
                        self._process_exited();return
                for operation_id in tuple(self._pending_native):
                    self.refresh_operation(operation_id)
                code=self.transport.call('WcaDrain',request)
            except FrameworkError:
                if self.transport.exited():
                    self._release_sdk_files()
                    if self.transport.release_if_exited():
                        self._process_exited();return
                raise
            if code==0:
                break
            if code!=4:
                fail(ErrorCode.SHUTDOWN_PENDING,'Native drain failed; module retained',retryable=True)
            time.sleep(0.05)
        self._release_sdk_files()
        self.transport.unload();self.transport=None

    def cleanup_media(self):
        return self._incoming.retry_cleanup()+self._outbound.retry_cleanup()

    def pending_media_cleanup(self):
        with self._incoming._cleanup_lock,self._outbound.lock:
            return len(self._incoming.cleanup_pending)+len(self._outbound.pending)

    def _sync_guard_snapshots(self):
        if self._guard:
            records=tuple(self._outbound.active.values())+tuple(self._outbound.pending.values())
            self._guard.update(snapshots=[{'root':str(record['root']),'owned':str(record['owned'])} for record in records])

    def watchdog_diagnostics(self):
        return self._guard.diagnostics() if self._guard else {'state':'not_started'}

    def stop_admission(self):self._stop_submission.set()

    def _process_exited(self):
        self.transport=None
        self._incoming.close()
        for operation_id in tuple(self._pending_native):
            self._resolved_native[operation_id]=SendResult(operation_id,SendState.UNKNOWN,
                ErrorCode.RESULT_UNKNOWN,detail='Target exited; external result remains unknown')
        self._pending_native.clear()
        for operation_id in tuple(self._snapshots):
            self._release_snapshot(operation_id)
