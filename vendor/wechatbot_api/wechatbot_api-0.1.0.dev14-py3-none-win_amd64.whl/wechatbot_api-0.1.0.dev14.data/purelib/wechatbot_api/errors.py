from enum import Enum


class ErrorCode(str, Enum):
    NOT_LOGGED_IN = "NOT_LOGGED_IN"
    UNSUPPORTED_BUILD = "UNSUPPORTED_BUILD"
    ACCESS_DENIED = "ACCESS_DENIED"
    LAYOUT_NOT_READY = "LAYOUT_NOT_READY"
    LAYOUT_MISMATCH = "LAYOUT_MISMATCH"
    PROCESS_EXITED = "PROCESS_EXITED"
    ACCOUNT_CHANGED = "ACCOUNT_CHANGED"
    SESSION_BUSY = "SESSION_BUSY"
    SESSION_CLOSED = "SESSION_CLOSED"
    ABI_MISMATCH = "ABI_MISMATCH"
    NOT_ADAPTED = "NOT_ADAPTED"
    NOT_VERIFIED = "NOT_VERIFIED"
    INVALID_ARGUMENT = "INVALID_ARGUMENT"
    NATIVE_FAILURE = "NATIVE_FAILURE"
    RESULT_UNKNOWN = "RESULT_UNKNOWN"
    SHUTDOWN_PENDING = "SHUTDOWN_PENDING"
    CALLBACK_FAILED = "CALLBACK_FAILED"
    EVENT_GAP = "EVENT_GAP"
    PLATFORM_UNSUPPORTED = "PLATFORM_UNSUPPORTED"
    DEPENDENCY_MISSING = "DEPENDENCY_MISSING"
    MEDIA_CLEANUP_PENDING = "MEDIA_CLEANUP_PENDING"


class FrameworkError(RuntimeError):
    def __init__(self, code: ErrorCode, message: str, *, retryable: bool = False):
        super().__init__(message)
        self.code = code
        self.retryable = retryable


def fail(code: ErrorCode, message: str, *, retryable: bool = False):
    raise FrameworkError(code, message, retryable=retryable)
