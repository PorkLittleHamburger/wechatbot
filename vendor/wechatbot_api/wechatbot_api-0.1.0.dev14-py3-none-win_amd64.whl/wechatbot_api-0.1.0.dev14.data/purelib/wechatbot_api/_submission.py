"""Linearize stop against creating a native admission thread, never its wait."""
import threading


class SubmissionGate:
    def __init__(self):self.lock=threading.Lock();self.stopped=False
    def set(self):
        with self.lock:self.stopped=True
    def is_set(self):
        with self.lock:return self.stopped
