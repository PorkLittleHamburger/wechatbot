"""Bounded incoming SILK metadata/framing, retained from Bot; no native calls."""
import re
import xml.etree.ElementTree as ET
from ._rich.account import validate_account
from ._voices import STANDARD_SILK_HEADER,TENCENT_SILK_HEADER,_inspect_silk
MAX_RECEIVED_VOICE_BYTES=262144
MAX_VOICE_XML_BYTES=16384

def parse_voice_xml(xml):
    """校验并保留语音 XML 原文，只去掉群消息的路由前缀。"""
    if not isinstance(xml, str) or '\0' in xml or len(xml.encode('utf-8')) > MAX_VOICE_XML_BYTES:
        raise ValueError('语音元数据无效')
    # 群消息的作者前缀属于消息路由，不属于 XML。
    content = xml.strip()
    if not content.startswith('<') and ':\n' in content:
        prefix, content = content.split(':\n', 1)
        validate_account(prefix)
        content = content.strip()
    if re.search(r'<!\s*(?:DOCTYPE|ENTITY)\b', content, re.IGNORECASE):
        raise ValueError('语音元数据不支持实体声明')
    try:
        root = ET.fromstring(content)
    except (ET.ParseError, ValueError):
        raise ValueError('语音元数据无效') from None
    stack, total = [(root, 1)], 0
    while stack:
        element, depth = stack.pop()
        total += 1
        if depth > 8 or total > 128 or len(element.attrib) > 64:
            raise ValueError('语音元数据结构过于复杂')
        stack.extend((child, depth + 1) for child in element)
    nodes = [root] if root.tag == 'voicemsg' else root.findall('voicemsg') if root.tag == 'msg' else []
    if len(nodes) != 1:
        raise ValueError('语音元数据缺少唯一的音频信息')
    node = nodes[0]
    if len(node) or len(node.attrib) > 64:
        raise ValueError('语音元数据结构无效')
    return content, node


def _voice_data(payload, xml):
    if (not isinstance(payload, bytes) or not 12 < len(payload) <= MAX_RECEIVED_VOICE_BYTES or
            not payload.startswith((TENCENT_SILK_HEADER, STANDARD_SILK_HEADER))):
        raise ValueError('完整 SILK 音频不可用')
    _, node = parse_voice_xml(xml)
    if node.get('endflag', '1') != '1' or node.get('cancelflag', '0') != '0':
        raise ValueError('语音尚未接收完整')
    duration = node.get('voicelength', '')
    if not re.fullmatch(r'[1-9][0-9]{0,4}', duration) or int(duration) > 60_000:
        raise ValueError('语音时长无效')
    declared = node.get('length')
    if declared is not None and (not re.fullmatch(r'[1-9][0-9]{0,6}', declared) or int(declared) != len(payload)):
        raise ValueError('语音声明长度与音频不一致')
    parsed = _inspect_silk(payload)
    # 实机微信语音可标注 2980 ms 而携带 148 个完整帧（2960 ms）。
    # endflag、声明字节数和完整包边界均已校验，容许一帧的计时差。
    if abs(parsed.duration_ms - int(duration)) > 20:
        raise ValueError('语音声明时长与音频不一致')
    return parsed.silk, parsed.duration_ms


def cdn_voice_reference(xml):
    """Bound the private type-15 reference; returned validation XML has no keys."""
    _,node=parse_voice_xml(xml)
    if node.get('endflag','1')!='1' or node.get('cancelflag','0')!='0' or node.get('voiceformat')!='4':
        raise ValueError('Incomplete or unsupported CDN voice')
    duration=node.get('voicelength','');length=node.get('length','')
    if not re.fullmatch(r'[1-9][0-9]{0,4}',duration) or int(duration)>60000:
        raise ValueError('Invalid voice duration')
    if not re.fullmatch(r'[1-9][0-9]{0,6}',length) or not 12<int(length)<=MAX_RECEIVED_VOICE_BYTES:
        raise ValueError('Invalid voice byte count')
    key=node.get('voiceurl','');aes=node.get('aeskey','');md5=node.get('voicemd5') or None
    if not key or '\0' in key or len(key.encode('utf-8'))>1023 or not re.fullmatch(r'(?:[0-9a-fA-F]{32}|[0-9a-fA-F]{64})',aes):
        raise ValueError('No bounded voice reference')
    if md5 is not None and not re.fullmatch(r'[0-9a-fA-F]{32}',md5):raise ValueError('Invalid voice MD5')
    sanitized=ET.Element('voicemsg',length=length,voicelength=duration,voiceformat='4',endflag='1',cancelflag='0')
    return {'filekey':key,'aeskey':aes,'image_type':15,'media_kind':'voice_cdn','expected_size':int(length),
        'expected_md5':md5.lower() if md5 else None,'declared_duration_ms':int(duration),
        'voice_validation_xml':ET.tostring(sanitized,encoding='unicode')}
