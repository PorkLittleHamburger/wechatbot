"""微信 type=6 文件 XML 和账号隔离存储；不连接 CDN 或执行文件。"""
from __future__ import annotations

from dataclasses import dataclass, field
import re
import xml.etree.ElementTree as ET

from .._files import MAX_FILE_BYTES

MAX_FILE_XML_BYTES = 16_384
_FORBIDDEN_DECLARATION = re.compile(r"<!\s*(?:DOCTYPE|ENTITY)\b", re.IGNORECASE)
_MD5 = re.compile(r"[0-9a-fA-F]{32}")
_DECIMAL = re.compile(r"[0-9]{1,19}")


class FileMetadataError(ValueError):
    """文件 XML 无效；错误消息不会包含原始 XML、CDN 地址或密钥。"""


@dataclass(frozen=True, slots=True)
class FileMetadata:
    title: str = ""
    size: int | None = None
    extension: str = ""
    md5: str = ""
    cdnattachurl: str = field(default="", repr=False)
    aeskey: str = field(default="", repr=False)
    attachid: str = field(default="", repr=False)
    filekey: str = field(default="", repr=False)
    encryver: int | None = None


def _text(parent, name, maximum=1024):
    children = parent.findall(name)
    if len(children) > 1:
        raise FileMetadataError("文件 XML 包含重复字段")
    if not children:
        return ""
    element = children[0]
    if len(element):
        raise FileMetadataError("文件 XML 字段不能包含子元素")
    value = element.text or ""
    if len(value.encode("utf-8")) > maximum or any(ord(ch) < 32 or ord(ch) == 127 for ch in value):
        raise FileMetadataError("文件 XML 字段过长或包含控制字符")
    return value


def _number(parent, name, maximum):
    if parent.find(name) is None:
        return None
    value = _text(parent, name)
    if not _DECIMAL.fullmatch(value) or int(value) > maximum:
        raise FileMetadataError("文件 XML 数值不在支持范围内")
    return int(value)


def parse_file_metadata(content: str) -> FileMetadata | None:
    """只解析 msg/appmsg(type=6)/appattach；合法的其他 appmsg 返回 None。

    title 和 extension 仅为展示信息。下载目标由 SDK 决定，不能把它们
    直接拼为目录。缺失 size/md5 保持未知，不把未知值当作完整性验证成功。
    """
    if not isinstance(content, str) or not content.strip():
        raise FileMetadataError("文件 XML 必须是非空字符串")
    if len(content) > MAX_FILE_XML_BYTES or "\0" in content:
        raise FileMetadataError("文件 XML 过长或包含 NUL")
    try:
        if len(content.encode("utf-8")) > MAX_FILE_XML_BYTES:
            raise FileMetadataError("文件 XML 超过 16384 字节上限")
    except UnicodeError:
        raise FileMetadataError("文件 XML 必须包含有效 UTF-8 字符") from None
    if _FORBIDDEN_DECLARATION.search(content):
        raise FileMetadataError("文件 XML 不允许 DTD 或实体声明")
    try:
        root = ET.fromstring(content)
    except (ET.ParseError, ValueError):
        raise FileMetadataError("文件 XML 格式不合法") from None
    pending, count = [(root, 1)], 0
    while pending:
        element, depth = pending.pop()
        count += 1
        if count > 256 or depth > 16 or len(element.attrib) > 64:
            raise FileMetadataError("文件 XML 结构过于复杂")
        pending.extend((child, depth + 1) for child in element)
    if root.tag != "msg":
        raise FileMetadataError("文件 XML 必须具有 msg/appmsg 结构")
    appmsgs = list(root.iter("appmsg"))
    if len(appmsgs) != 1 or appmsgs[0] not in list(root):
        raise FileMetadataError("文件 XML 必须具有唯一的直接 appmsg 子元素")
    appmsg = appmsgs[0]
    message_type = _text(appmsg, "type", 16)
    if not message_type or not _DECIMAL.fullmatch(message_type):
        raise FileMetadataError("文件 XML 缺少有效的 appmsg 类型")
    if int(message_type) != 6:
        return None
    attachments = list(appmsg.iter("appattach"))
    if len(attachments) != 1 or attachments[0] not in list(appmsg):
        raise FileMetadataError("文件 XML 必须具有唯一的直接 appattach 子元素")
    attach = attachments[0]
    size = _number(attach, "totallen", MAX_FILE_BYTES)
    if size == 0:
        raise FileMetadataError("当前文件接收不支持空文件")
    hashes = [_text(parent, "md5", 32) for parent in (appmsg, attach)]
    if any(value and not _MD5.fullmatch(value) for value in hashes):
        raise FileMetadataError("文件 md5 必须为 32 位十六进制字符串")
    if all(hashes) and hashes[0].lower() != hashes[1].lower():
        raise FileMetadataError("文件 XML 的 md5 字段不一致")
    title = _text(appmsg, "title", 2048)
    extension = _text(attach, "fileext", 128)
    return FileMetadata(
        title=title, size=size, extension=extension, md5=(hashes[0] or hashes[1]).lower(),
        cdnattachurl=_text(attach, "cdnattachurl", 8192),
        aeskey=_text(attach, "aeskey", 1024), attachid=_text(attach, "attachid", 8192),
        filekey=_text(attach, "filekey", 1024), encryver=_number(attach, "encryver", (1 << 31) - 1),
    )
