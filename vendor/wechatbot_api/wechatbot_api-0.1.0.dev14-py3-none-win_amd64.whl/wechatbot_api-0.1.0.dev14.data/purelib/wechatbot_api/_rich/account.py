import re


def validate_account(value):
    if not isinstance(value,str) or not re.fullmatch(r'[a-zA-Z0-9_.@-]{1,127}',value) or value.endswith('@chatroom') or value.startswith('gh_') or value in ('filehelper','fmessage'):
        raise ValueError('Not a personal WeChat account identifier')
    return value
