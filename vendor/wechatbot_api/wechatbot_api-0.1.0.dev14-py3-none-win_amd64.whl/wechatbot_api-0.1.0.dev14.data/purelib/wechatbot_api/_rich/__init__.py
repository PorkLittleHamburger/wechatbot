"""Private bounded rich-content parsers adapted from helper/Bot local patches."""
