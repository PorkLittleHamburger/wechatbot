"""Complete bounded SILK decode to a normal PCM WAV for SDK consumers."""
import importlib
from io import BytesIO
import struct
import wave

from .errors import ErrorCode,fail


def decoder():
    try:
        package=importlib.import_module('pysilk')
        if package.__version__!='0.2.9':raise ImportError('Unverified codec version')
        module=importlib.import_module('pysilk.backends.cffi._silk')
        if not hasattr(module,'ffi') or not hasattr(module.lib,'SKP_Silk_SDK_Decode'):raise ImportError('SILK SDK unavailable')
    except (ImportError,OSError,AttributeError):
        fail(ErrorCode.DEPENDENCY_MISSING,'Incoming voice decode requires the pinned voice extra and SILK SDK binding')
    return module


def decode_wav(module,payload,duration_ms):
    from ._voices import _inspect_silk,TENCENT_SILK_HEADER
    maximum=24000*2*60
    parsed=_inspect_silk(payload);payload=parsed.silk
    if parsed.duration_ms!=duration_ms:raise ValueError('SILK framing duration changed')
    ffi,lib=module.ffi,module.lib
    size=ffi.new('int32_t *')
    if lib.SKP_Silk_SDK_Get_Decoder_Size(size)!=0 or not 0<size[0]<=16*1024*1024:
        raise ValueError('SILK decoder size invalid')
    state=ffi.new('uint8_t[]',size[0])
    if lib.SKP_Silk_SDK_InitDecoder(state)!=0:raise ValueError('SILK decoder initialization failed')
    control=ffi.new('SKP_SILK_SDK_DecControlStruct *');control.API_sampleRate=24000
    control.framesPerPacket=1
    samples=ffi.new('int16_t[1024]');count=ffi.new('int16_t *')
    pcm=bytearray();offset=len(TENCENT_SILK_HEADER)
    while offset<len(payload):
        length=struct.unpack_from('<h',payload,offset)[0];offset+=2
        packet=payload[offset:offset+length];offset+=length
        count[0]=1024
        code=lib.SKP_Silk_SDK_Decode(state,control,0,ffi.from_buffer('uint8_t[]',packet),length,samples,count)
        if code!=0:raise ValueError('SILK packet decoding failed')
        # The pinned high-level decode() silently omits remaining internal
        # frames. This framework supports one 20 ms frame per packet only;
        # reject multi-frame packets instead of publishing truncated audio.
        if control.moreInternalDecoderFrames or count[0]!=480:
            raise ValueError('Unsupported multi-frame SILK packet')
        if len(pcm)+count[0]*2>maximum:raise ValueError('Decoded voice exceeds duration limit')
        pcm.extend(ffi.buffer(samples,count[0]*2))
    if len(pcm)!=duration_ms*48:raise ValueError('Decoded voice duration does not match complete frames')
    wav=BytesIO()
    with wave.open(wav,'wb') as stream:
        stream.setnchannels(1);stream.setsampwidth(2);stream.setframerate(24000);stream.writeframes(pcm)
    return wav.getvalue()
