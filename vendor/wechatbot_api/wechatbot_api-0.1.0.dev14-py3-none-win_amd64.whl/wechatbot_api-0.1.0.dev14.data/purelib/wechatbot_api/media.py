from __future__ import annotations

import hashlib
import threading
from pathlib import Path

from .errors import ErrorCode, fail


class _MediaResource:
    def __init__(self,path,root,media_id,digest):
        self.path=Path(path).resolve();self.root=Path(root).resolve()
        if self.path.parent!=self.root:
            raise ValueError('Media must be a direct child of its owned directory')
        self.media_id=media_id;self.digest=digest;self.references=1
        self.lock=threading.RLock()


class MediaHandle:
    """A lease on a ready SDK-owned file; retain() makes an independent lease."""
    def __init__(self,path: Path, *, root: Path, media_id: str, expected_sha256: str):
        self._resource=_MediaResource(path,root,media_id,expected_sha256)
        self._released=False

    @property
    def path(self):return self._resource.path
    @property
    def media_id(self):return self._resource.media_id
    @property
    def sha256(self):return self._resource.digest

    def _check(self):
        if self._released:
            fail(ErrorCode.INVALID_ARGUMENT,'Media handle has been released')
        if self.path.is_symlink() or self.path.resolve().parent!=self._resource.root:
            fail(ErrorCode.INVALID_ARGUMENT,'Media path no longer belongs to this handle')

    def retain(self) -> MediaHandle:
        with self._resource.lock:
            self._check()
            result=object.__new__(MediaHandle)
            result._resource=self._resource;result._released=False
            self._resource.references+=1
            return result

    def read(self) -> bytes:
        with self._resource.lock:
            self._check()
            data=self.path.read_bytes()
            if hashlib.sha256(data).hexdigest()!=self.sha256:
                fail(ErrorCode.NATIVE_FAILURE,'Media content changed')
            return data

    def export(self,destination: str | Path) -> Path:
        destination=Path(destination)
        data=self.read()
        with destination.open('xb') as output:
            output.write(data)
        return destination

    def release(self):
        with self._resource.lock:
            if self._released:
                return
            self._check()
            if self._resource.references==1:
                self.path.unlink(missing_ok=True)
            self._resource.references-=1
            self._released=True

    def __del__(self):
        # Losing a Python reference does not delete a delivered file. Explicit
        # release/cleanup owns deletion; other live leases still count correctly.
        resource=getattr(self,'_resource',None)
        if resource is not None and not getattr(self,'_released',True):
            with resource.lock:
                resource.references-=1;self._released=True
