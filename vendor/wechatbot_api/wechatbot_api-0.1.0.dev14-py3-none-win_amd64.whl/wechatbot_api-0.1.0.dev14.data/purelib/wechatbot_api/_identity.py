"""Build-specific read-only layout; derived from helper with new structural evidence."""
import re
import struct
from collections.abc import Callable

from .errors import ErrorCode, FrameworkError, fail
from .models import Account

APP_GLOBAL = 0xBB6F788
APP_TABLE = 0x901F0E8
CONTEXT_TABLE = 0x90D0CC8
APP_GETTER = 0x20920
IDENTITY_GETTER = 0x358810


def read_identity(read_memory: Callable[[int, int], bytes], base: int) -> Account:
    observed = {}
    def read(address, size):
        if not 0x10000 <= address < 0x800000000000 or address+size >= 0x800000000000:
            fail(ErrorCode.LAYOUT_NOT_READY, 'Identity pointer is not ready', retryable=True)
        data = read_memory(address, size)
        if len(data) != size:
            fail(ErrorCode.LAYOUT_NOT_READY, 'Short identity read', retryable=True)
        key = (address, size)
        if key in observed and observed[key] != data:
            fail(ErrorCode.LAYOUT_NOT_READY, 'Identity changed during read', retryable=True)
        observed[key] = data
        return data
    def ptr(address):
        return struct.unpack('<Q',read(address,8))[0]
    app = ptr(base+APP_GLOBAL)
    if not app:
        fail(ErrorCode.LAYOUT_NOT_READY, 'Application object is not initialized', retryable=True)
    if ptr(app) != base+APP_TABLE or ptr(base+APP_TABLE+0x60) != base+APP_GETTER:
        fail(ErrorCode.LAYOUT_MISMATCH, 'Application object/vtable mismatch')
    context = ptr(app+0x68)
    if not context:
        fail(ErrorCode.LAYOUT_NOT_READY, 'Account context is not initialized', retryable=True)
    if ptr(context) != base+CONTEXT_TABLE or ptr(base+CONTEXT_TABLE+0x18) != base+IDENTITY_GETTER:
        fail(ErrorCode.LAYOUT_MISMATCH, 'Identity context/vtable mismatch')
    if read(base+IDENTITY_GETTER,5) != b'\x48\x8d\x41\x48\xc3':
        fail(ErrorCode.LAYOUT_MISMATCH, 'Identity getter instruction mismatch')
    def string(address, limit, encoding):
        header=read(address,32)
        length, capacity=struct.unpack_from('<QQ',header,16)
        if length > limit or capacity < length or not (capacity==15 or 16<=capacity<=1048576):
            fail(ErrorCode.LAYOUT_MISMATCH,'Invalid identity string layout')
        if length == 0:
            return ''
        buffer=address if capacity==15 else struct.unpack_from('<Q',header)[0]
        try:
            return read(buffer,length).decode(encoding)
        except UnicodeError:
            fail(ErrorCode.LAYOUT_MISMATCH,'Invalid identity string encoding')
    wxid=string(context+0x48,127,'ascii')
    if not wxid:
        fail(ErrorCode.NOT_LOGGED_IN,'Identity has no logged-in account',retryable=True)
    if not re.fullmatch(r'[a-zA-Z0-9_.-]{1,127}',wxid) or wxid in ('filehelper','fmessage') or wxid.startswith('gh_'):
        fail(ErrorCode.LAYOUT_MISMATCH,'Identity is not a personal account')
    # The new build's display-name field has not been proven; never reuse +0x88.
    for (address,size),data in reversed(tuple(observed.items())):
        if read_memory(address,size)!=data:
            fail(ErrorCode.LAYOUT_NOT_READY,'Identity changed during verification',retryable=True)
    return Account(wxid)
