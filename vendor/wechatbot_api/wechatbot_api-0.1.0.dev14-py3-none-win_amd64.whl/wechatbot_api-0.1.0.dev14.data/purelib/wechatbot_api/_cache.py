"""Bounded stable cache reader; no native calls and no network synchronization.

Container algorithms adapted from helper group_members.py/contacts.py. Target
vtables were independently checked against constructors and live cache objects.
"""
import re
import struct

from ._identity import APP_GLOBAL,read_identity
from .errors import ErrorCode,fail
from .models import DirectorySnapshot,GroupInfo,GroupMember,ContactInfo


class StableReader:
    def __init__(self,read):
        self._read=read;self.observed={};self.total=0
    def read(self,address,size):
        if not 0x10000<=address<0x800000000000 or not 0<size<=1048576 or address+size>=0x800000000000:
            fail(ErrorCode.LAYOUT_NOT_READY,'Cache pointer/budget not ready',retryable=True)
        value=self._read(address,size)
        if len(value)!=size:
            fail(ErrorCode.LAYOUT_NOT_READY,'Cache read incomplete',retryable=True)
        key=(address,size)
        if key in self.observed and self.observed[key]!=value:
            fail(ErrorCode.LAYOUT_NOT_READY,'Cache changed while reading',retryable=True)
        if key not in self.observed:
            self.total+=size
            if self.total>16*1024*1024:
                fail(ErrorCode.LAYOUT_NOT_READY,'Cache exceeds snapshot budget')
        self.observed[key]=value
        return value
    def ptr(self,address):return struct.unpack('<Q',self.read(address,8))[0]
    def string(self,address,limit=256):
        header=self.read(address,32);length,capacity=struct.unpack_from('<QQ',header,16)
        if length>limit or capacity<length or not (capacity==15 or 16<=capacity<=1048576):
            fail(ErrorCode.LAYOUT_MISMATCH,'Cache string layout mismatch')
        if not length:return ''
        data=self.read(address if capacity==15 else struct.unpack_from('<Q',header)[0],length)
        try:value=data.decode('utf-8')
        except UnicodeError:fail(ErrorCode.LAYOUT_MISMATCH,'Cache string encoding mismatch')
        if any(ord(c)<32 or ord(c)==127 for c in value):
            fail(ErrorCode.LAYOUT_MISMATCH,'Cache string contains invalid control bytes')
        return value
    def verify(self):
        for (address,size),value in reversed(tuple(self.observed.items())):
            if self._read(address,size)!=value:
                fail(ErrorCode.LAYOUT_NOT_READY,'Cache changed during final verification',retryable=True)


def cache_object(reader,base,account,table_rva,key=None):
    if read_identity(reader.read,base).wxid!=account:
        fail(ErrorCode.ACCOUNT_CHANGED,'Cache belongs to a different account')
    context=reader.ptr(reader.ptr(base+APP_GLOBAL)+0x68)
    if reader.ptr(reader.ptr(context)+0x38)!=base+0x355690 or reader.read(base+0x355690+28,8)!=bytes.fromhex('48 83 b9 60 04 00 00 00'):
        fail(ErrorCode.LAYOUT_MISMATCH,'Cache provider getter mismatch')
    provider=reader.ptr(context+0x460)
    if reader.ptr(provider)!=base+0x9225548:
        fail(ErrorCode.LAYOUT_NOT_READY,'Cache provider is not initialized',retryable=True)
    head,count=struct.unpack('<QQ',reader.read(provider+0x90,16))
    if not 1<=count<=512:fail(ErrorCode.LAYOUT_NOT_READY,'Cache registry count invalid')
    current=reader.ptr(head);seen=set();matches=[]
    for _ in range(count):
        if current==head or current in seen:fail(ErrorCode.LAYOUT_NOT_READY,'Cache registry changed')
        seen.add(current);obj=reader.ptr(current+0x30)
        if obj and reader.ptr(obj)==base+table_rva:
            if key is not None and reader.string(current+0x10,64)!=key:fail(ErrorCode.LAYOUT_MISMATCH,'Cache key mismatch')
            matches.append(obj)
        current=reader.ptr(current)
    if current!=head or len(matches)!=1:fail(ErrorCode.LAYOUT_NOT_READY,'No unique requested cache')
    return matches[0]


def room_records(read,base,account):
    reader=StableReader(read)
    cache=cache_object(reader,base,account,0x92257d8,'ChatroomCache')
    head,count=struct.unpack('<QQ',reader.read(cache+0x38,16))
    if count>10000:fail(ErrorCode.LAYOUT_NOT_READY,'Room cache exceeds budget')
    current=reader.ptr(head);seen=set();records={}
    for _ in range(count):
        if current==head or current in seen:fail(ErrorCode.LAYOUT_NOT_READY,'Room list changed')
        seen.add(current);next_node,previous=struct.unpack('<QQ',reader.read(current,16))
        if reader.ptr(previous)!=current or reader.ptr(next_node+8)!=current:fail(ErrorCode.LAYOUT_NOT_READY,'Room links changed')
        room=reader.string(current+0x10,127);record=reader.ptr(current+0x30)
        if not re.fullmatch(r'[a-zA-Z0-9_.-]+@chatroom',room) or reader.string(record+8,127)!=room or room in records:
            fail(ErrorCode.LAYOUT_MISMATCH,'Room record identity mismatch')
        records[room]=record;current=next_node
    if current!=head:fail(ErrorCode.LAYOUT_NOT_READY,'Room count changed')
    return reader,records


def contacts(read,base,account):
    reader=StableReader(read)
    cache=cache_object(reader,base,account,0x922bbd8)
    layout=reader.read(cache+0xc8,0x40)
    head,count,buckets,end,capacity,mask,bucket_count=struct.unpack_from('<7Q',layout,8)
    if count>10000 or not 1<=mask<=65535 or (mask+1)&mask or bucket_count!=mask+1 or end-buckets!=bucket_count*16 or capacity<end:
        fail(ErrorCode.LAYOUT_NOT_READY,'Contact cache container is not ready')
    current=reader.ptr(head);seen=set();result=[]
    for _ in range(count):
        if current==head or current in seen:fail(ErrorCode.LAYOUT_NOT_READY,'Contact links changed')
        seen.add(current);following,previous=struct.unpack('<QQ',reader.read(current,16))
        if reader.ptr(previous)!=current or reader.ptr(following+8)!=current:fail(ErrorCode.LAYOUT_NOT_READY,'Contact links changed')
        wxid=reader.string(current+0x10,127);record=reader.ptr(current+0x30)
        if not re.fullmatch(r'[a-zA-Z0-9_.@-]{1,127}',wxid) or reader.string(record+8,127)!=wxid:
            fail(ErrorCode.LAYOUT_MISMATCH,'Contact identity mismatch')
        result.append(ContactInfo(wxid,reader.string(record+0xd8,256) or None,reader.string(record+0x78,1024) or None))
        current=following
    if current!=head:fail(ErrorCode.LAYOUT_NOT_READY,'Contact count changed')
    if len({c.wxid for c in result})!=len(result):fail(ErrorCode.LAYOUT_MISMATCH,'Duplicate contact IDs')
    reader.verify()
    return DirectorySnapshot(tuple(sorted(result,key=lambda row:row.wxid)))


def groups(read,base,account):
    reader,records=room_records(read,base,account);reader.verify()
    return DirectorySnapshot(tuple(GroupInfo(room) for room in sorted(records)))


def members(read,base,account,room):
    reader,records=room_records(read,base,account)
    if room not in records:fail(ErrorCode.LAYOUT_NOT_READY,'Room is not loaded in the cache',retryable=True)
    record=records[room]
    table,array,count,allocated,capacity=struct.unpack_from('<QQiii',reader.read(record+0x60,32))
    if table!=base+0x922d358 or not 1<=count<=allocated<=capacity<=2000:
        fail(ErrorCode.LAYOUT_NOT_READY,'Member list is not stable',retryable=True)
    if struct.unpack_from('<Q',reader.read(record+0xd0,0x38),16)[0]!=count:
        fail(ErrorCode.LAYOUT_NOT_READY,'Member index is rebuilding',retryable=True)
    pointers=struct.unpack('<'+'Q'*count,reader.read(array,count*8));result=[];seen=set()
    if len(set(pointers))!=count:fail(ErrorCode.LAYOUT_MISMATCH,'Duplicate member pointers')
    for pointer in pointers:
        table,identity,name=struct.unpack('<QQQ',reader.read(pointer,24))
        if table!=base+0x922d2c8:fail(ErrorCode.LAYOUT_MISMATCH,'Member protobuf table mismatch')
        wxid=reader.string(identity,127)
        if not re.fullmatch(r'[a-zA-Z0-9_.@-]{1,127}',wxid) or wxid.endswith('@chatroom') or wxid in seen:fail(ErrorCode.LAYOUT_MISMATCH,'Member identity mismatch')
        seen.add(wxid)
        nickname=reader.string(name,256) if name else None
        result.append(GroupMember(wxid,nickname or None))
    if account not in seen:fail(ErrorCode.LAYOUT_NOT_READY,'Own membership is missing',retryable=True)
    reader.verify()
    return DirectorySnapshot(tuple(sorted(result,key=lambda row:row.wxid)))


def inspect_cache(pid,account,room=None,*,directory=False):
    from .discovery import inspect_process
    from ._win32 import Reader,modules
    result=inspect_process(pid)
    if result.error:fail(result.error,result.detail)
    if account is not None and result.account.wxid!=account:fail(ErrorCode.ACCOUNT_CHANGED,'Selected account changed')
    with Reader(pid) as process:
        if process.created()!=result.process_created:fail(ErrorCode.PROCESS_EXITED,'Process identity changed')
        core=modules(pid)['weixin.dll']
        if directory:
            snapshot=contacts(process.read,core[0],result.account.wxid)
        else:
            snapshot=groups(process.read,core[0],result.account.wxid) if room is None else members(process.read,core[0],result.account.wxid,room)
            from dataclasses import replace
            from .errors import FrameworkError
            try:
                names={r.wxid:r for r in contacts(process.read,core[0],result.account.wxid).records}
            except FrameworkError:
                names={}
            snapshot=replace(snapshot,records=tuple((replace(row,name=names[row.wxid].wechat_name) if isinstance(row,GroupInfo)
                else replace(row,wechat_name=names[row.wxid].wechat_name,remark=names[row.wxid].remark))
                if row.wxid in names else row for row in snapshot.records))
        if modules(pid).get('weixin.dll')!=core or read_identity(process.read,core[0])!=result.account:
            fail(ErrorCode.ACCOUNT_CHANGED,'Cache account/module changed')
        return snapshot
