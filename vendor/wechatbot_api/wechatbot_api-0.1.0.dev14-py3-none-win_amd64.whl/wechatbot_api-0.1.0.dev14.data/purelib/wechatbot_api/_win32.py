"""Private Win32 transport. Import does not open processes or load a bridge."""
from __future__ import annotations

import ctypes as c
from ctypes import wintypes as w
import os
import struct
from contextlib import contextmanager

from .errors import ErrorCode, fail


def kernel():
    if os.name != 'nt' or struct.calcsize('P') != 8:
        fail(ErrorCode.PLATFORM_UNSUPPORTED,'Windows x64 and 64-bit Python are required')
    k=c.WinDLL('kernel32',use_last_error=True)
    declarations={
        'CreateToolhelp32Snapshot':([w.DWORD,w.DWORD],w.HANDLE),
        'Process32FirstW':([w.HANDLE,c.c_void_p],w.BOOL),
        'Process32NextW':([w.HANDLE,c.c_void_p],w.BOOL),
        'Module32FirstW':([w.HANDLE,c.c_void_p],w.BOOL),
        'Module32NextW':([w.HANDLE,c.c_void_p],w.BOOL),
        'OpenProcess':([w.DWORD,w.BOOL,w.DWORD],w.HANDLE),
        'CloseHandle':([w.HANDLE],w.BOOL),
        'ReadProcessMemory':([w.HANDLE,c.c_void_p,c.c_void_p,c.c_size_t,c.POINTER(c.c_size_t)],w.BOOL),
        'GetProcessTimes':([w.HANDLE,c.POINTER(w.FILETIME),c.POINTER(w.FILETIME),c.POINTER(w.FILETIME),c.POINTER(w.FILETIME)],w.BOOL),
        'GetExitCodeProcess':([w.HANDLE,c.POINTER(w.DWORD)],w.BOOL),
        'WaitForSingleObject':([w.HANDLE,w.DWORD],w.DWORD),
    }
    for name,(args,result) in declarations.items():
        f=getattr(k,name); f.argtypes=args;f.restype=result
    return k


def win_error(message):
    code=c.get_last_error()
    fail(ErrorCode.ACCESS_DENIED if code==5 else ErrorCode.PROCESS_EXITED if code in (6,87,299) else ErrorCode.LAYOUT_NOT_READY,
         f'{message} (Win32 {code})',retryable=code!=5)


@contextmanager
def handle(value,k):
    if not value or value == c.c_void_p(-1).value:
        win_error('Opening process snapshot failed')
    try:
        yield value
    finally:
        k.CloseHandle(value)


class ProcessEntry(c.Structure):
    _fields_=[('size',w.DWORD),('usage',w.DWORD),('pid',w.DWORD),('heap',c.c_size_t),
        ('module',w.DWORD),('threads',w.DWORD),('parent',w.DWORD),('priority',w.LONG),('flags',w.DWORD),('exe',w.WCHAR*260)]


class ModuleEntry(c.Structure):
    _fields_=[('size',w.DWORD),('module_id',w.DWORD),('pid',w.DWORD),('global_usage',w.DWORD),
        ('usage',w.DWORD),('base',c.c_void_p),('bytes',w.DWORD),('module',w.HMODULE),
        ('name',w.WCHAR*256),('path',w.WCHAR*260)]


def candidates():
    k=kernel(); entry=ProcessEntry();entry.size=c.sizeof(entry)
    with handle(k.CreateToolhelp32Snapshot(2,0),k) as snapshot:
        ok=k.Process32FirstW(snapshot,c.byref(entry))
        while ok:
            if entry.exe.lower() in ('weixin.exe','wechat.exe'):
                yield entry.pid
            ok=k.Process32NextW(snapshot,c.byref(entry))


def modules(pid):
    k=kernel();entry=ModuleEntry();entry.size=c.sizeof(entry)
    rows={}
    with handle(k.CreateToolhelp32Snapshot(0x18,pid),k) as snapshot:
        ok=k.Module32FirstW(snapshot,c.byref(entry))
        if not ok:
            win_error('Enumerating process modules failed')
        while ok:
            rows[entry.name.lower()]=(entry.base,entry.bytes,entry.path)
            ok=k.Module32NextW(snapshot,c.byref(entry))
    return rows


class Reader:
    def __init__(self,pid):
        self.k=kernel();self.pid=pid;self.handle=None
    def __enter__(self):
        self.handle=self.k.OpenProcess(0x100410,False,self.pid)
        if not self.handle:
            win_error('Opening process for read-only discovery failed')
        return self
    def __exit__(self,*_):
        self.k.CloseHandle(self.handle);self.handle=None
    def created(self):
        times=[w.FILETIME() for _ in range(4)]
        if not self.k.GetProcessTimes(self.handle,*(c.byref(t) for t in times)):
            win_error('Reading process creation time failed')
        return times[0].dwLowDateTime+(times[0].dwHighDateTime<<32)
    def alive(self):
        status=self.k.WaitForSingleObject(self.handle,0)
        if status not in (0,258):win_error('Checking process liveness failed')
        return status==258
    def read(self,address,size):
        value=c.create_string_buffer(size);count=c.c_size_t()
        if not self.k.ReadProcessMemory(self.handle,address,value,size,c.byref(count)):
            error=c.get_last_error()
            if not self.alive():
                fail(ErrorCode.PROCESS_EXITED,'Process exited during discovery',retryable=True)
            # ERROR_PARTIAL_COPY on a live process is an unstable/unmapped object,
            # not proof that the process exited.
            if error==5:
                fail(ErrorCode.ACCESS_DENIED,'Process read access denied')
            fail(ErrorCode.LAYOUT_NOT_READY,'Memory changed during discovery',retryable=True)
        return value.raw[:count.value]
